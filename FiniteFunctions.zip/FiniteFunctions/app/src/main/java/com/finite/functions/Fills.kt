package com.finite.functions
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

// What an overlay is filled with, beyond a flat color: a gradient, a texture, a shape made of triangles, hexagons, or your own picture
val FILLS = listOf("Solid", "Gradient", "Dots", "Stripes", "Grid", "Triangles", "Hexagons", "Waves", "Speckle", "Picture")
val LocalFillPic = compositionLocalOf<ImageBitmap?> { null }

private fun r2(i: Int, j: Int, k: Int): Float { val v = sin(i * 12.9898f + j * 78.233f + k * 37.719f) * 43758.547f; return v - floor(v) }

fun DrawScope.drawFill(g: Group, pic: ImageBitmap?, blend: BlendMode = BlendMode.SrcOver) {
  val base = Color(g.color); val lt = lerp(base, Color.White, .30f); val dk = lerp(base, Color.Black, .35f); val al = g.alpha; val w = size.width; val h = size.height; val u = 14.dp.toPx()
  when (g.fill) {
    "Gradient" -> drawRect(Brush.linearGradient(listOf(lt.copy(alpha = al), dk.copy(alpha = al)), Offset.Zero, Offset(w, h)), blendMode = blend)
    "Dots" -> { var y = u / 2; var r = 0; while (y < h + u) { var x = if (r % 2 == 0) u / 2 else u; while (x < w + u) { drawCircle(lt.copy(alpha = .45f * al), 3.dp.toPx(), Offset(x, y), blendMode = blend); x += u }; y += u * .9f; r++ } }
    "Stripes" -> { var x = -h; while (x < w) { drawLine(lt.copy(alpha = .35f * al), Offset(x, h), Offset(x + h, 0f), 5.dp.toPx(), blendMode = blend); x += 14.dp.toPx() } }
    "Grid" -> { var x = 0f; while (x < w) { drawLine(lt.copy(alpha = .35f * al), Offset(x, 0f), Offset(x, h), 1.dp.toPx(), blendMode = blend); x += u * 1.5f }
      var y = 0f; while (y < h) { drawLine(lt.copy(alpha = .35f * al), Offset(0f, y), Offset(w, y), 1.dp.toPx(), blendMode = blend); y += u * 1.5f } }
    "Triangles" -> { val s = 26.dp.toPx(); var j = 0; var y = 0f
      while (y < h + s) { var i = 0; var x = 0f
        while (x < w + s) { for (k in 0..1) { val p = Path(); if (k == 0) { p.moveTo(x, y); p.lineTo(x + s, y); p.lineTo(x, y + s) } else { p.moveTo(x + s, y); p.lineTo(x + s, y + s); p.lineTo(x, y + s) }; p.close()
            drawPath(p, lerp(dk, lt, r2(i, j, k)).copy(alpha = al), blendMode = blend) }; x += s; i++ }
        y += s; j++ } }
    "Hexagons" -> { val s = 18.dp.toPx(); var row = 0; var y = 0f
      while (y < h + s) { var x = if (row % 2 == 0) 0f else s * 1.5f
        while (x < w + s) { val p = Path(); for (k in 0 until 6) { val a = k * 1.0472f; val px = x + s * cos(a); val py = y + s * sin(a); if (k == 0) p.moveTo(px, py) else p.lineTo(px, py) }; p.close()
          drawPath(p, lt.copy(alpha = .40f * al), style = Stroke(1.2.dp.toPx()), blendMode = blend); x += s * 3f }
        y += s * .87f; row++ } }
    "Waves" -> { var y = 0f; var i = 0; while (y < h + 20f) { val p = Path(); var x = 0f; p.moveTo(0f, y); while (x <= w) { p.lineTo(x, y + sin(x / 30f + i) * 5.dp.toPx()); x += 6f }
      drawPath(p, lt.copy(alpha = .4f * al), style = Stroke(2.dp.toPx()), blendMode = blend); y += 12.dp.toPx(); i++ } }
    "Speckle" -> for (i in 0 until ((w * h) / 700f).toInt().coerceAtMost(700)) drawCircle((if (i % 2 == 0) lt else dk).copy(alpha = .5f * al), (.6f + r2(i, 3, 3) * 1.6f).dp.toPx(), Offset(r2(i, 1, 1) * w, r2(i, 2, 2) * h), blendMode = blend)
    "Picture" -> pic?.let { val s = maxOf(w / it.width, h / it.height); val dw = (it.width * s).toInt(); val dh = (it.height * s).toInt()
      drawImage(it, IntOffset.Zero, IntSize(it.width, it.height), IntOffset(((w - dw) / 2).toInt(), ((h - dh) / 2).toInt()), IntSize(dw, dh), alpha = al, blendMode = blend) }
  }
}

// for shapes drawn by hand: the texture only lands where the shape is
fun DrawScope.withFill(g: Group, pic: ImageBitmap?, shape: DrawScope.() -> Unit) { if (g.fill == "Solid") { shape(); return }
  drawIntoCanvas { cv -> cv.saveLayer(Rect(0f, 0f, size.width, size.height), Paint()); shape(); drawFill(g, pic, BlendMode.SrcAtop); cv.restore() } }

// for shapes that are a clipped, filled box
@Composable fun Modifier.fillTex(g: Group): Modifier { if (g.fill == "Solid") return this; val pic = LocalFillPic.current; return drawBehind { drawFill(g, pic) } }
