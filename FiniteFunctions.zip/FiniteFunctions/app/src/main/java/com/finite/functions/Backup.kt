package com.finite.functions
import android.Manifest
import android.app.Application
import android.app.backup.BackupManager
import android.content.ContentUris
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.core.content.edit
import androidx.core.net.toUri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.time.Duration.Companion.milliseconds

// Watches the app's saved data. A second and a half after anything changes (and whenever the app leaves the screen) the whole record is written again.
class App : Application() {
  private lateinit var l: SharedPreferences.OnSharedPreferenceChangeListener
  override fun onCreate() { super.onCreate()
    l = SharedPreferences.OnSharedPreferenceChangeListener { _, k -> if (k == "libfiles" || k == "libfolders") LibMirror.changed(this)
      if (k != null && k != "pending" && k != "mirrorstat" && k != "mirrorlist" && k != "mirrordirs" && !(k.startsWith("w") && k.drop(1).all { it.isDigit() })) Backup.changed(this) }
    getSharedPreferences("ff", 0).registerOnSharedPreferenceChangeListener(l)
    // the old virtual Windows PC was removed: delete its leftover disk files (they can take tens of gigabytes)
    Thread { runCatching { java.io.File(filesDir, "vm").deleteRecursively() }; runCatching { getSharedPreferences("ff_vms", 0).edit().clear().apply() } }.start() }
}

object Backup {
  const val NAME = "FiniteFunctions-backup.json"
  private val h = Handler(Looper.getMainLooper()); private var task: Runnable? = null
  fun changed(c: Context) { task?.let { h.removeCallbacks(it) }; val r = Runnable { Thread { runCatching { save(c) } }.start() }; task = r; h.postDelayed(r, 1500) }
  fun flush(c: Context) { task?.let { h.removeCallbacks(it) }; task = null; Thread { runCatching { save(c) } }.start() }

  // every saved setting, group, color, playlist and song detail, as one file
  fun snapshot(c: Context): JSONObject { val o = JSONObject()
    Store(c).p.all.forEach { (k, v) -> if (k == "pending" || (k.startsWith("w") && k.drop(1).all { it.isDigit() })) return@forEach
      val e = JSONObject(); when (v) { is String -> e.put("t", "s").put("v", v); is Boolean -> e.put("t", "b").put("v", v); is Float -> e.put("t", "f").put("v", v.toDouble()); is Int -> e.put("t", "i").put("v", v); is Long -> e.put("t", "l").put("v", v)
        is Set<*> -> e.put("t", "ss").put("v", JSONArray(v.toList())); else -> return@forEach }; o.put(k, e) }
    return JSONObject().put("v", 1).put("savedAt", System.currentTimeMillis()).put("prefs", o) }

  // each song's file name and size, so it can be found again after a reinstall
  private fun ensureMeta(c: Context) { val st = Store(c); val meta = JSONObject(st.p.getString("meta", "{}")!!); var ch = false
    for ((u) in st.lib()["All"] ?: emptyList()) { if (meta.has(u)) continue
      runCatching { c.contentResolver.query(u.toUri(), arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { if (it.moveToFirst()) { meta.put(u, JSONObject().put("n", it.getString(0)).put("s", it.getLong(1))); ch = true } } } }
    if (ch) st.p.edit { putString("meta", meta.toString()) } }

  fun save(c: Context) { ensureMeta(c); val text = snapshot(c).toString()
    File(c.filesDir, "backup.json").writeText(text); BackupManager.dataChanged(c.packageName)   // Android decides when the Google upload runs
    folder(c)?.let { runCatching { writeTree(c, it, text) } } }

  fun folder(c: Context): Uri? { val d = Store(c).p.getString("bkdir", null) ?: return null
    return if (c.contentResolver.persistedUriPermissions.any { it.uri.toString() == d && it.isWritePermission }) d.toUri() else null }
  private fun findChild(c: Context, tree: Uri): Uri? { val id = DocumentsContract.getTreeDocumentId(tree)
    c.contentResolver.query(DocumentsContract.buildChildDocumentsUriUsingTree(tree, id), arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { cur ->
      while (cur.moveToNext()) if (cur.getString(1) == NAME) return DocumentsContract.buildDocumentUriUsingTree(tree, cur.getString(0)) }
    return null }
  private fun writeTree(c: Context, tree: Uri, text: String) { val f = findChild(c, tree) ?: DocumentsContract.createDocument(c.contentResolver, DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree)), "application/json", NAME) ?: return
    c.contentResolver.openOutputStream(f, "wt")?.use { it.write(text.toByteArray()) } }
  fun readTree(c: Context, tree: Uri): JSONObject? { val f = findChild(c, tree) ?: return null; return JSONObject(c.contentResolver.openInputStream(f)!!.bufferedReader().readText()) }
  fun readLocal(c: Context): JSONObject? = runCatching { JSONObject(File(c.filesDir, "backup.json").readText()) }.getOrNull()

  fun apply(c: Context, rec: JSONObject) { val prefs = rec.getJSONObject("prefs")
    Store(c).p.edit {
      prefs.keys().forEach { k -> if (k == "bkdir") return@forEach; val e = prefs.getJSONObject(k)
        when (e.getString("t")) { "s" -> putString(k, e.getString("v")); "b" -> putBoolean(k, e.getBoolean("v")); "f" -> putFloat(k, e.getDouble("v").toFloat()); "i" -> putInt(k, e.getInt("v")); "l" -> putLong(k, e.getLong("v"))
          "ss" -> { val a = e.getJSONArray("v"); putStringSet(k, (0 until a.length()).map { a.getString(it) }.toSet()) } } } } }
  fun audioPerm() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
}

// The three sections of the loading card
class RecState { var colors by mutableFloatStateOf(0f); var groups by mutableFloatStateOf(0f); var music by mutableFloatStateOf(0f)
  var note by mutableStateOf(""); var status by mutableStateOf("run"); var source by mutableStateOf("") }   // status: run, perm, norec, done

object Reconnect {
  private fun readable(c: Context, u: String) = runCatching { c.contentResolver.openInputStream(u.toUri())!!.close(); true }.getOrDefault(false)
  private fun migrate(st: Store, key: String, remap: Map<String, String>) { val j = JSONObject(st.p.getString(key, "{}")!!); var ch = false
    remap.forEach { (o, n) -> if (j.has(o)) { j.put(n, j.get(o)); j.remove(o); ch = true } }; if (ch) st.p.edit { putString(key, j.toString()) } }

  suspend fun run(c: Context, s: RecState, onlyMusic: Boolean) = withContext(Dispatchers.IO) {
    val st = Store(c); s.status = "run"
    if (!onlyMusic) {
      val tree = Backup.folder(c); val folder = tree?.let { runCatching { Backup.readTree(c, it) }.getOrNull() }; val local = Backup.readLocal(c)
      val rec = listOfNotNull(folder, local).maxByOrNull { it.optLong("savedAt") }
      if (rec == null) { s.status = "norec"; return@withContext }
      s.source = if (rec === folder) "backup folder" else "Google backup"
      Backup.apply(c, rec)   // everything saved comes back first, then each section is checked
      val keys = listOf("cc_ov", "cc_ic", "cc_gl"); val cols = keys.map { k -> st.p.getString(k, "")!!.split(",").filter { it.isNotEmpty() } }; val total = cols.sumOf { it.size }.coerceAtLeast(1); var done = 0
      cols.forEach { l -> l.forEach { _ -> done++; s.colors = done / total.toFloat(); delay(25.milliseconds) } }; s.colors = 1f
      val gs = st.groups(); val fonts = Fonts.list(c)
      val fixed = gs.mapIndexed { i, g -> var x = g
        if (x.mode == "Picture" && !readable(c, x.pic)) x = x.copy(mode = "Collage", pic = "")   // a picture that can't be opened any more
        if (x.font.isNotEmpty() && x.font !in fonts) x = x.copy(font = "")
        val lk = x.looks().filter { (_, v) -> !v.startsWith("pic:") || readable(c, v.removePrefix("pic:")) }; if (lk.size != x.looks().size) x = x.copy(plLook = JSONObject(lk as Map<*, *>).toString())
        s.groups = (i + 1) / gs.size.toFloat(); x }
      st.saveGroups(fixed); s.groups = 1f
    }
    if (ContextCompat.checkSelfPermission(c, Backup.audioPerm()) != PackageManager.PERMISSION_GRANTED) { s.status = "perm"; return@withContext }
    val meta = JSONObject(st.p.getString("meta", "{}")!!); val lib = st.lib(); val all = lib["All"] ?: emptyList()
    if (all.isEmpty()) { s.music = 1f; s.note = "No songs saved"; s.status = "done"; return@withContext }
    val idx = HashMap<String, Uri>()   // every audio file Android knows about, by name and size
    c.contentResolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.SIZE), null, null, null)?.use { cur ->
      while (cur.moveToNext()) idx.putIfAbsent(cur.getString(1) + "|" + cur.getLong(2), ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, cur.getLong(0))) }
    var found = 0; val remap = HashMap<String, String>()
    all.forEachIndexed { i, sg -> if (readable(c, sg.u)) found++ else { val m = meta.optJSONObject(sg.u); val hit = m?.let { idx[it.optString("n") + "|" + it.optLong("s")] }; if (hit != null) { remap[sg.u] = hit.toString(); found++ } }
      s.music = (i + 1) / all.size.toFloat(); s.note = "$found of ${all.size}" }
    if (remap.isNotEmpty()) { val m2 = LinkedHashMap<String, List<Song>>(); lib.forEach { (k, v) -> m2[k] = v.map { x -> remap[x.u]?.let { n -> x.copy(u = n) } ?: x } }; st.saveLib(m2)
      listOf("covers", "cpos", "emb", "art", "meta").forEach { migrate(st, it, remap) } }   // covers and crops follow the songs to their new addresses
    s.music = 1f; s.status = "done" }
}

// A second backup that is just a normal folder: "Finite Functions Library" with Files, Cuts and GIFs inside, holding a copy of everything the app keeps in Library.
// It lives inside the backup folder you chose, updates itself after changes, and only removes files it put there.
object LibMirror {
  private val h = Handler(Looper.getMainLooper()); private var task: Runnable? = null; @Volatile private var running = false
  fun changed(c: Context) { task?.let { h.removeCallbacks(it) }; val r = Runnable { Thread { runCatching { sync(c) } }.start() }; task = r; h.postDelayed(r, 2000) }
  private fun kids(c: Context, tree: Uri, parent: String): List<Pair<String, String>> { val out = ArrayList<Pair<String, String>>()
    c.contentResolver.query(DocumentsContract.buildChildDocumentsUriUsingTree(tree, parent), arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { while (it.moveToNext()) out.add(it.getString(0) to it.getString(1)) }
    return out }
  private fun dir(c: Context, tree: Uri, parent: String, name: String): String? = kids(c, tree, parent).firstOrNull { it.second == name }?.first
    ?: DocumentsContract.createDocument(c.contentResolver, DocumentsContract.buildDocumentUriUsingTree(tree, parent), DocumentsContract.Document.MIME_TYPE_DIR, name)?.let { DocumentsContract.getDocumentId(it) }
  fun sync(c: Context) { if (running) return; val tree = Backup.folder(c) ?: return; running = true
    try { val st = Store(c); val entries = st.libFiles().filter { it.mode == "moved" && File(it.ref).exists() }
      val root = dir(c, tree, DocumentsContract.getTreeDocumentId(tree), "Finite Functions Library") ?: return
      val sub = HashMap<String, String?>(); for ((k, n) in listOf("k:file" to "Files", "k:cut" to "Cuts", "k:gif" to "GIFs")) sub[k] = dir(c, tree, root, n)
      for (fl in st.libFolders()) sub["f:$fl"] = dir(c, tree, root, fl)   // your own folders, even empty ones
      val keyOf = { f: LibFile -> if (f.folder != "") "f:" + f.folder else "k:" + f.kind }
      val have = HashMap<String, Set<String>>(); val made = st.p.getStringSet("mirrorlist", emptySet())!!.toMutableSet(); var done = 0
      st.p.edit { putString("mirrorstat", "0/${entries.size}") }
      for (f in entries) { val key = keyOf(f); val d = sub[key]; val name = File(f.ref).name
        if (d != null) { val existing = have.getOrPut(key) { kids(c, tree, d).map { it.second }.toSet() }
          if (name !in existing) { val doc = DocumentsContract.createDocument(c.contentResolver, DocumentsContract.buildDocumentUriUsingTree(tree, d), f.mime, name)
            if (doc != null) c.contentResolver.openOutputStream(doc)?.use { o -> File(f.ref).inputStream().use { it.copyTo(o) } } }
          made.add("$key/$name") }
        done++; st.p.edit { putString("mirrorstat", "$done/${entries.size}") } }
      val keep = entries.map { keyOf(it) + "/" + File(it.ref).name }.toSet()   // files moved, renamed away or gone from Library are removed from the folder too
      made.filter { it !in keep }.forEach { m -> val key = m.substringBefore('/'); val n = m.substringAfter('/'); val d = sub[key]
        if (d != null) kids(c, tree, d).firstOrNull { it.second == n }?.let { (id, _) -> runCatching { DocumentsContract.deleteDocument(c.contentResolver, DocumentsContract.buildDocumentUriUsingTree(tree, id)) } }; made.remove(m) }
      val dirs = st.p.getStringSet("mirrordirs", emptySet())!!.toMutableSet(); val now = st.libFolders().toSet()   // a deleted or renamed folder: remove the empty one from the real folder
      dirs.filter { it !in now }.forEach { old -> kids(c, tree, root).firstOrNull { it.second == old }?.let { (id, _) -> if (kids(c, tree, id).isEmpty()) runCatching { DocumentsContract.deleteDocument(c.contentResolver, DocumentsContract.buildDocumentUriUsingTree(tree, id)) } }; dirs.remove(old) }
      dirs.addAll(now); st.p.edit { putStringSet("mirrorlist", made); putStringSet("mirrordirs", dirs) }
    } finally { running = false } }
}
