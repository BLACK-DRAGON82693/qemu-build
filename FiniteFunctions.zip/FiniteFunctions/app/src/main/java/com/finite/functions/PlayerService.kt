package com.finite.functions
import android.content.SharedPreferences
import android.media.audiofx.LoudnessEnhancer
import android.widget.Toast
import kotlin.math.log10
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.*
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture

@OptIn(UnstableApi::class)
class PlayerService : MediaSessionService() {
  private var s: MediaSession? = null; private var prefL: SharedPreferences.OnSharedPreferenceChangeListener? = null
  override fun onCreate() { super.onCreate()
    // tell Android this is music, so it hands over the audio output properly and pauses and resumes around other apps
    val attrs = AudioAttributes.Builder().setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).setUsage(C.USAGE_MEDIA).build()
    val player = ExoPlayer.Builder(this).setAudioAttributes(attrs, true).setHandleAudioBecomingNoisy(true).setWakeMode(C.WAKE_MODE_LOCAL).build()
    var enh: LoudnessEnhancer? = null   // volume boost: gain in millibels = 2000 x log10(percent / 100)
    fun boost() { runCatching { val pct = Store(this).boost; if (pct < 100) { player.volume = pct / 100f; enh?.enabled = false; return@runCatching }; player.volume = 1f; val sid = player.audioSessionId; if (sid == C.AUDIO_SESSION_ID_UNSET) return@runCatching
      if (enh == null) enh = LoudnessEnhancer(sid); enh!!.setTargetGain((2000.0 * log10(pct / 100.0)).toInt()); enh!!.enabled = pct > 100 } }
    fun speed() { runCatching { val st = Store(this); player.playbackParameters = PlaybackParameters(st.speed, if (st.keepPitch) 1f else st.speed) } }   // speed, with or without keeping the pitch
    prefL = SharedPreferences.OnSharedPreferenceChangeListener { _, k -> if (k == "boost") boost(); if (k == "speed" || k == "keeppitch") speed() }; getSharedPreferences("ff", 0).registerOnSharedPreferenceChangeListener(prefL); speed()
    player.addListener(object : Player.Listener { override fun onAudioSessionIdChanged(id: Int) { runCatching { enh?.release() }; enh = null; boost() } })
    var errs = 0
    player.addListener(object : Player.Listener {
      override fun onIsPlayingChanged(p: Boolean) { if (p) errs = 0 }
      override fun onPlayerError(e: PlaybackException) { Toast.makeText(this@PlayerService, "Couldn't play this song", Toast.LENGTH_SHORT).show()   // a file that won't open is skipped, not silent
        if (++errs <= 3 && player.hasNextMediaItem()) { player.seekToNextMediaItem(); player.prepare(); player.play() } } })
    s = MediaSession.Builder(this, player).setCallback(object : MediaSession.Callback {
      // songs sent by the app carry their address in the request, so make sure the player always gets it
      override fun onAddMediaItems(ms: MediaSession, c: MediaSession.ControllerInfo, items: MutableList<MediaItem>): ListenableFuture<MutableList<MediaItem>> =
        Futures.immediateFuture(items.map { m -> (m.requestMetadata.mediaUri ?: m.localConfiguration?.uri)?.let { m.buildUpon().setUri(it).build() } ?: m }.toMutableList()) }).build()
  }
  override fun onGetSession(i: MediaSession.ControllerInfo) = s
  override fun onDestroy() { prefL?.let { getSharedPreferences("ff", 0).unregisterOnSharedPreferenceChangeListener(it) }; s?.run { player.release(); release() }; s = null; super.onDestroy() }
}
