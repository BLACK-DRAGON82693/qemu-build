package com.finite.functions
import android.app.PendingIntent
import android.content.Intent
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.view.ViewGroup
import android.view.WindowManager
import androidx.activity.ComponentDialog
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// One quick settings tile. It shows a system dialog (not an activity), so the app underneath, like YouTube, isn't told it left the screen.
class GroupsTile : TileService() {
  override fun onStartListening() { AppCache.warm(this); qsTile?.apply { state = Tile.STATE_INACTIVE; label = "Finite Functions"; updateTile() } }
  override fun onClick() {
    if (Store(this).groups().any { g -> g.apps.any { it.startsWith("pl:") } }) runCatching { startService(Intent(this, PlayerService::class.java)) }   // Android allows this right at a tile tap
    if (isLocked) unlockAndRun { openPicker() } else openPicker() }

  @Suppress("DEPRECATION")
  private fun openPicker() {
    val st = Store(this); val gs = st.orderedGroups()
    val d = ComponentDialog(this, R.style.Theme_FF_Overlay); val sh = Shake(this); val runner = PlRunner(this, gs.any { g -> g.apps.any { it.startsWith("pl:") } })
    d.window?.apply { setBackgroundDrawable(ColorDrawable(android.graphics.Color.TRANSPARENT)); setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT); clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND) }
    val go: (AppInfo) -> Unit = { a -> if (a.pkg.startsWith("pl:")) runner.toggle(a.label) else { d.dismiss()
      packageManager.getLaunchIntentForPackage(a.pkg)?.let { i -> i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) startActivityAndCollapse(PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE)) else { TileService::class.java.getMethod("startActivityAndCollapse", Intent::class.java).invoke(this, i) } } } }
    val setBlur: (Int) -> Unit = { r -> if (Build.VERSION.SDK_INT >= 31) d.window?.let { w -> w.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND); val at = w.attributes; at.blurBehindRadius = r; w.attributes = at } }
    d.setContentView(ComposeView(this).apply { setContent {
      var screen by remember { mutableStateOf<String?>(null) }; val g = gs.firstOrNull { it.id == screen }
      if (g == null) PickerContent(gs, st.showNames, st.tileSize, st.tileStack, st.tileCover, { screen = it }) { d.dismiss() }
      else { DisposableEffect(g.id) { Thread { Snd.warm(g.sound) }.start(); if (g.loose) sh.start(); onDispose { sh.stop() } }
        GroupOverlay(g, listFor(this@GroupsTile, g), sh.flow, runner.playing.value, go, setBlur) { d.dismiss() } } } })
    d.setOnDismissListener { sh.stop(); runner.release() }
    showDialog(d)
  }
}

// The picker: each group's icon, with the names only if you turned that on in Settings
@OptIn(ExperimentalLayoutApi::class)
@Composable fun PickerContent(gs: List<Group>, names: Boolean, size: Float, stack: String, cover: String, onPick: (String) -> Unit, done: () -> Unit) {
  val ctx = LocalContext.current; var scrim by remember { mutableStateOf(false) }; var closing by remember { mutableStateOf(false) }; val prog = remember { Animatable(0f) }; val scope = rememberCoroutineScope()
  LaunchedEffect(Unit) { scrim = true; delay(300); prog.animateTo(1f, tween(400)) }   // tint first, then the groups
  val close: (String?) -> Unit = { id -> if (!closing) { closing = true; scope.launch { prog.animateTo(0f, tween(300)); scrim = false; delay(350); if (id != null) onPick(id) else done() } } }
  BackHandler { close(null) }
  val a by animateFloatAsState(if (scrim) .7f else 0f, tween(350))
  val none = remember { MutableInteractionSource() }
  Box(Modifier.fillMaxSize().clickable(indication = null, interactionSource = none) { close(null) }) {   // the clear half still closes it
    val area = when {   // how much of the screen is tinted and holds the icons
      cover.startsWith("Top") -> Modifier.align(Alignment.TopCenter).fillMaxWidth().fillMaxHeight(.5f)
      cover.startsWith("Bottom") -> Modifier.align(Alignment.BottomCenter).fillMaxWidth().fillMaxHeight(.5f)
      cover.startsWith("Left") -> Modifier.align(Alignment.CenterStart).fillMaxHeight().fillMaxWidth(.5f)
      cover.startsWith("Right") -> Modifier.align(Alignment.CenterEnd).fillMaxHeight().fillMaxWidth(.5f)
      else -> Modifier.fillMaxSize() }
    Box(area.background(Color.Black.copy(alpha = a)).clickable(indication = null, interactionSource = none) { close(null) }, Alignment.Center) {
      if (gs.isEmpty()) Text("Make a group first", color = Color.White.copy(alpha = prog.value))
      else {
        val item: @Composable (Group) -> Unit = { g -> Column(Modifier.padding((10 * size).dp).clickable { close(g.id) }, horizontalAlignment = Alignment.CenterHorizontally) {
          val bmp by produceState<ImageBitmap?>(null, g) { value = withContext(Dispatchers.Default) { ctx.groupBitmap(g).asImageBitmap() } }   // drawn in the background so the panel opens smoothly
          Box(Modifier.size((72 * size).dp).clip(CircleShape).background(Color(0xFF222222))) { bmp?.let { Image(it, g.name, Modifier.fillMaxSize()) } }
          if (names) Text(g.name, color = Color.White, fontSize = (12 * size).sp, maxLines = 2, textAlign = TextAlign.Center, modifier = Modifier.widthIn(max = (84 * size).dp)) } }
        val fx = Modifier.graphicsLayer { alpha = prog.value; scaleX = .85f + .15f * prog.value; scaleY = scaleX }
        when (stack) {
          "Vertical" -> Column(fx.verticalScroll(rememberScrollState()).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) { gs.forEach { item(it) } }
          "Horizontal" -> Row(fx.horizontalScroll(rememberScrollState()).padding(24.dp), verticalAlignment = Alignment.CenterVertically) { gs.forEach { item(it) } }
          else -> FlowRow(fx.padding(32.dp), horizontalArrangement = Arrangement.Center, verticalArrangement = Arrangement.Center) { gs.forEach { item(it) } } } } } }
}
