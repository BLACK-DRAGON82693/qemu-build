package com.finite.functions
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AColor
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.roundToInt

// Playback speed: 0.5x to 2x in steps of 0.05, with or without keeping the pitch. Applies to the Music tab and playlist bubbles.
@Composable fun SpeedPage() {
  val c = LocalContext.current; val st = remember { Store(c) }; var v by remember { mutableStateOf(st.speed) }; var keep by remember { mutableStateOf(st.keepPitch) }; val hap = LocalHapticFeedback.current
  fun set(n: Float) { val s = (n / .05f).roundToInt() * .05f; if (s != v) { v = s; st.speed = s; hap.performHapticFeedback(HapticFeedbackType.TextHandleMove) } }
  Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth().padding(top = 16.dp)) {
    Text("${"%.2f".format(v)}x", color = Color.White, fontSize = 56.sp, fontWeight = FontWeight.Bold)
    Text(if (v < .995f) "Slower than normal" else if (v > 1.005f) "Faster than normal" else "Normal speed", color = Color.Gray, fontSize = 13.sp)
    TSlider(v, { set(it) }, Modifier.padding(vertical = 12.dp), valueRange = .5f..2f, steps = 29)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("0.5x", color = Color.Gray, fontSize = 12.sp); Text("2x", color = Color.Gray, fontSize = 12.sp) }
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp)) { listOf(.75f, 1f, 1.25f, 1.5f, 2f).forEach { Pick("${it}x", kotlin.math.abs(v - it) < .001f) { set(it) } } }
    Row(Modifier.fillMaxWidth().padding(top = 16.dp), verticalAlignment = Alignment.CenterVertically) { Text("Keep the pitch the same", color = Color.White, modifier = Modifier.weight(1f)); TSwitch(keep, { keep = it; st.keepPitch = it }) }
    Text(if (keep) "Voices and instruments sound normal, only the speed changes." else "The pitch follows the speed: slower sounds deeper, faster sounds higher.", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
    Text("Applies to the Music tab and the playlist bubbles in your groups, straight away.", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp)) }
}

private fun qrBitmap(text: String, level: String, scale: Int): Bitmap? = runCatching {
  val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 0, 0, mapOf(EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.valueOf(level), EncodeHintType.MARGIN to 2))
  val b = Bitmap.createBitmap(m.width * scale, m.height * scale, Bitmap.Config.ARGB_8888); val cv = Canvas(b); cv.drawColor(AColor.WHITE); val p = Paint().apply { color = AColor.BLACK }
  for (y in 0 until m.height) for (x in 0 until m.width) if (m[x, y]) cv.drawRect((x * scale).toFloat(), (y * scale).toFloat(), ((x + 1) * scale).toFloat(), ((y + 1) * scale).toFloat(), p); b }.getOrNull()

// QR maker: type a link or text, see the code, save it to Library (PNG) or share it
@Composable fun QrPage() {
  val c = LocalContext.current; val st = remember { Store(c) }; var text by remember { mutableStateOf("") }; var level by remember { mutableStateOf("M") }
  val preview = remember(text, level) { if (text.isBlank()) null else qrBitmap(text, level, 8) }
  fun save(share: Boolean) { val b = qrBitmap(text, level, 12) ?: return; val base = text.trim().take(24).replace(Regex("[^A-Za-z0-9._-]"), "_").ifEmpty { "code" }
    var f = File(LibStore.dir(c, "file"), "QR $base.png"); var i = 1; while (f.exists()) { f = File(LibStore.dir(c, "file"), "QR $base ($i).png"); i++ }
    f.outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }; LibStore.addMade(c, "file", f, f.name, "image/png")
    if (share) LibStore.share(c, listOf(st.libFiles().last())) else LibStore.toast(c, "Saved to Library > Files") }
  Column(Modifier.fillMaxWidth().padding(top = 12.dp)) {
    OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), label = { Text("Link or text") }, keyboardOptions = KeyboardOptions.Default)
    Text("How much damage it can survive", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp)); Row { listOf("L", "M", "Q", "H").forEach { Pick(it, it == level) { level = it } } }
    Text("L holds the most text. H is still readable if it gets scratched or covered a little, but it's denser.", color = Color.Gray, fontSize = 12.sp)
    Box(Modifier.fillMaxWidth().padding(top = 12.dp), Alignment.Center) { val p = preview
      if (p != null) Image(p.asImageBitmap(), null, Modifier.size(260.dp).clip(RoundedCornerShape(12.dp)))
      else Box(Modifier.size(260.dp).clip(RoundedCornerShape(12.dp)).background(Th.card), Alignment.Center) { Text(if (text.isBlank()) "Type something to make a code" else "Too much text for a QR code", color = Color.Gray, fontSize = 13.sp) } }
    Row(Modifier.padding(top = 12.dp)) { TButton({ save(false) }, enabled = preview != null) { Text("Save to Library") }; Spacer(Modifier.width(8.dp)); TOutlinedButton({ save(true) }, enabled = preview != null) { Text("Save and share") } } }
}

private fun nameOf(c: android.content.Context, u: Uri) = c.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null } ?: "image"

// Image converter: pick pictures, choose JPEG, PNG or WEBP, optionally shrink them; the results land in Library > Files
@Composable fun ImgConvPage() {
  val c = LocalContext.current; val scope = rememberCoroutineScope(); var uris by remember { mutableStateOf(listOf<Uri>()) }; var fmt by remember { mutableStateOf("JPEG") }; var quality by remember { mutableStateOf(90f) }; var maxW by remember { mutableStateOf(0) }; var prog by remember { mutableStateOf<Float?>(null) }
  val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { us -> uris = uris + us }
  fun convert() { val list = uris; prog = 0f
    scope.launch(Dispatchers.IO) { var ok = 0
      list.forEachIndexed { i, u -> runCatching {
        var src = c.loadBmp(u.toString(), if (maxW > 0) maxW else 8192) ?: error("read")
        if (maxW > 0 && src.width > maxW) src = Bitmap.createScaledBitmap(src, maxW, (src.height * maxW / src.width.toFloat()).roundToInt().coerceAtLeast(1), true)
        val flat = if (fmt == "JPEG") Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888).also { Canvas(it).apply { drawColor(AColor.WHITE); drawBitmap(src, 0f, 0f, null) } } else src   // JPEG can't hold transparency, so it goes on white
        val ext = when (fmt) { "JPEG" -> "jpg"; "PNG" -> "png"; else -> "webp" }; val base = nameOf(c, u).substringBeforeLast('.')
        var f = File(LibStore.dir(c, "file"), "$base.$ext"); var n = 1; while (f.exists()) { f = File(LibStore.dir(c, "file"), "$base ($n).$ext"); n++ }
        val cf = when (fmt) { "JPEG" -> Bitmap.CompressFormat.JPEG; "PNG" -> Bitmap.CompressFormat.PNG; else -> if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else @Suppress("DEPRECATION") Bitmap.CompressFormat.WEBP }
        f.outputStream().use { flat.compress(cf, quality.roundToInt(), it) }; LibStore.addMade(c, "file", f, f.name, "image/" + (if (fmt == "JPEG") "jpeg" else ext)); ok++ }
        prog = (i + 1f) / list.size }
      LibStore.toast(c, "Converted $ok of ${list.size}. They're in Library > Files"); uris = emptyList(); prog = null } }
  Column(Modifier.fillMaxWidth().padding(top = 12.dp)) {
    Row(verticalAlignment = Alignment.CenterVertically) { TButton({ pick.launch(arrayOf("image/*")) }) { Text("Choose pictures") }; Text("  ${uris.size} chosen", color = Color.Gray, fontSize = 13.sp); if (uris.isNotEmpty()) Tx("Clear") { uris = emptyList() } }
    Text("Convert to", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp)); Row { listOf("JPEG", "PNG", "WEBP").forEach { Pick(it, it == fmt) { fmt = it } } }
    if (fmt != "PNG") { Text("Quality ${quality.roundToInt()}%", color = Color.White, modifier = Modifier.padding(top = 8.dp)); TSlider(quality, { quality = it }, valueRange = 10f..100f) }
    else Text("PNG keeps every pixel, so there's no quality setting.", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
    Text("Size", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp)); Row(Modifier.horizontalScroll(rememberScrollState())) { listOf(0 to "Original", 1920 to "1920 wide", 1280 to "1280 wide", 720 to "720 wide").forEach { (w, l) -> Pick(l, maxW == w) { maxW = w } } }
    TButton({ convert() }, Modifier.padding(top = 12.dp), enabled = uris.isNotEmpty() && prog == null) { Text("Convert") }
    Text("Your originals aren't touched. Converted copies go to Library > Files.", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
  prog?.let { p -> CenterCard("Converting", false, { }, locked = true) { RecRow("Pictures", p, "") } }
}
