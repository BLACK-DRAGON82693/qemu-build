package com.finite.functions
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.PI
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Path
import org.json.JSONObject
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import java.util.Collections
import java.util.UUID

val COLORS = listOf(0xFF222222, 0xFF1E88E5, 0xFFE53935, 0xFF43A047, 0xFF8E24AA, 0xFFFB8C00, 0xFFFFFFFF)
fun LazyGridScope.full(c: @Composable () -> Unit) = item(span = { GridItemSpan(maxLineSpan) }) { c() }

@Composable fun GroupsTab() {
  val ctx = LocalContext.current; val st = remember { Store(ctx) }
  var gs by remember { mutableStateOf(st.groups()) }; var ed by remember { mutableStateOf<Group?>(null) }
  val e = ed
  var origin by remember { mutableStateOf(Offset.Zero) }; var delG by remember { mutableStateOf<Pair<Group, Offset>?>(null) }
  if (e == null) Column(Modifier.onGloballyPositioned { origin = it.positionInRoot() }) {
    TButton({ ed = Group(UUID.randomUUID().toString().take(8), "New group") }) { Text("New group") }
    delG?.let { (dg, at) -> val hasW = st.p.all.entries.any { it.key.startsWith("w") && it.value == dg.id }
      PopCard(at, origin, true, "Delete group?", { delG = null }) {
        Text("Delete ${dg.name}?" + (if (hasW) " Its widget on your home screen will go blank." else ""), color = Color.White, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 8.dp))
        Row { TTextButton({ delG = null }) { Text("Cancel") }; TTextButton({ gs = gs - dg; st.saveGroups(gs); ctx.refreshWidgets(); delG = null }, danger = true) { Text("Delete") } } } }
    LazyColumn { items(gs) { g -> Row(verticalAlignment = Alignment.CenterVertically) {
      Image(remember(g) { ctx.groupBitmap(g).asImageBitmap() }, null, Modifier.size(48.dp).clip(CircleShape)); Text(g.name, color = Color.White, modifier = Modifier.weight(1f).padding(8.dp))
      IcoBtn("edit") { ed = g }; IcoBtn("pin") { ctx.addWidget(g) }; IcoBtnAt("trash") { delG = g to it } } } } }
  else Editor(e, { n -> gs = if (gs.any { it.id == n.id }) gs.map { if (it.id == n.id) n else it } else gs + n; st.saveGroups(gs); ctx.refreshWidgets(); ed = null }, { ed = null })
}

@Composable fun Editor(g: Group, onSave: (Group) -> Unit, onCancel: () -> Unit) {
  val ctx = LocalContext.current; val all = remember { ctx.apps() }
  var name by remember { mutableStateOf(g.name) }; var color by remember { mutableStateOf(g.color) }; var icolor by remember { mutableStateOf(g.icolor) }
  var anim by remember { mutableStateOf(g.anim) }; var mode by remember { mutableStateOf(g.mode) }; var preset by remember { mutableStateOf(g.preset) }
  var pic by remember { mutableStateOf(g.pic) }; var sel by remember { mutableStateOf(g.apps) }; var q by remember { mutableStateOf("") }; var shape by remember { mutableStateOf(g.shape) }; var blur by remember { mutableStateOf(g.blur) }; var alpha by remember { mutableStateOf(g.alpha) }; var namePos by remember { mutableStateOf(g.namePos) }; var size by remember { mutableStateOf(g.size) }; var loose by remember { mutableStateOf(g.loose) }; var wshape by remember { mutableStateOf(g.wshape) }; var nameOwn by remember { mutableStateOf(g.nameOwn) }; var sound by remember { mutableStateOf(g.sound) }; var lock by remember { mutableStateOf(g.lock) }; var rnd by remember { mutableStateOf(g.rnd) }; var ordSel by remember { mutableStateOf<String?>(null) }; var glyph by remember { mutableStateOf(g.glyph) }; var appsOpen by remember { mutableStateOf(false) }; var plOpen by remember { mutableStateOf(false) }; var looks by remember { mutableStateOf(g.looks()) }; var looksOpen by remember { mutableStateOf(false) }; var ringMap by remember { mutableStateOf(g.rings()) }; var font by remember { mutableStateOf(g.font) }; var fill by remember { mutableStateOf(g.fill) }; var fillPic by remember { mutableStateOf(g.fillPic) }; var fonts by remember { mutableStateOf(Fonts.list(ctx)) }; var delFont by remember { mutableStateOf<String?>(null) }; var presetTab by remember { mutableStateOf(maxOf(0, PRESET_TABS.indexOfFirst { g.preset in it.second })) }; var picFor by remember { mutableStateOf<String?>(null) }; val playlists = remember { Store(ctx).lib().keys.toList() }
  val img = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); pic = ctx.keepPic(u); mode = "Picture" } }
  var secOpen by remember { mutableStateOf(setOf("Overlay look")) }; fun tog(k: String) { secOpen = if (k in secOpen) secOpen - k else secOpen + k }
  val plPic = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> val n = picFor; if (u != null && n != null) { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); looks = looks + (n to "pic:" + ctx.keepPic(u)) }; picFor = null }
  val fontPick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) { val n = Fonts.add(ctx, u); if (n == null) Toast.makeText(ctx, "Couldn't load that font", Toast.LENGTH_SHORT).show() else { fonts = Fonts.list(ctx); font = n } } }
  val fillPick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); fillPic = ctx.keepPic(u); fill = "Picture" } }
  val shown = all.filter { it.label.contains(q, true) }
  Column {
    LazyVerticalGrid(GridCells.Fixed(5), Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
      full { OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true) }
      full { val ordered = sel.mapNotNull { p -> if (p.startsWith("pl:")) AppInfo(p, Uri.decode(p.removePrefix("pl:"))) else all.firstOrNull { it.pkg == p } }
        Column { Text("Preview", color = Color.Gray); CompositionLocalProvider(LocalFillPic provides remember(fillPic, fill) { if (fill == "Picture" && fillPic.isNotEmpty()) ctx.loadImg(fillPic) else null }) { Preview(g.copy(name = name, color = color, alpha = alpha, shape = shape, namePos = namePos, nameOwn = nameOwn, size = size, rnd = rnd, glyph = glyph, plLook = JSONObject(looks.filterKeys { "pl:" + Uri.encode(it) in sel }).toString(), ringMap = JSONObject(ringMap as Map<*, *>).toString(), font = font, fill = fill, fillPic = fillPic), ordered) }
          if (ordered.size > 1) { Text("Order: tap an app, then move it", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) { Row(Modifier.weight(1f).horizontalScroll(rememberScrollState())) { ordered.forEach { a -> Box(Modifier.padding(2.dp).clip(RoundedCornerShape(12.dp)).background(if (a.pkg == ordSel) Color(0xFF444444) else Color.Transparent).padding(4.dp)) { AppIcon(a, 30.dp) { ordSel = a.pkg } } } }
              IcoBtn("left") { ordSel?.let { p -> val i = sel.indexOf(p); if (i > 0) sel = sel.toMutableList().also { Collections.swap(it, i, i - 1) } } }
              IcoBtn("right") { ordSel?.let { p -> val i = sel.indexOf(p); if (i >= 0 && i < sel.size - 1) sel = sel.toMutableList().also { Collections.swap(it, i, i + 1) } } } } } } }
      full { SecHead("Icon", "Icon" in secOpen) { tog("Icon") } }
      if ("Icon" in secOpen) {
      full { Column { Text("Group icon", color = Color.Gray); Row { listOf("Collage", "Preset", "Picture").forEach { Pick(it, it == mode) { mode = it; if (it == "Picture") img.launch(arrayOf("image/*")) } } } } }
      if (mode != "Picture") full { Column { Text("Icon background color", color = Color.Gray); Swatches("ic", icolor) { icolor = it } } }
      if (mode == "Preset") full { Column { Text("Icon color", color = Color.Gray); Swatches("gl", glyph, true) { glyph = it } } }
      if (mode == "Preset") full { Row(Modifier.horizontalScroll(rememberScrollState())) { PRESET_TABS.forEachIndexed { i, t -> Pick(t.first, i == presetTab) { presetTab = i } } } }
      if (mode == "Preset") items(PRESET_TABS[presetTab].second) { p -> Box(Modifier.padding(2.dp).clip(RoundedCornerShape(14.dp)).background(if (p == preset) Color.White else Th.card2).clickable { preset = p }.padding(12.dp)) { Ico(p, 28.dp, if (p == preset) Color.Black else Color.White) } }
      }
      full { SecHead("Overlay look", "Overlay look" in secOpen) { tog("Overlay look") } }
      if ("Overlay look" in secOpen) {
      full { Column { Text("Overlay shape", color = Color.Gray); Row(Modifier.horizontalScroll(rememberScrollState())) { listOf("Dots", "Soft", "Sharp", "Wheel", "Strip", "Rings", "Cloud", "Blob").forEach { Pick(it, it == shape) { shape = it } } } } }
      full { Column { Text("Overlay style (what fills the shape)", color = Color.Gray); Row(Modifier.horizontalScroll(rememberScrollState())) { FILLS.forEach { Pick(it, it == fill) { fill = it; if (it == "Picture") fillPick.launch(arrayOf("image/*")) } } } } }
        if (shape == "Rings") full { RingEditor(sel, all, ringMap) { ringMap = it } }
      full { Column { Text("Overlay color", color = Color.Gray); Swatches("ov", color) { color = it } } }
      full { Column { Text("Overlay opacity", color = Color.Gray); TSlider(alpha, { alpha = it }, Modifier.fillMaxWidth()) } }
      full { Column { Text("Overlay size ${(size * 100).toInt()}%", color = Color.Gray); TSlider(size, { size = it }, Modifier.fillMaxWidth(), valueRange = .5f..2f) } }
      full { Row(verticalAlignment = Alignment.CenterVertically) { Text("Blur background", color = Color.White, modifier = Modifier.weight(1f)); TSwitch(blur, { blur = it }) } }
      full { Sw("Random shape (Dots, Cloud)", rnd, shape == "Dots" || shape == "Cloud") { rnd = it } }
      }
      full { SecHead("Name", "Name" in secOpen) { tog("Name") } }
      if ("Name" in secOpen) {
      full { Column { Text("Group name", color = Color.Gray); Row { listOf("Off", "Left", "Middle", "Right").forEach { Pick(it, it == namePos) { namePos = it } } } } }
      full { Sw("Name in its own bubble", nameOwn, namePos != "Off") { nameOwn = it } }
        full { Column { Text("Font (add a .ttf or .otf file with +)", color = Color.Gray); Row(Modifier.horizontalScroll(rememberScrollState())) { Chip("Default", font == "", { }) { font = "" }
          fonts.forEach { f -> Chip(f.substringBeforeLast('.'), font == f, { delFont = f }, font = Fonts.family(ctx, f)) { font = f } }; Pick("+", false) { fontPick.launch(arrayOf("*/*")) } } } }
      }
      full { SecHead("Animation and movement", "Move" in secOpen) { tog("Move") } }
      if ("Move" in secOpen) {
      full { Column { Text("Open animation", color = Color.Gray); Row(Modifier.horizontalScroll(rememberScrollState())) { listOf("Fade", "Scale", "Slide", "Lines", "Cubes", "Decloak", "Swirl", "Wave", "Beam", "Cut").forEach { Pick(it, it == anim) { anim = it } } } } }
      full { Row(verticalAlignment = Alignment.CenterVertically) { Text("Loose overlay (shake to bounce)", color = Color.White, modifier = Modifier.weight(1f)); TSwitch(loose, { loose = it }) } }
      full { Sw("Auto app lock (spins and scrolls end on an app)", lock) { lock = it } }
      }
      full { SecHead("Sound", "Sound" in secOpen) { tog("Sound") } }
      if ("Sound" in secOpen) {
      full { Column { Text("Sound", color = Color.Gray); Row(Modifier.horizontalScroll(rememberScrollState())) { listOf("Off", "Rolling", "Revolver", "Bubble", "Wood tap", "Typewriter", "Water drop", "Ratchet", "Glass", "Marimba").forEach { Pick(it, it == sound) { sound = it; Snd.warm(it); Snd.step(it, 3) } } } } }
      }
      full { SecHead("Widget", "Widget" in secOpen) { tog("Widget") } }
      if ("Widget" in secOpen) {
      full { Column { Text("Widget shape", color = Color.Gray); Row(Modifier.horizontalScroll(rememberScrollState())) { listOf("Soft", "Sharp", "Circle", "Rectangle").forEach { Pick(it, it == wshape) { wshape = it } } } } }
      }
      full { DropHead("Apps in group", sel.count { !it.startsWith("pl:") }, appsOpen) { appsOpen = !appsOpen } }
      if (appsOpen) {
        full { OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Search apps") }, leadingIcon = { Ico("search", 20.dp, Color.Gray) }) }
        items(shown, key = { it.pkg }) { a -> val on = a.pkg in sel
          Box(Modifier.padding(4.dp).clickable { sel = if (on) sel - a.pkg else sel + a.pkg }, contentAlignment = Alignment.BottomEnd) {
            Image(remember(a.pkg) { ctx.packageManager.getApplicationIcon(a.pkg).toBitmap(144, 144).asImageBitmap() }, null, Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)))
            if (on) Box(Modifier.size(20.dp).clip(CircleShape).background(Color.White), Alignment.Center) { Ico("check", 14.dp, Color.Black) } } } }
      full { DropHead("Playlists in group", sel.count { it.startsWith("pl:") }, plOpen) { plOpen = !plOpen } }
      if (plOpen) { if (playlists.isEmpty()) full { Text("Make a playlist in the Music tab first", color = Color.Gray, fontSize = 13.sp) }
        playlists.forEach { n -> val key = "pl:" + Uri.encode(n); val on = key in sel
          full { Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Th.card).clickable { sel = if (on) sel - key else sel + key }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Ico("music", 22.dp); Text(n, color = Color.White, modifier = Modifier.weight(1f).padding(horizontal = 12.dp)); if (on) Ico("check", 20.dp) } } } }
      full { DropHead("Playlist bubble look", sel.count { it.startsWith("pl:") }, looksOpen) { looksOpen = !looksOpen } }
      if (looksOpen) { sel.filter { it.startsWith("pl:") }.map { Uri.decode(it.removePrefix("pl:")) }.forEach { n -> val cur = looks[n] ?: ""
          full { Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Th.card).padding(12.dp)) {
            Text(n, color = Color.White)
            Row(Modifier.horizontalScroll(rememberScrollState())) { Pick("Note", cur == "") { looks = looks + (n to "") }; Pick("Icon", cur.startsWith("icon:")) { looks = looks + (n to "icon:music") }
              Pick("Name", cur == "name") { looks = looks + (n to "name") }; Pick("Picture", cur.startsWith("pic:")) { picFor = n; plPic.launch(arrayOf("image/*")) } }
            if (cur.startsWith("icon:")) Row(Modifier.horizontalScroll(rememberScrollState())) { PRESETS.forEach { p -> Box(Modifier.padding(2.dp).clip(RoundedCornerShape(12.dp)).background(if (cur == "icon:$p") Color.White else Color(0xFF2A2A2A)).clickable { looks = looks + (n to "icon:$p") }.padding(8.dp)) { Ico(p, 24.dp, if (cur == "icon:$p") Color.Black else Color.White) } } } } } }
        if (sel.none { it.startsWith("pl:") }) full { Text("Add a playlist above first", color = Color.Gray, fontSize = 13.sp) } }
    }
    delFont?.let { f -> CenterCard("Delete font?", true, { delFont = null }) {
      Text("Delete ${f.substringBeforeLast('.')}? Groups using it go back to Default.", color = Color.White, fontSize = 14.sp)
      Row { TTextButton({ delFont = null }) { Text("Cancel") }
        TTextButton({ Fonts.remove(ctx, f); fonts = Fonts.list(ctx); if (font == f) font = ""; val st = Store(ctx); st.saveGroups(st.groups().map { x -> if (x.font == f) x.copy(font = "") else x }); delFont = null }, danger = true) { Text("Delete") } } } }
    Row { TButton({ onSave(g.copy(name = name, color = color, icolor = icolor, anim = anim, mode = mode, preset = preset, pic = pic, apps = sel, shape = shape, blur = blur, alpha = alpha, namePos = namePos, size = size, loose = loose, wshape = wshape, nameOwn = nameOwn, sound = sound, lock = lock, rnd = rnd, glyph = glyph, plLook = JSONObject(looks.filterKeys { "pl:" + Uri.encode(it) in sel }).toString(), ringMap = JSONObject(ringMap as Map<*, *>).toString(), font = font, fill = fill, fillPic = fillPic)) }) { Text("Save") }; TTextButton(onCancel) { Text("Cancel") } }
  }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable fun Swatches(key: String, sel: Long, auto: Boolean = false, on: (Long) -> Unit) {
  val ctx = LocalContext.current; val st = remember { Store(ctx) }; val others = listOf("ov", "ic", "gl") - key; fun nm(k: String) = when (k) { "ov" -> "overlay"; "ic" -> "icon background"; else -> "icon" }
  var extra by remember { mutableStateOf(st.customColors(key)) }; var dlg by remember { mutableStateOf(false) }; var menu by remember { mutableStateOf<Long?>(null) }
  var r by remember { mutableStateOf(128f) }; var gr by remember { mutableStateOf(128f) }; var b by remember { mutableStateOf(128f) }; var hex by remember { mutableStateOf("#808080") }
  fun setRgb(rr: Float, gg: Float, bb: Float) { r = rr; gr = gg; b = bb; hex = "#%02X%02X%02X".format(rr.toInt(), gg.toInt(), bb.toInt()) }
  fun sw(c: Long) = Modifier.padding(4.dp).size(36.dp).clip(CircleShape).background(Color(c)).border(if (c == sel) 3.dp else 1.dp, if (c == sel) Color.White else Color.DarkGray, CircleShape)
  Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
    if (auto) Box(Modifier.padding(4.dp).size(36.dp).clip(CircleShape).background(Color(0xFF333333)).border(if (sel == 0L) 3.dp else 1.dp, if (sel == 0L) Color.White else Color.DarkGray, CircleShape).clickable { on(0L) }, Alignment.Center) { Text("Auto", color = Color.White, fontSize = 10.sp) }
    COLORS.forEach { c -> Box(sw(c).clickable { on(c) }) }
    extra.forEach { c -> Box { Box(sw(c).combinedClickable(onLongClick = { menu = c }, onClick = { on(c) }))
      DropdownMenu(menu == c, { menu = null }) {
        DropdownMenuItem({ Text("Delete") }, { st.removeColor(key, c); extra = st.customColors(key); menu = null })
        others.forEach { o -> DropdownMenuItem({ Text("Copy to ${nm(o)} colors") }, { st.addColor(o, c); menu = null }) } } } }
    Box(Modifier.padding(4.dp).size(36.dp).clip(CircleShape).border(1.dp, Color.Gray, CircleShape).clickable { dlg = true }, Alignment.Center) { Ico("plus", 18.dp) } }
  if (dlg) AlertDialog({ dlg = false }, title = { Text("Custom color") },
    confirmButton = { TTextButton({ val c = 0xFF000000L or (r.toLong() shl 16) or (gr.toLong() shl 8) or b.toLong(); st.addColor(key, c); extra = st.customColors(key); on(c); dlg = false }) { Text("Add") } },
    dismissButton = { TTextButton({ dlg = false }) { Text("Cancel") } },
    text = { Column { Box(Modifier.fillMaxWidth().height(40.dp).clip(RoundedCornerShape(12.dp)).background(Color(r.toInt(), gr.toInt(), b.toInt())))
      OutlinedTextField(hex, { h -> hex = h; Regex("#?([0-9a-fA-F]{6})").matchEntire(h.trim())?.let { m -> val v = m.groupValues[1].toInt(16); r = ((v shr 16) and 255).toFloat(); gr = ((v shr 8) and 255).toFloat(); b = (v and 255).toFloat() } }, label = { Text("RGB code") }, singleLine = true)
      TSlider(r, { setRgb(it, gr, b) }, valueRange = 0f..255f); TSlider(gr, { setRgb(r, it, b) }, valueRange = 0f..255f); TSlider(b, { setRgb(r, gr, it) }, valueRange = 0f..255f) } })
}

@Composable fun Sw(t: String, on: Boolean, enabled: Boolean = true, f: (Boolean) -> Unit) = Row(verticalAlignment = Alignment.CenterVertically) {
  Text(t, color = if (enabled) Color.White else Color.DarkGray, modifier = Modifier.weight(1f)); TSwitch(on, f, enabled = enabled) }

@Composable fun DropHead(t: String, n: Int, open: Boolean, f: () -> Unit) = GlassBox(RoundedCornerShape(14.dp), Modifier.fillMaxWidth().clickable { f() }) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
  Text("$t ($n)", color = Color.White, modifier = Modifier.weight(1f)); Ico(if (open) "up" else "down", 20.dp) } }

// A small picture of the overlay with the current settings. It stays one size: icons shrink to fit every app, and it scrolls if there are still too many.
@OptIn(ExperimentalLayoutApi::class)
@Composable fun Preview(g: Group, apps: List<AppInfo>) {
  val col = Color(g.color).copy(alpha = g.alpha); val k = .7f * g.size; val n = apps.size
  @Composable fun icons(a: List<AppInfo>, sz: Int, ph: Int = 2) { Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) { if (a.isEmpty()) repeat(ph) { Box(Modifier.size(sz.dp).clip(CircleShape).background(Color.DarkGray)) } else a.forEach { AppIcon(it, sz.dp) { } } } }
  Box(Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF0A0A0A)).border(1.dp, Color(0xFF333333), RoundedCornerShape(16.dp))) {
    Box(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), Alignment.Center) {
      when (g.shape) {
        "Dots" -> Column(Modifier.graphicsLayer { scaleX = k; scaleY = k }, horizontalAlignment = Alignment.CenterHorizontally) { Name(g, !g.nameOwn)
          FlowRow(horizontalArrangement = Arrangement.Center, verticalArrangement = Arrangement.Center) {
            if (apps.isEmpty()) repeat(3) { Box(Modifier.padding(2.dp).size(70.dp).clip(CircleShape).background(col).fillTex(g)) } else chunkApps(apps, false).forEach { (c, _) -> Bubble(c, if (n > 12) .7f else 1f, col, { }, Modifier, g) } } }
        "Wheel" -> { val n2 = maxOf(n, 5); val ic = (270f / n2).coerceIn(10f, 24f); val r = maxOf(44f, n2 * (ic + 2) / 6.283f)
          Column(Modifier.graphicsLayer { scaleX = k; scaleY = k }, horizontalAlignment = Alignment.CenterHorizontally) { if (g.nameOwn) Name(g); Box(Modifier.size((2 * r + ic + 12).dp).clip(CircleShape).background(col).fillTex(g), Alignment.Center) {
            for (i in 0 until n2) { val a = Math.toRadians(i * 360.0 / n2 - 90); Box(Modifier.offset((kotlin.math.cos(a) * r).dp, (kotlin.math.sin(a) * r).dp)) { if (i < n) AppIcon(apps[i], ic.dp) { } else Box(Modifier.size(ic.dp).clip(CircleShape).background(Color.DarkGray)) } } } } }
        "Rings" -> { val rs = if (n == 0) listOf(List(5) { AppInfo("", "") }) else buildRings(apps, g.rings()); val tot = 2 * (30f + 28f * (rs.size - 1)) + 34f
          Column(Modifier.graphicsLayer { scaleX = k; scaleY = k }, horizontalAlignment = Alignment.CenterHorizontally) { if (g.nameOwn) Name(g)
            Box(Modifier.size(tot.dp).drawBehind { rs.forEachIndexed { i, _ -> drawCircle(col, (30f + 28f * i).dp.toPx(), style = Stroke(24.dp.toPx())) } }, Alignment.Center) {   // small gap between each ring
              rs.forEachIndexed { i, ring -> val rad = 30f + 28f * i; val ic = minOf(20f, 6.283f * rad / ring.size * .85f)
                ring.forEachIndexed { j, a -> val an = Math.toRadians(j * 360.0 / ring.size - 90); Box(Modifier.offset((kotlin.math.cos(an) * rad).dp, (kotlin.math.sin(an) * rad).dp)) { if (a.pkg.isEmpty()) Box(Modifier.size(ic.dp).clip(CircleShape).background(Color.DarkGray)) else AppIcon(a, ic.dp) { } } } } } } }
        "Cloud" -> { val puffs = remember { List(14) { i -> Triple(((i * 37) % 10) / 10f, ((i * 53) % 10) / 10f, ((i * 29) % 10) / 10f) } }
          Column(Modifier.graphicsLayer { scaleX = k; scaleY = k }, horizontalAlignment = Alignment.CenterHorizontally) { if (g.nameOwn) Name(g)
            Box(Modifier.cloudBg(Color(g.color), g.alpha, puffs).padding(28.dp)) { Column(horizontalAlignment = Alignment.CenterHorizontally) { if (!g.nameOwn) Name(g, true)
              if (n == 0) icons(emptyList(), 28, 4) else apps.chunked(4).forEach { row -> icons(row, 28, 0); Spacer(Modifier.height(4.dp)) } } } } }
        "Blob" -> { val sz = (110f + minOf(n, 12) * 6f)
          Column(Modifier.graphicsLayer { scaleX = k; scaleY = k }, horizontalAlignment = Alignment.CenterHorizontally) { if (g.nameOwn) Name(g)
            Box(Modifier.size((sz * 1.15f).dp).drawBehind { val c = Offset(size.width / 2, size.height / 2); val r0 = sz.dp.toPx() / 2; val path = Path()
              for (i in 0..48) { val an = i * 2f * PI.toFloat() / 48; val r = r0 * (1f + .05f * sin(3f * an) + .035f * sin(5f * an)); val x = c.x + cos(an) * r; val y = c.y + sin(an) * r; if (i == 0) path.moveTo(x, y) else path.lineTo(x, y) }
              path.close(); drawPath(path, col) }, Alignment.Center) { if (!g.nameOwn) Name(g, true)
              (if (n == 0) List(4) { AppInfo("", "") } else apps).take(12).forEachIndexed { i, a -> val an = i * 2.4f; val rad = (sz / 2f - 22f) * kotlin.math.sqrt((i + .5f) / maxOf(minOf(n, 12), 4)); Box(Modifier.offset((cos(an) * rad).dp, (sin(an) * rad).dp)) { if (a.pkg.isEmpty()) Box(Modifier.size(24.dp).clip(CircleShape).background(Color.DarkGray)) else AppIcon(a, 24.dp) { } } } } } }
        "Strip" -> Box(Modifier.requiredSize(900.dp, 64.dp * k).graphicsLayer { rotationZ = -20f }.background(col).fillTex(g), Alignment.Center) { Box(Modifier.graphicsLayer { scaleX = k; scaleY = k }) { icons(apps, (300f / maxOf(n, 1)).coerceIn(14f, 34f).toInt(), 4) } }
        else -> Column(Modifier.graphicsLayer { scaleX = k; scaleY = k }, horizontalAlignment = Alignment.CenterHorizontally) { if (g.nameOwn) Name(g)
          Box(Modifier.clip(if (g.shape == "Sharp") RectangleShape else RoundedCornerShape(24.dp)).background(col).fillTex(g).padding(14.dp)) { Column(horizontalAlignment = Alignment.CenterHorizontally) { if (!g.nameOwn) Name(g, true)
            val sz = if (n > 15) 22 else if (n > 10) 26 else 30
            if (n == 0) icons(emptyList(), sz, 4) else apps.chunked(5).forEach { row -> icons(row, sz, 0); Spacer(Modifier.height(4.dp)) } } } }
      } } }
}

@Composable fun SecHead(t: String, open: Boolean, f: () -> Unit) = GlassBox(RoundedCornerShape(14.dp), Modifier.fillMaxWidth().clickable { f() }) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
  Text(t, color = Color.White, modifier = Modifier.weight(1f)); Ico(if (open) "up" else "down", 20.dp) } }

// Rings: pick which ring each app sits on. Tap an app, then tap a ring (or use the arrows to move it one ring in or out).
@Composable fun RingEditor(sel: List<String>, all: List<AppInfo>, map: Map<String, Int>, onMap: (Map<String, Int>) -> Unit) {
  val apps = sel.mapNotNull { p -> if (p.startsWith("pl:")) AppInfo(p, Uri.decode(p.removePrefix("pl:"))) else all.firstOrNull { it.pkg == p } }
  val raw = buildRingsRaw(apps, map); var pick by remember { mutableStateOf<String?>(null) }
  fun move(to: Int) { val p = pick ?: return; val cur = raw.flatMapIndexed { k, r -> r.map { it.pkg to k } }.toMap(); onMap(cur + (p to to.coerceIn(0, raw.size))) }   // saves every app's ring so nothing else shuffles
  val at = raw.indexOfFirst { r -> r.any { it.pkg == pick } }
  Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Th.card).padding(12.dp)) {
    Text("Rings: tap an app, then tap a ring", color = Color.Gray, fontSize = 12.sp)
    (0..raw.size).forEach { k -> val row = raw.getOrNull(k) ?: emptyList()
      Row(Modifier.fillMaxWidth().padding(top = 6.dp).clip(RoundedCornerShape(10.dp)).background(if (pick != null) Th.card2 else Color.Transparent).clickable { if (pick != null) move(k) }.padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(if (k == raw.size) "New ring" else if (k == 0) "Ring 1 (inner)" else "Ring ${k + 1}", color = Color.White, fontSize = 12.sp, modifier = Modifier.width(92.dp))
        Row(Modifier.horizontalScroll(rememberScrollState())) { row.forEach { a -> Box(Modifier.padding(2.dp).clip(RoundedCornerShape(10.dp)).background(if (a.pkg == pick) Color(0xFF555555) else Color.Transparent).padding(3.dp)) { AppIcon(a, 28.dp) { pick = a.pkg } } } } } }
    if (pick != null && at >= 0) Row(verticalAlignment = Alignment.CenterVertically) { Text("Move one ring", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.weight(1f)); IcoBtn("up") { move(maxOf(0, at - 1)) }; IcoBtn("down") { move(at + 1) } } }
}
