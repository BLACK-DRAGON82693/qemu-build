package com.finite.functions
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.drawable.AnimatedImageDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.widget.ImageView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.IntOffset
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.withContext
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.OutputStream
import kotlin.math.roundToInt

// A GIF encoder: one shared 252-colour palette with ordered dithering, and the GIF flavour of LZW compression
class GifWriter(private val out: OutputStream, private val w: Int, private val h: Int) {
  private val bayer = intArrayOf(0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5)
  private fun w16(v: Int) { out.write(v and 255); out.write((v shr 8) and 255) }
  init { out.write("GIF89a".toByteArray()); w16(w); w16(h); out.write(0xF7); out.write(0); out.write(0)
    for (r in 0 until 6) for (g in 0 until 7) for (b in 0 until 6) { out.write(r * 255 / 5); out.write(g * 255 / 6); out.write(b * 255 / 5) }
    repeat(4) { out.write(0); out.write(0); out.write(0) }
    out.write(0x21); out.write(0xFF); out.write(0x0B); out.write("NETSCAPE2.0".toByteArray()); out.write(3); out.write(1); out.write(0); out.write(0); out.write(0) }   // loops forever

  fun frame(px: IntArray, delayCs: Int) {
    val idx = ByteArray(w * h)
    for (y in 0 until h) for (x in 0 until w) { val p = px[y * w + x]; val th = bayer[(y and 3) * 4 + (x and 3)] / 16f - .5f
      val r = (((p shr 16) and 255) + th * 51f).coerceIn(0f, 255f); val g = (((p shr 8) and 255) + th * 42f).coerceIn(0f, 255f); val b = ((p and 255) + th * 51f).coerceIn(0f, 255f)
      idx[y * w + x] = ((r * 5 / 255f).roundToInt() * 42 + (g * 6 / 255f).roundToInt() * 6 + (b * 5 / 255f).roundToInt()).toByte() }
    out.write(0x21); out.write(0xF9); out.write(4); out.write(0); w16(delayCs); out.write(0); out.write(0)
    out.write(0x2C); w16(0); w16(0); w16(w); w16(h); out.write(0); lzw(idx) }

  private fun lzw(data: ByteArray) {
    out.write(8); val buf = ByteArrayOutputStream(); var acc = 0; var nb = 0
    fun put(code: Int, size: Int) { acc = acc or (code shl nb); nb += size; while (nb >= 8) { buf.write(acc and 255); acc = acc ushr 8; nb -= 8 } }
    var size = 9; var next = 258; val dict = HashMap<Int, Int>(8192); put(256, size)
    var cur = data[0].toInt() and 255
    for (i in 1 until data.size) { val b = data[i].toInt() and 255; val key = (cur shl 8) or b; val hit = dict[key]
      if (hit != null) cur = hit else { put(cur, size); if (next >= (1 shl size) && size < 12) size++
        if (next < 4096) { dict[key] = next++ } else { put(256, size); dict.clear(); next = 258; size = 9 }
        cur = b } }
    put(cur, size); if (next >= (1 shl size) && size < 12) size++; put(257, size); if (nb > 0) buf.write(acc and 255)
    val bytes = buf.toByteArray(); var o = 0; while (o < bytes.size) { val n = minOf(255, bytes.size - o); out.write(n); out.write(bytes, o, n); o += n }; out.write(0) }

  fun finish() { out.write(0x3B); out.flush(); out.close() }
}

// A clip on the timeline: a picture (dur = how long it shows) or a video (plays from inS for dur seconds, out of srcDur)
data class Clip(val uri: Uri, val video: Boolean, val srcDur: Float, val inS: Float, val dur: Float)
data class Anim(val type: String, val start: Float, val end: Float)
val ANIMS = listOf("Fade in", "Fade out", "Zoom in", "Zoom out", "Pan left", "Pan right", "Spin", "Shake", "Pulse")

object GifMaker {
  fun cover(b: Bitmap, w: Int, h: Int): Bitmap { val o = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); val s = maxOf(w / b.width.toFloat(), h / b.height.toFloat())
    val m = Matrix(); m.postScale(s, s); m.postTranslate((w - b.width * s) / 2, (h - b.height * s) / 2); Canvas(o).drawBitmap(b, m, Paint(Paint.FILTER_BITMAP_FLAG)); return o }
  fun ease(p: Float) = p * p * (3f - 2f * p)   // slow in, slow out: transitions and animations glide instead of moving at a constant speed
  fun dims(c: android.content.Context, k: Clip): Pair<Int, Int> = runCatching { if (k.video) { val r = MediaMetadataRetriever(); r.setDataSource(c, k.uri); val b = r.getFrameAtTime((k.inS * 1_000_000).toLong()); r.release(); b!!.width to b.height } else c.loadBmp(k.uri.toString(), 400)!!.let { it.width to it.height } }.getOrDefault(480 to 270)

  // Builds any frame of the GIF: the clip at that time, a transition into the next one, then any animations on top
  class Composer(private val c: android.content.Context, val w: Int, val h: Int, private val fast: Boolean) {
    var clips: List<Clip> = emptyList(); var anims: List<Anim> = emptyList(); var trans = "Fade"; var dir = "Left"; var tt = .5f
    private val imgs = HashMap<Uri, Bitmap>(); private val retr = HashMap<Uri, MediaMetadataRetriever>()
    private fun clipFrame(i: Int, local: Float): Bitmap { val k = clips[i]
      if (!k.video) return imgs.getOrPut(k.uri) { cover(c.loadBmp(k.uri.toString(), 1200) ?: Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888), w, h) }
      val r = retr.getOrPut(k.uri) { MediaMetadataRetriever().apply { setDataSource(c, k.uri) } }
      val b = r.getFrameAtTime(((k.inS + local) * 1_000_000).toLong(), if (fast) MediaMetadataRetriever.OPTION_CLOSEST_SYNC else MediaMetadataRetriever.OPTION_CLOSEST) ?: return Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
      return cover(b, w, h) }
    @Synchronized fun frameAt(t: Float): Bitmap { if (clips.isEmpty()) return Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
      var acc = 0f; var i = 0; while (i < clips.size - 1 && t >= acc + clips[i].dur) { acc += clips[i].dur; i++ }; val local = (t - acc).coerceIn(0f, clips[i].dur)
      var base = clipFrame(i, local); val tr = minOf(tt, clips[i].dur)
      if (i < clips.size - 1 && trans != "Swap" && local > clips[i].dur - tr) { val p = ease(((local - (clips[i].dur - tr)) / tr).coerceIn(0f, 1f)); val nx = clipFrame(i + 1, 0f)
        val o = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); val cv = Canvas(o)
        if (trans == "Fade") { cv.drawBitmap(base, 0f, 0f, null); cv.drawBitmap(nx, 0f, 0f, Paint().apply { alpha = (p * 255).toInt() }) }
        else { val (dx, dy) = when (dir) { "Left" -> -1f to 0f; "Right" -> 1f to 0f; "Up" -> 0f to -1f; else -> 0f to 1f }
          cv.drawBitmap(base, dx * p * w, dy * p * h, null); cv.drawBitmap(nx, dx * (p - 1) * w, dy * (p - 1) * h, null) }
        base = o }
      return applyAnims(base, t) }
    private fun applyAnims(src: Bitmap, t: Float): Bitmap {
      val act = anims.filter { it.end > it.start && t >= it.start && t <= it.end }; if (act.isEmpty()) return src
      var alpha = 1f; var sc = 1f; var rot = 0f; var tx = 0f
      for (a in act) { val q = ((t - a.start) / (a.end - a.start)).coerceIn(0f, 1f); val e = ease(q)
        when (a.type) { "Fade in" -> alpha *= e; "Fade out" -> alpha *= 1f - e; "Zoom in" -> sc *= 1f + .3f * e; "Zoom out" -> sc *= 1.3f - .3f * e
          "Pan left" -> { sc *= 1.15f; tx += w * .07f * (1f - 2f * e) }; "Pan right" -> { sc *= 1.15f; tx -= w * .07f * (1f - 2f * e) }
          "Spin" -> rot += 360f * e; "Shake" -> tx += kotlin.math.sin(q * 40f) * w * .03f; "Pulse" -> sc *= 1f + .1f * kotlin.math.sin(q * 6.2832f * 3f) } }
      val o = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); val cv = Canvas(o); cv.drawColor(android.graphics.Color.BLACK)
      val m = Matrix(); m.postScale(sc, sc, w / 2f, h / 2f); m.postRotate(rot, w / 2f, h / 2f); m.postTranslate(tx, 0f)
      cv.drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG).apply { this.alpha = (alpha.coerceIn(0f, 1f) * 255).toInt() }); return o }
    fun close() { retr.values.forEach { runCatching { it.release() } } }
  }

  // Most apps play a GIF no faster than 50 frames per second, so frames beyond that would only make the file bigger.
  fun build(c: android.content.Context, clips: List<Clip>, fps: Int, trans: String, dir: String, tt: Float, anims: List<Anim>, size: Pair<Int, Int>?, out: File, onP: (Float) -> Unit) {
    val eff = minOf(fps, 50); val total = clips.sumOf { it.dur.toDouble() }.toFloat(); val frames = (total * eff).toInt().coerceAtLeast(2)
    val w: Int; val h: Int; if (size == null) { val (fw, fh) = dims(c, clips[0]); w = minOf(480, fw); h = (w * fh / fw.toFloat()).roundToInt().coerceAtLeast(16) } else { w = size.first.coerceIn(16, 1000); h = size.second.coerceIn(16, 1000) }
    val comp = Composer(c, w, h, false).also { it.clips = clips; it.anims = anims; it.trans = trans; it.dir = dir; it.tt = tt }; val gif = GifWriter(out.outputStream().buffered(), w, h)
    for (f in 0 until frames) { val bmp = comp.frameAt(minOf(f / eff.toFloat(), total)); val px = IntArray(w * h); bmp.getPixels(px, 0, w, 0, 0, w, h)
      gif.frame(px, (Math.round((f + 1) * 100f / eff) - Math.round(f * 100f / eff)).coerceAtLeast(2)); onP((f + 1f) / frames) }
    gif.finish(); comp.close() }
}

// The GIF maker, laid out like a small video editor: preview on top, a timeline with a clips track and an animations track, a toolbar, and an Export bar that stays at the bottom.
@OptIn(ExperimentalFoundationApi::class)
@Composable fun GifPage() {
  val c = LocalContext.current; val scope = rememberCoroutineScope(); val dps = 48f
  var clips by remember { mutableStateOf(listOf<Clip>()) }; var anims by remember { mutableStateOf(listOf<Anim>()) }; var selClip by remember { mutableStateOf(-1) }; var selAnim by remember { mutableStateOf(-1) }
  var fps by remember { mutableStateOf(12) }; var trans by remember { mutableStateOf("Fade") }; var dir by remember { mutableStateOf("Left") }; var tt by remember { mutableStateOf(.5f) }
  var auto by remember { mutableStateOf(true) }; var wTxt by remember { mutableStateOf("480") }; var hTxt by remember { mutableStateOf("270") }
  var tab by remember { mutableStateOf("Clips") }; var pt by remember { mutableStateOf(0f) }; var playing by remember { mutableStateOf(false) }; var fpsDialog by remember { mutableStateOf(false) }; var fpsTxt by remember { mutableStateOf("12") }
  var prog by remember { mutableStateOf<Float?>(null) }; var result by remember { mutableStateOf<File?>(null) }; var frame by remember { mutableStateOf<ImageBitmap?>(null) }
  val total = clips.sumOf { it.dur.toDouble() }.toFloat()
  val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { us -> scope.launch(Dispatchers.IO) { val add = us.map { u ->
    if ((c.contentResolver.getType(u) ?: "").startsWith("video")) { val d = runCatching { val r = MediaMetadataRetriever(); r.setDataSource(c, u); val x = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L) / 1000f; r.release(); x }.getOrDefault(0f).coerceAtLeast(.5f); Clip(u, true, d, 0f, minOf(d, 4f)) }
    else Clip(u, false, 0f, 0f, 2f) }
    var room = 30f - clips.sumOf { it.dur.toDouble() }.toFloat(); val fit = ArrayList<Clip>(); for (k in add) { if (room < .3f) break; val k2 = if (k.dur > room) k.copy(dur = room) else k; fit.add(k2); room -= k2.dur }
    clips = clips + fit } }
  val dim by produceState(480 to 270, clips.firstOrNull()?.uri) { val k = clips.firstOrNull(); value = if (k == null) 480 to 270 else withContext(Dispatchers.IO) { GifMaker.dims(c, k) } }
  val asp = (if (!auto) (wTxt.toFloatOrNull() ?: 16f) / (hTxt.toFloatOrNull() ?: 9f) else dim.first / dim.second.toFloat()).coerceIn(.5f, 2.5f); val pw = 360; val ph = (pw / asp).toInt()
  val comp = remember(ph) { GifMaker.Composer(c, pw, ph, true) }; DisposableEffect(comp) { onDispose { comp.close() } }
  comp.clips = clips; comp.anims = anims; comp.trans = trans; comp.dir = dir; comp.tt = tt
  val curTotal by rememberUpdatedState(total)
  // One worker that builds frames and skips ahead when one is slow. Before, every move restarted the work and a slow frame was thrown away unfinished, so the preview froze at the busy moments.
  LaunchedEffect(comp) { snapshotFlow { listOf(pt, clips, anims, trans, dir, tt) }.conflate().collect {
    if (clips.isEmpty()) frame = null else { val b = withContext(Dispatchers.Default) { runCatching { comp.frameAt(pt.coerceIn(0f, curTotal)).asImageBitmap() }.getOrNull() }; if (b != null) frame = b } } }   // a frame that fails keeps the last good one on screen
  LaunchedEffect(playing) { if (playing) { var last = System.nanoTime()   // playback follows the real clock, so a slow frame is skipped instead of slowing everything down
    while (playing) { delay(16); val now = System.nanoTime(); val dt = (now - last) / 1e9f; last = now; val tot = curTotal; if (tot <= 0f) { playing = false; break }; pt += dt; if (pt >= tot) pt = 0f } } }
  fun build() { prog = 0f; scope.launch(Dispatchers.Default) { val f = File(c.cacheDir, "make.gif")
    val ok = runCatching { GifMaker.build(c, clips, fps, trans, dir, tt, anims, if (auto) null else ((wTxt.toIntOrNull() ?: 480) to (hTxt.toIntOrNull() ?: 270)), f) { prog = it }; true }.getOrDefault(false)
    if (ok) result = f else { f.delete(); LibStore.toast(c, "Couldn't make the GIF") }; prog = null } }
  fun trim(i: Int, side: Int, ds: Float) { val k = clips.getOrNull(i) ?: return
    val nk = if (side == 1) k.copy(dur = (k.dur + ds).coerceAtLeast(.3f).let { if (k.video) it.coerceAtMost(k.srcDur - k.inS) else it })
      else if (k.video) { val ni = (k.inS + ds).coerceIn(0f, k.inS + k.dur - .3f); k.copy(inS = ni, dur = k.dur - (ni - k.inS)) } else k.copy(dur = (k.dur - ds).coerceAtLeast(.3f))
    if (total - k.dur + nk.dur <= 30f) clips = clips.toMutableList().also { it[i] = nk } }
  val ew = if (auto) 480 else (wTxt.toIntOrNull() ?: 480); val eh = if (auto) 270 else (hTxt.toIntOrNull() ?: 270); val mb = total * minOf(fps, 50) * ew * eh * .35 / 1_000_000
  Column(Modifier.fillMaxSize()) {
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(top = 8.dp)) {
      Box(Modifier.fillMaxWidth().aspectRatio(asp).clip(RoundedCornerShape(14.dp)).background(Color.Black), Alignment.Center) {
        frame?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit) } ?: Text("Add pictures or videos to see the preview", color = Color.Gray, fontSize = 13.sp) }
      Row(verticalAlignment = Alignment.CenterVertically) { IcoBtn(if (playing) "pause" else "play") { playing = !playing }
        TSlider(pt.coerceIn(0f, maxOf(total, .1f)), { pt = it; playing = false }, Modifier.weight(1f), valueRange = 0f..maxOf(total, .1f)); Text("${"%.1f".format(pt)} / ${"%.1f".format(total)} s", color = Color.Gray, fontSize = 12.sp) }
      // the timeline: a ruler, the clips track and the animations track
      Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xFF141414)).horizontalScroll(rememberScrollState()).padding(8.dp)) {
        Column(Modifier.width(((maxOf(total, 4f)) * dps + 80).dp)) {
          Box(Modifier.fillMaxWidth().height(18.dp).pointerInput(total) { detectTapGestures { o -> pt = (o.x / density / dps).coerceIn(0f, total); playing = false } }) { (0..maxOf(total, 4f).toInt()).forEach { s -> Text("$s", color = Color.Gray, fontSize = 9.sp, modifier = Modifier.offset(x = (s * dps).dp)) } }
          Row(Modifier.height(64.dp).padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            clips.forEachIndexed { i, k -> val th = remember(k.uri) { if (k.video) null else c.loadBmp(k.uri.toString(), 160)?.asImageBitmap() }; var dx by remember(k.uri) { mutableStateOf(0f) }
              Box(Modifier.offset { IntOffset(dx.roundToInt(), 0) }.width((k.dur * dps).dp.coerceAtLeast(36.dp)).fillMaxHeight().clip(RoundedCornerShape(8.dp)).background(Color(0xFF333333)).border(if (selClip == i) 2.dp else 0.dp, Color.White, RoundedCornerShape(8.dp))
                .pointerInput(i, clips.size) { detectDragGesturesAfterLongPress(onDragStart = { dx = 0f }, onDrag = { _, d -> dx += d.x },
                  onDragEnd = { val ws = clips.map { maxOf(it.dur * dps * density, 36f * density) }; val center = ws.take(i).sum() + ws[i] / 2 + dx; var acc = 0f; var to = ws.size - 1; for (j in ws.indices) { if (center < acc + ws[j]) { to = j; break }; acc += ws[j] }
                    dx = 0f; if (to != i) clips = clips.toMutableList().also { l -> l.add(to, l.removeAt(i)) }; selClip = to }, onDragCancel = { dx = 0f }) }
                .clickable { selClip = i; selAnim = -1 }) {
                th?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) } ?: Box(Modifier.fillMaxSize(), Alignment.Center) { if (k.video) Ico("clapper", 22.dp, Color.Gray) }
                Text("${"%.1f".format(k.dur)}s", color = Color.White, fontSize = 10.sp, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 2.dp).clip(RoundedCornerShape(6.dp)).background(Color(0x99000000)).padding(horizontal = 4.dp))
                Box(Modifier.align(Alignment.CenterStart).width(14.dp).fillMaxHeight().background(Color(0xCCFFFFFF)).pointerInput(i) { detectDragGestures { _, d -> trim(i, 0, d.x / density / dps) } }, Alignment.Center) { Box(Modifier.width(2.dp).height(20.dp).background(Color.Black)) }
                Box(Modifier.align(Alignment.CenterEnd).width(14.dp).fillMaxHeight().background(Color(0xCCFFFFFF)).pointerInput(i) { detectDragGestures { _, d -> trim(i, 1, d.x / density / dps) } }, Alignment.Center) { Box(Modifier.width(2.dp).height(20.dp).background(Color.Black)) } }
              if (i < clips.size - 1) Text(trans, color = Color.White, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 3.dp).clip(RoundedCornerShape(50)).background(Color(0xFF444444)).clickable { tab = "Clips" }.padding(horizontal = 6.dp, vertical = 3.dp)) }
            Box(Modifier.padding(start = 6.dp).size(56.dp).clip(RoundedCornerShape(10.dp)).border(1.dp, Color.Gray, RoundedCornerShape(10.dp)).clickable { pick.launch(arrayOf("image/*", "video/*")) }, Alignment.Center) { Ico("plus", 22.dp, Color.Gray) } }
          Box(Modifier.fillMaxWidth().height(40.dp).padding(top = 6.dp)) {
            anims.forEachIndexed { i, a -> val wDp = ((a.end - a.start) * dps).dp.coerceAtLeast(40.dp)
              Box(Modifier.offset(x = (a.start * dps).dp).width(wDp).fillMaxHeight().clip(RoundedCornerShape(8.dp)).background(if (selAnim == i) Color(0xFF555555) else Color(0xFF2E2E2E)).border(if (selAnim == i) 2.dp else 1.dp, if (selAnim == i) Color.White else Color(0xFF555555), RoundedCornerShape(8.dp))
                .pointerInput(i) { detectDragGestures { _, d -> val x = d.x / density / dps; val a0 = anims[i]; val len = a0.end - a0.start; val s = (a0.start + x).coerceIn(0f, maxOf(0f, total - len)); anims = anims.toMutableList().also { it[i] = a0.copy(start = s, end = s + len) } } }
                .clickable { selAnim = i; selClip = -1; tab = "Animations" }, Alignment.Center) {
                Text(a.type, color = Color.White, fontSize = 10.sp, maxLines = 1)
                Box(Modifier.align(Alignment.CenterStart).width(12.dp).fillMaxHeight().background(Color(0xCCFFFFFF)).pointerInput(i) { detectDragGestures { _, d -> val a0 = anims[i]; anims = anims.toMutableList().also { it[i] = a0.copy(start = (a0.start + d.x / density / dps).coerceIn(0f, a0.end - .2f)) } } })
                Box(Modifier.align(Alignment.CenterEnd).width(12.dp).fillMaxHeight().background(Color(0xCCFFFFFF)).pointerInput(i) { detectDragGestures { _, d -> val a0 = anims[i]; anims = anims.toMutableList().also { it[i] = a0.copy(end = (a0.end + d.x / density / dps).coerceIn(a0.start + .2f, maxOf(total, a0.start + .2f))) } } }) } }
            if (anims.isEmpty()) Text("Animations track: tap + Animation below", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterStart).padding(start = 4.dp)) } }
        Box(Modifier.offset(x = (pt * dps).dp).width(2.dp).height(150.dp).background(Color.White)) }   // the playhead
      Text("Hold a clip and drag to reorder. Drag the white edges to trim or stretch. Drag an animation bar to slide it, or its edges to resize it.", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
      Row(Modifier.fillMaxWidth().padding(top = 8.dp).clip(RoundedCornerShape(14.dp)).background(Th.card).padding(vertical = 6.dp)) {
        listOf("Clips" to "imgbox", "Animations" to "star", "Size" to "sliders", "Length" to "clock", "Frames" to "clapper").forEach { (t, ic) -> Column(Modifier.weight(1f).clickable { tab = t }.padding(vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) { Ico(ic, 22.dp, if (tab == t) Color.White else Color.Gray); Text(t, color = if (tab == t) Color.White else Color.Gray, fontSize = 10.sp) } } }
      Column(Modifier.fillMaxWidth().padding(top = 8.dp)) { when (tab) {
        "Clips" -> { Row(verticalAlignment = Alignment.CenterVertically) { TButton({ pick.launch(arrayOf("image/*", "video/*")) }) { Text("Add pictures or videos") }
            if (selClip in clips.indices) TTextButton({ clips = clips.filterIndexed { j, _ -> j != selClip }; selClip = -1 }, danger = true) { Text("Remove clip ${selClip + 1}") } }
          Text("Between clips", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp)); Row { listOf("Fade", "Swap", "Slide").forEach { Pick(it, it == trans) { trans = it } } }
          if (trans == "Slide") Row(Modifier.padding(top = 4.dp)) { listOf("Left", "Right", "Up", "Down").forEach { Pick(it, it == dir) { dir = it } } }
          if (clips.size >= 2 && trans != "Swap") Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 6.dp)) { Text("Transition time: ${"%.1f".format(tt)} s", color = Color.White, modifier = Modifier.weight(1f)); Tx("−0.1") { tt = (tt - .1f).coerceAtLeast(.1f) }; Tx("+0.1") { tt = (tt + .1f).coerceAtMost(2f) } } }
        "Animations" -> { Row(verticalAlignment = Alignment.CenterVertically) { TButton({ val s = pt.coerceIn(0f, maxOf(0f, total - .5f)); anims = anims + Anim("Fade in", s, minOf(maxOf(total, s + .5f), s + 1f)); selAnim = anims.size - 1 }, enabled = total > 0f) { Text("+ Animation at the playhead") }
            if (selAnim in anims.indices) TTextButton({ anims = anims.filterIndexed { j, _ -> j != selAnim }; selAnim = -1 }, danger = true) { Text("Remove") } }
          if (selAnim in anims.indices) { Text("Animation for the selected bar", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp)); Row(Modifier.horizontalScroll(rememberScrollState())) { ANIMS.forEach { t -> Pick(t, anims[selAnim].type == t) { anims = anims.toMutableList().also { it[selAnim] = it[selAnim].copy(type = t) } } } } }
          else Text("Tap a bar on the animations track to choose its animation.", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)) }
        "Size" -> { Row { Pick("Auto", auto) { auto = true }; Pick("Type a size", !auto) { auto = false } }
          if (!auto) Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) { OutlinedTextField(wTxt, { wTxt = it.filter { ch -> ch.isDigit() }.take(4) }, Modifier.weight(1f), singleLine = true, label = { Text("Width px") }); Text("  ×  ", color = Color.White); OutlinedTextField(hTxt, { hTxt = it.filter { ch -> ch.isDigit() }.take(4) }, Modifier.weight(1f), singleLine = true, label = { Text("Height px") }) }
          Text(if (auto) "Auto picks about 480 pixels wide and keeps the shape of your first clip." else "Pictures are filled and cropped to fit your size.", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
        "Length" -> { Text("GIF length: ${"%.1f".format(total)} s", color = Color.White)
          Text("The length is every clip added up. Drag a clip's white edges to change how long it plays. The most is 30 seconds.", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
        else -> { Text("$fps frames per second (tap to type)", color = Color.White, fontSize = 16.sp, modifier = Modifier.clickable { fpsTxt = "$fps"; fpsDialog = true })
          TSlider(fps.toFloat(), { fps = it.roundToInt() }, valueRange = 5f..120f, steps = 114)
          Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("5 (blocky, light)", color = Color.Gray, fontSize = 12.sp); Text("120 (smooth, heavy)", color = Color.Gray, fontSize = 12.sp) }
          if (fps > 50) Text("Most apps play GIFs at 50 frames per second at most, so above 50 the extra frames only add file size. The GIF is made at 50.", color = Color(0xFFFF8A80), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) } } } }
    // the Export bar, always at the bottom
    Row(Modifier.fillMaxWidth().padding(top = 6.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF1E1E1E)).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
      Column(Modifier.weight(1f)) { Text("Export", color = Color.White, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, fontSize = 13.sp)
        Text("About ${"%.1f".format(mb)} MB · ${"%.1f".format(total)} s" + (if (mb > 15) " · heavy" else ""), color = if (mb > 15) Color(0xFFFF8A80) else Color.Gray, fontSize = 12.sp) }
      TButton({ build() }, enabled = clips.isNotEmpty() && prog == null) { Text("Make the GIF") } } }
  if (fpsDialog) CenterCard("Frames per second", false, { fpsDialog = false }) { OutlinedTextField(fpsTxt, { fpsTxt = it.filter { ch -> ch.isDigit() }.take(3) }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), label = { Text("5 to 120") })
    Row { TTextButton({ fpsDialog = false }) { Text("Cancel") }; TTextButton({ fps = (fpsTxt.toIntOrNull() ?: fps).coerceIn(5, 120); fpsDialog = false }) { Text("OK") } } }
  prog?.let { p -> CenterCard("Making the GIF", false, { }, locked = true) { RecRow("GIF", p, "") } }
  result?.let { f -> CenterCard("Your GIF", false, { }, locked = true) {
    AndroidView(factory = { ctx -> ImageView(ctx).apply { adjustViewBounds = true
      if (Build.VERSION.SDK_INT >= 28) { val d = ImageDecoder.decodeDrawable(ImageDecoder.createSource(f)); setImageDrawable(d); (d as? AnimatedImageDrawable)?.start() } else setImageBitmap(android.graphics.BitmapFactory.decodeFile(f.path)) } }, modifier = Modifier.fillMaxWidth().heightIn(max = 300.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { TTextButton({ f.delete(); result = null }) { Text("Discard") }
      TTextButton({ val stamp = java.text.SimpleDateFormat("yyyyMMdd-HHmm", java.util.Locale.US).format(java.util.Date()); val dest = File(LibStore.dir(c, "gif"), "GIF $stamp.gif"); f.copyTo(dest, true); f.delete()
        LibStore.addMade(c, "gif", dest, "GIF $stamp", "image/gif"); LibStore.toast(c, "Saved to Library > GIFs"); result = null }) { Text("Save to Library") } } } }
}
