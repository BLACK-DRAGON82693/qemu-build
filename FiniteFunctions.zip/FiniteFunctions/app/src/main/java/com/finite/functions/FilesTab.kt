package com.finite.functions
import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import kotlin.math.abs
import kotlin.math.roundToInt
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.core.content.edit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

// kind: file, cut or gif. mode: moved (a copy in the app's folder, ref = its path) or shortcut (ref = the original's address)
data class LibFile(val id: String, val name: String, val size: Long, val mime: String, val kind: String, val mode: String, val ref: String, val added: Long = 0L, val folder: String = "")
fun Store.libFiles(): MutableList<LibFile> { val a = JSONArray(p.getString("libfiles", "[]")); return MutableList(a.length()) { i -> a.getJSONObject(i).let { LibFile(it.getString("id"), it.getString("name"), it.getLong("size"), it.getString("mime"), it.getString("kind"), it.getString("mode"), it.getString("ref"), it.optLong("added", 0L), it.optString("folder", "")) } } }
fun Store.saveLibFiles(l: List<LibFile>) { p.edit { putString("libfiles", JSONArray(l.map { JSONObject().put("id", it.id).put("name", it.name).put("size", it.size).put("mime", it.mime).put("kind", it.kind).put("mode", it.mode).put("ref", it.ref).put("added", it.added).put("folder", it.folder) }).toString()) } }

// Your own folders in Library, in the order you set. A file sits in at most one; they also appear as real folders inside the backup folder.
fun Store.libFolders(): List<String> { val a = JSONArray(p.getString("libfolders", "[]")); return List(a.length()) { a.getString(it) } }
fun Store.saveLibFolders(l: List<String>) { p.edit { putString("libfolders", JSONArray(l).toString()) } }

// Asks for read and write access, so a file can be moved (the original removed) if its location allows it
class OpenDocsRW : ActivityResultContracts.OpenMultipleDocuments() {
  override fun createIntent(context: Context, input: Array<String>): Intent = super.createIntent(context, input).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
}

object LibStore {
  fun dir(c: Context, kind: String) = File(c.filesDir, "library/" + when (kind) { "cut" -> "cuts"; "gif" -> "gifs"; else -> "files" }).apply { mkdirs() }
  private fun unique(d: File, n: String): File { var f = File(d, n); var i = 1; val base = n.substringBeforeLast('.', n); val ext = n.substringAfterLast('.', "")
    while (f.exists()) { f = File(d, "$base ($i)" + if (ext.isEmpty()) "" else ".$ext"); i++ }; return f }
  fun toast(c: Context, t: String) { Handler(Looper.getMainLooper()).post { Toast.makeText(c, t, Toast.LENGTH_LONG).show() } }
  fun uriOf(f: LibFile): String = if (f.mode == "shortcut") f.ref else Uri.fromFile(File(f.ref)).toString()
  fun uriFor(c: Context, f: LibFile): Uri = if (f.mode == "shortcut") Uri.parse(f.ref) else FileProvider.getUriForFile(c, c.packageName + ".files", File(f.ref))
  fun fileName(f: LibFile) = if (f.mode == "moved") File(f.ref).name else f.name

  fun addFile(c: Context, u: Uri) { val st = Store(c); var name = "file"; var size = 0L
    c.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { if (it.moveToFirst()) { name = it.getString(0) ?: name; size = it.getLong(1) } }
    val mime = c.contentResolver.getType(u) ?: "*/*"; val now = System.currentTimeMillis()
    if (st.libMode == "Move") { val dest = unique(dir(c, "file"), name)
      val ok = runCatching { c.contentResolver.openInputStream(u)!!.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }; true }.getOrDefault(false)
      if (!ok) { dest.delete(); toast(c, "Couldn't copy $name"); return }
      val removed = runCatching { DocumentsContract.deleteDocument(c.contentResolver, u) }.getOrDefault(false)
      if (!removed) toast(c, "$name was copied, but the original can't be removed from where it is")
      st.saveLibFiles(st.libFiles() + LibFile(UUID.randomUUID().toString(), name, dest.length(), mime, "file", "moved", dest.path, now))
    } else { runCatching { c.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
      st.saveLibFiles(st.libFiles() + LibFile(UUID.randomUUID().toString(), name, size, mime, "file", "shortcut", u.toString(), now)) } }

  fun addMade(c: Context, kind: String, f: File, name: String, mime: String) { val st = Store(c); st.saveLibFiles(st.libFiles() + LibFile(UUID.randomUUID().toString(), name, f.length(), mime, kind, "moved", f.path, System.currentTimeMillis())) }

  // a shortcut becomes a copy in the app's folder
  fun moveIn(c: Context, f: LibFile) { val st = Store(c); val u = Uri.parse(f.ref); val dest = unique(dir(c, "file"), f.name)
    val ok = runCatching { c.contentResolver.openInputStream(u)!!.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }; true }.getOrDefault(false)
    if (!ok) { dest.delete(); toast(c, "Couldn't reach ${f.name}, so it can't be moved"); return }
    val removed = runCatching { DocumentsContract.deleteDocument(c.contentResolver, u) }.getOrDefault(false)
    if (!removed) toast(c, "${f.name} was copied into the app's folder, but the original can't be removed from where it is")
    st.saveLibFiles(st.libFiles().map { if (it.id == f.id) it.copy(mode = "moved", ref = dest.path, size = dest.length()) else it }) }

  fun remove(c: Context, f: LibFile) { val st = Store(c); if (f.mode == "moved") File(f.ref).delete(); st.saveLibFiles(st.libFiles().filter { it.id != f.id }) }
  fun readable(c: Context, f: LibFile) = if (f.mode == "moved") File(f.ref).exists() else runCatching { c.contentResolver.openInputStream(Uri.parse(f.ref))!!.close(); true }.getOrDefault(false)
  fun open(c: Context, f: LibFile) { val u = uriFor(c, f)
    runCatching { c.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, f.mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)) }.onFailure { toast(c, "No app can open this") } }
  fun toMusic(c: Context, f: LibFile, playlist: String) { val st = Store(c); val m = st.lib(); val s = Song(uriOf(f), f.name.substringBeforeLast('.'))
    for (k in listOf("All", playlist)) m[k]?.let { l -> if (l.none { it.u == s.u }) l.add(s) }; st.saveLib(m) }

  // getting files out: share them, or save a copy anywhere you can see in your file manager
  fun share(c: Context, fs: List<LibFile>) { val uris = ArrayList(fs.map { uriFor(c, it) })
    val i = if (uris.size == 1) Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0]).setType(fs[0].mime) else Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris).setType("*/*")
    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); runCatching { c.startActivity(Intent.createChooser(i, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
  fun copyTo(c: Context, f: LibFile, out: Uri) { c.contentResolver.openInputStream(uriFor(c, f))?.use { i -> c.contentResolver.openOutputStream(out)?.use { o -> i.copyTo(o) } } }
  fun copyToTree(c: Context, tree: Uri, f: LibFile) { val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
    DocumentsContract.createDocument(c.contentResolver, parent, f.mime, fileName(f))?.let { copyTo(c, f, it) } }
  fun thumb(c: Context, f: LibFile): ImageBitmap? = runCatching { when {
    f.mime.startsWith("image") -> c.loadImg(uriOf(f))?.let { it }
    f.mime.startsWith("video") -> { val r = MediaMetadataRetriever(); if (f.mode == "moved") r.setDataSource(f.ref) else r.setDataSource(c, Uri.parse(f.ref)); val b = r.getFrameAtTime(0); r.release(); b?.asImageBitmap() }
    f.mime.startsWith("audio") -> Store(c).effCovers()[uriOf(f)]?.let { c.loadImg(it) }
    else -> null } }.getOrNull()
}

// plays a song from the Library's Music section, with the rest of your Music queued after it
fun playSong(c: Context, f: LibFile) { val st = Store(c); val all = st.lib()["All"] ?: return; val idx = all.indexOfFirst { it.u == f.id.removePrefix("song:") }.coerceAtLeast(0)
  PlayerHub.curPl = "All"
  PlayerHub.with(c) { x -> x.setMediaItems(all.map { MediaItem.Builder().setUri(it.u).setRequestMetadata(MediaItem.RequestMetadata.Builder().setMediaUri(Uri.parse(it.u)).build()).setMediaMetadata(MediaMetadata.Builder().setTitle(it.t).setArtist("Finite Functions").setArtworkUri(st.artUri(it.u)).build()).build() }, idx, 0L)
    x.repeatMode = Player.REPEAT_MODE_ALL; x.playWhenReady = true; x.prepare(); x.play() } }

private fun sizeText(b: Long) = if (b >= 1_073_741_824) "%.1f GB".format(b / 1_073_741_824.0) else if (b >= 1_048_576) "%.1f MB".format(b / 1_048_576.0) else "${maxOf(1L, b / 1024)} KB"
private fun iconFor(m: String) = when { m.startsWith("audio") -> "music"; m.startsWith("image") -> "imgbox"; m.startsWith("video") -> "clapper"; else -> "notepage" }

// The Library tab: search, sort, filters, grid or list, thumbnails, and selecting several files to share, copy out, move in or delete
@OptIn(ExperimentalFoundationApi::class)
@Composable fun FilesTab() {
  val c = LocalContext.current; val st = remember { Store(c) }; val scope = rememberCoroutineScope()
  var files by remember { mutableStateOf(st.libFiles()) }; var sec by remember { mutableStateOf("Files") }; var q by remember { mutableStateOf("") }; var sort by remember { mutableStateOf("Newest") }; var typeF by remember { mutableStateOf("All") }; var grid by remember { mutableStateOf(true) }
  var songs by remember { mutableStateOf(listOf<LibFile>()) }; var folders by remember { mutableStateOf(st.libFolders()) }; var folder by remember { mutableStateOf<String?>(null) }; var newDlg by remember { mutableStateOf(false) }; var newName by remember { mutableStateOf("") }; var folderMenu by remember { mutableStateOf<String?>(null) }; var renameFor by remember { mutableStateOf<String?>(null) }; var delFolder by remember { mutableStateOf<String?>(null) }; var moveDlg by remember { mutableStateOf(false) }
  var sel by remember { mutableStateOf(setOf<String>()) }; var pl by remember { mutableStateOf<List<LibFile>?>(null) }; var missing by remember { mutableStateOf(setOf<String>()) }; var confirm by remember { mutableStateOf(false) }; var saveOne by remember { mutableStateOf<LibFile?>(null) }
  val pick = rememberLauncherForActivityResult(OpenDocsRW()) { us -> scope.launch(Dispatchers.IO) { val before = st.libFiles().map { it.id }.toSet(); val fl = folder; us.forEach { LibStore.addFile(c, it) }
    if (fl != null) st.saveLibFiles(st.libFiles().map { if (it.id !in before) it.copy(folder = fl) else it })   // files added inside a folder go into it
    files = st.libFiles() } }
  val create = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { u -> val f = saveOne; saveOne = null; if (u != null && f != null) scope.launch(Dispatchers.IO) { runCatching { LibStore.copyTo(c, f, u) }; LibStore.toast(c, "Saved a copy of ${f.name}") } }
  val tree = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u -> val chosen = (files + songs).filter { it.id in sel }; if (u != null) scope.launch(Dispatchers.IO) { chosen.forEach { runCatching { LibStore.copyToTree(c, u, it) } }; LibStore.toast(c, "Saved ${chosen.size} copies") }; sel = emptySet() }
  // the Music section is a view of your Music tab: every song once, with its size
  LaunchedEffect(sec, files) { if (sec == "Music") songs = withContext(Dispatchers.IO) { val meta = JSONObject(st.p.getString("meta", "{}")!!); val all = st.lib()["All"] ?: emptyList()
    all.mapIndexed { idx, s -> val moved = s.u.startsWith("file:"); val path = if (moved) (Uri.parse(s.u).path ?: "") else ""
      val size = if (moved) File(path).length() else (meta.optJSONObject(s.u)?.optLong("s") ?: runCatching { c.contentResolver.query(Uri.parse(s.u), arrayOf(OpenableColumns.SIZE), null, null, null)?.use { if (it.moveToFirst()) it.getLong(0) else 0L } ?: 0L }.getOrDefault(0L))
      LibFile("song:" + s.u, s.t, size, "audio/*", "music", if (moved) "moved" else "shortcut", if (moved) path else s.u, (all.size - idx).toLong()) } } }
  LaunchedEffect(files, songs) { missing = withContext(Dispatchers.IO) { (files + songs).filter { !LibStore.readable(c, it) }.map { it.id }.toSet() } }
  val inMusic = sec == "Music" && folder == null
  val kind = when (sec) { "Cuts" -> "cut"; "GIFs" -> "gif"; "Music" -> "music"; else -> "file" }
  val shown = (if (inMusic) songs else files).filter { (if (folder != null) it.folder == folder else (it.folder == "" && it.kind == kind)) && (q.isBlank() || it.name.contains(q, true)) && when (typeF) { "Audio" -> it.mime.startsWith("audio"); "Images" -> it.mime.startsWith("image"); "Video" -> it.mime.startsWith("video"); "Other" -> !(it.mime.startsWith("audio") || it.mime.startsWith("image") || it.mime.startsWith("video")); else -> true } }
    .let { l -> when (sort) { "Name" -> l.sortedBy { it.name.lowercase() }; "Size" -> l.sortedByDescending { it.size }; else -> l.sortedByDescending { it.added } } }
  val chosen = (files + songs).filter { it.id in sel }
  Column(Modifier.pointerInput(Unit) { detectTapGestures { newDlg = true } }) {   // tapping empty space makes a new folder
    OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Search your library") }, leadingIcon = { Ico("search", 20.dp, Color.Gray) })
    if (folder == null) Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp)) { listOf("Files", "Cuts", "GIFs", "Music").forEach { Pick(it, it == sec) { sec = it; sel = emptySet() } } }
    else Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) { IcoBtn("left") { folder = null; sel = emptySet() }; Ico("folder", 22.dp); Text("  $folder", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1) }
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) { listOf("All", "Audio", "Images", "Video", "Other").forEach { Pick(it, it == typeF) { typeF = it } }
      Pick("+ Folder", false) { newDlg = true }; Pick("Sort: $sort", false) { sort = when (sort) { "Newest" -> "Name"; "Name" -> "Size"; else -> "Newest" } }; IcoBtn(if (grid) "list" else "grid") { grid = !grid } }
    Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
      Text("${shown.size} files · ${sizeText(shown.sumOf { it.size })}", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.weight(1f))
      if ((sec == "Files" || folder != null) && !inMusic) { Text(if (st.libMode == "Move") "Moved into the app's folder" else "Kept as shortcuts", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(end = 8.dp)); TButton({ pick.launch(arrayOf("*/*")) }) { Text("Add files") } } }
    // folders: tap to open, hold and drag to reorder, hold without moving for Rename and Delete
    if (folder == null && folders.isNotEmpty() && !inMusic) Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
      folders.forEachIndexed { i, name -> var dx by remember(name) { mutableStateOf(0f) }; val count = files.count { it.folder == name }
        Row(Modifier.offset { IntOffset(dx.roundToInt(), 0) }.padding(end = 8.dp).clip(RoundedCornerShape(14.dp)).background(Th.card).border(1.dp, Color(0xFF333333), RoundedCornerShape(14.dp))
          .pointerInput(name, folders.size) { var moved = 0f
            detectDragGesturesAfterLongPress(onDragStart = { dx = 0f; moved = 0f }, onDrag = { _, d -> dx += d.x; moved += abs(d.x) + abs(d.y) },
              onDragEnd = { val to = (i + (dx / (150f * density)).roundToInt()).coerceIn(0, folders.size - 1)
                if (moved < 20f) folderMenu = name else if (to != i) { val l = folders.toMutableList(); l.add(to, l.removeAt(i)); st.saveLibFolders(l); folders = l }; dx = 0f }, onDragCancel = { dx = 0f }) }
          .clickable { folder = name; sel = emptySet() }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Ico("folder", 22.dp)
          Column(Modifier.padding(start = 8.dp)) { Text(name, color = Color.White, maxLines = 1, fontSize = 13.sp); Text("$count file${if (count == 1) "" else "s"}", color = Color.Gray, fontSize = 11.sp) } } } }
    if (sel.isNotEmpty()) Column(Modifier.fillMaxWidth().padding(vertical = 6.dp).clip(RoundedCornerShape(14.dp)).background(Th.card2).padding(8.dp)) {
      Row(verticalAlignment = Alignment.CenterVertically) { Text("${sel.size} selected", color = Color.White, modifier = Modifier.weight(1f).padding(start = 6.dp))
        IcoBtn("share") { LibStore.share(c, chosen) }; IcoBtn("download") { tree.launch(null) }; IcoBtn("trash", Color(0xFFFF5252)) { confirm = true }; IcoBtn("close") { sel = emptySet() } }
      Row(Modifier.horizontalScroll(rememberScrollState())) { if (!inMusic) TTextButton({ moveDlg = true }) { Text("Move to folder") }; if (!inMusic && chosen.isNotEmpty() && chosen.all { it.mime.startsWith("audio") }) TTextButton({ pl = chosen }) { Text("Add to Music") }
        if (!inMusic && chosen.any { it.mode == "shortcut" }) TTextButton({ scope.launch(Dispatchers.IO) { chosen.filter { it.mode == "shortcut" }.forEach { LibStore.moveIn(c, it) }; files = st.libFiles() }; sel = emptySet() }) { Text("Move into the app's folder") } } }
    if (shown.isEmpty()) Text(if (if (inMusic) songs.isEmpty() else files.none { if (folder != null) it.folder == folder else (it.folder == "" && it.kind == kind) }) when (sec) { "Files" -> "Nothing here yet. Add files with the button above."; "Cuts" -> "Cuts from the Audio cutter appear here."; "Music" -> "No songs yet. Add music in the Music tab."; else -> "GIFs from the GIF maker appear here." } else "Nothing matches.", color = Color.Gray, modifier = Modifier.padding(top = 16.dp))
    @Composable fun card(f: LibFile) {
      val thumb by produceState<ImageBitmap?>(null, f.id) { value = withContext(Dispatchers.IO) { LibStore.thumb(c, f) } }; val on = f.id in sel; val miss = f.id in missing
      val sub = sizeText(f.size) + " · " + f.mime.substringAfter('/').take(10) + (if (f.mode == "shortcut") " · Shortcut" else "") + (if (miss) " · Missing" else "")
      val tap = { if (sel.isNotEmpty()) sel = if (on) sel - f.id else sel + f.id else if (f.kind == "music") playSong(c, f) else LibStore.open(c, f) }
      val box = Modifier.clip(RoundedCornerShape(14.dp)).background(Th.card).border(if (on) 2.dp else 1.dp, if (on) Color.White else Color(0xFF2A2A2A), RoundedCornerShape(14.dp)).combinedClickable(onLongClick = { sel = sel + f.id }, onClick = { tap() })
      val pic: @Composable (Modifier) -> Unit = { m -> Box(m.clip(RoundedCornerShape(10.dp)).background(Color(0xFF262626)), Alignment.Center) { thumb?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) } ?: Ico(iconFor(f.mime), 30.dp, Color.Gray)
        if (on) Box(Modifier.align(Alignment.TopStart).padding(6.dp).size(22.dp).clip(CircleShape).background(Color.White), Alignment.Center) { Ico("check", 15.dp, Color.Black) } } }
      if (grid) Column(box.padding(8.dp)) { pic(Modifier.fillMaxWidth().aspectRatio(1.25f)); Text(f.name, color = Color.White, maxLines = 1, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)); Text(sub, color = if (miss) Color(0xFFFF8A80) else Color.Gray, fontSize = 11.sp, maxLines = 1)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { IcoBtn("share") { LibStore.share(c, listOf(f)) }; IcoBtn("download") { saveOne = f; create.launch(LibStore.fileName(f)) } } }
      else Row(box.padding(8.dp), verticalAlignment = Alignment.CenterVertically) { pic(Modifier.size(56.dp)); Column(Modifier.weight(1f).padding(start = 10.dp)) { Text(f.name, color = Color.White, maxLines = 1); Text(sub, color = if (miss) Color(0xFFFF8A80) else Color.Gray, fontSize = 12.sp, maxLines = 1) }
        IcoBtn("share") { LibStore.share(c, listOf(f)) }; IcoBtn("download") { saveOne = f; create.launch(LibStore.fileName(f)) } } }
    if (grid) LazyVerticalGrid(GridCells.Adaptive(150.dp), Modifier.weight(1f).padding(top = 6.dp), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) { items(shown, key = { it.id }) { card(it) } }
    else LazyColumn(Modifier.weight(1f).padding(top = 6.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { items(shown, key = { it.id }) { card(it) } }
  }
  if (confirm) CenterCard("Delete files?", true, { confirm = false }) { Text(if (inMusic) "Remove ${chosen.size} song${if (chosen.size == 1) "" else "s"} from your Music? The files on your phone aren't deleted." else "Delete ${chosen.size} file${if (chosen.size == 1) "" else "s"} from the Library? Files kept in the app's folder are removed for good.", color = Color.White, fontSize = 14.sp)
    Row { TTextButton({ confirm = false }) { Text("Cancel") }; TTextButton({ if (inMusic) { val gone = chosen.map { it.id.removePrefix("song:") }.toSet(); val m = st.lib(); m.values.forEach { l -> l.removeAll { it.u in gone } }; st.saveLib(m); songs = songs.filter { it.id !in sel } } else { chosen.forEach { LibStore.remove(c, it) }; files = st.libFiles() }; sel = emptySet(); confirm = false }, danger = true) { Text("Delete") } } }
  fun create() { val n = newName.trim().replace("/", "-"); if (n.isEmpty() || n in folders || n in listOf("Files", "Cuts", "GIFs", "Music")) { Toast.makeText(c, if (n.isEmpty()) "Type a name" else "That name is taken", Toast.LENGTH_SHORT).show(); return }
    folders = folders + n; st.saveLibFolders(folders); newName = ""; newDlg = false }
  if (newDlg) CenterCard("New folder", false, { newDlg = false }) { OutlinedTextField(newName, { newName = it }, singleLine = true, label = { Text("Folder name") })
    Text("It's also made inside Finite Functions Library in your backup folder.", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)); Row { TTextButton({ newDlg = false }) { Text("Cancel") }; TTextButton({ create() }) { Text("Create") } } }
  folderMenu?.let { fm -> CenterCard(fm, false, { folderMenu = null }) { TTextButton({ renameFor = fm; newName = fm; folderMenu = null }) { Text("Rename") }
    TTextButton({ delFolder = fm; folderMenu = null }, danger = true) { Text("Delete") }; TTextButton({ folderMenu = null }) { Text("Cancel") } } }
  renameFor?.let { old -> CenterCard("Rename folder", false, { renameFor = null }) { OutlinedTextField(newName, { newName = it }, singleLine = true, label = { Text("Folder name") })
    Row { TTextButton({ renameFor = null }) { Text("Cancel") }; TTextButton({ val n = newName.trim().replace("/", "-")
      if (n.isEmpty() || (n != old && (n in folders || n in listOf("Files", "Cuts", "GIFs", "Music")))) Toast.makeText(c, "That name can't be used", Toast.LENGTH_SHORT).show()
      else { folders = folders.map { if (it == old) n else it }; st.saveLibFolders(folders); st.saveLibFiles(st.libFiles().map { if (it.folder == old) it.copy(folder = n) else it }); files = st.libFiles(); renameFor = null } }) { Text("Rename") } } } }
  delFolder?.let { d -> CenterCard("Delete folder?", true, { delFolder = null }) { Text("Delete $d? Its files aren't deleted, they go back to the top level of the Library.", color = Color.White, fontSize = 14.sp)
    Row { TTextButton({ delFolder = null }) { Text("Cancel") }; TTextButton({ folders = folders - d; st.saveLibFolders(folders); st.saveLibFiles(st.libFiles().map { if (it.folder == d) it.copy(folder = "") else it }); files = st.libFiles(); delFolder = null }, danger = true) { Text("Delete") } } } }
  if (moveDlg) CenterCard("Move ${sel.size} to", false, { moveDlg = false }) { fun to(t: String) { st.saveLibFiles(st.libFiles().map { if (it.id in sel) it.copy(folder = t) else it }); files = st.libFiles(); sel = emptySet(); moveDlg = false }
    if (folder != null) TTextButton({ to("") }) { Text("Top level") }; folders.filter { it != folder }.forEach { f -> TTextButton({ to(f) }) { Text(f) } }
    if (folders.isEmpty() && folder == null) Text("Make a folder first with + Folder.", color = Color.Gray, fontSize = 13.sp); TTextButton({ moveDlg = false }) { Text("Cancel") } }
  pl?.let { fs -> CenterCard("Add ${fs.size} to", false, { pl = null }) { st.lib().keys.forEach { k -> TTextButton({ fs.forEach { LibStore.toMusic(c, it, k) }; pl = null; sel = emptySet(); Toast.makeText(c, "Added to $k", Toast.LENGTH_SHORT).show() }) { Text(k) } }; TTextButton({ pl = null }) { Text("Cancel") } } }
}
