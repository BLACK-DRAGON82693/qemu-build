package com.finite.functions
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.sin

val THEMES = listOf("None", "Aurora", "Bubbles", "Neon grid", "Sunset plains", "Lab", "Matrix", "Rainy night", "Snowfall", "Deep sea", "Galaxy")
// 23 colors, plus the X (first) for the default, makes a full 6 x 4 block
val THEME_HUES = listOf(0f, 15f, 30f, 45f, 60f, 75f, 90f, 110f, 130f, 150f, 165f, 180f, 195f, 210f, 225f, 240f, 255f, 270f, 285f, 300f, 315f, 330f, 345f)

// The app's theme. A color doesn't paint everything: it picks a family (the color and its neighbours about 35 degrees either side) that backgrounds are drawn in,
// while pages and cards stay close to neutral with a slight tint and only highlights use the strong color. It never touches group overlays, icons or widgets.
object Th {
  var theme by mutableStateOf("None"); var hue by mutableStateOf(-1f); var night by mutableFloatStateOf(0f)   // hue -1 = the X, each theme's own default
  fun load(st: Store) { theme = st.theme.takeIf { it in THEMES } ?: "None"; hue = st.themeHue }
  private fun defHue() = when (theme) { "Aurora" -> 165f; "Bubbles" -> 200f; "Neon grid" -> 320f; "Sunset plains" -> 22f; "Lab" -> 150f; "Matrix" -> 125f; "Rainy night" -> 215f; "Snowfall" -> 200f; "Deep sea" -> 195f; "Galaxy" -> 265f; else -> 215f }
  val baseHue: Float get() = if (hue < 0f) defHue() else hue
  val effHue: Float get() = if (theme == "Sunset plains") (baseHue + 180f * night) % 360f else baseHue   // at night the sunset flips to the opposite colors
  private val on get() = theme != "None"
  val style: String get() = when (theme) { "Aurora", "Rainy night", "Galaxy" -> "Aurora"; "Bubbles", "Snowfall", "Deep sea" -> "Bubbles"; "Neon grid", "Lab", "Matrix" -> "Neon grid"; "Sunset plains" -> "Sunset plains"; else -> "None" }
  val accent: Color get() = if (on || hue >= 0f) Color.hsv(effHue, .6f, 1f) else Color.White
  val second: Color get() = Color.hsv((effHue + 35f) % 360f, .6f, 1f)
  val card: Color get() = if (on) Color.hsv(effHue, .14f, .16f) else if (hue >= 0f) Color.hsv(hue, .12f, .105f) else Color(0xFF1A1A1A)
  val card2: Color get() = if (on) Color.hsv(effHue, .16f, .24f) else if (hue >= 0f) Color.hsv(hue, .14f, .15f) else Color(0xFF222222)
  val nav: Color get() = if (on) Color.hsv(effHue, .22f, .10f) else if (hue >= 0f) Color.hsv(hue, .15f, .08f) else Color(0xFF111111)
  val bg: Color get() = if (on) Color.hsv(effHue, .35f, .05f) else Color.Black
  fun fam(k: Float): Color = Color.hsv(((effHue + (k - .5f) * 70f) + 360f) % 360f, .65f, 1f)   // a color from the family, k = 0..1
  val chipShape: Shape get() = when (style) { "Neon grid" -> RoundedCornerShape(2.dp); "Sunset plains" -> RoundedCornerShape(24.dp); else -> RoundedCornerShape(50) }
}

private fun rnd(i: Int, k: Int): Float { val v = sin(i * 12.9898f + k * 78.233f) * 43758.547f; return v - floor(v) }

// Sunset plains runs one full day: the sun rises, crosses and sets, then the moon does the same
const val DAY_LEN = 160f
fun nightF(t: Float): Float { val s = sin(((t / DAY_LEN) % 1f) * 6.2832f); return (.5f - s * 1.6f).coerceIn(0f, 1f) }
// x (0..1 across), height (0..1) and whether it's the sun
fun celestial(t: Float): Triple<Float, Float, Boolean> { val p = (t / DAY_LEN) % 1f; val sun = p < .5f; val u = if (sun) p * 2f else (p - .5f) * 2f; return Triple(.08f + .84f * u, sin(3.1416f * u), sun) }

private fun DrawScope.orca(cx: Float, cy: Float, len: Float, dir: Float, t: Float, body: Color, light: Color) {
  val wag = sin(t * 1.4f) * len * .03f
  translate2(cx, cy) {
    val p = Path(); p.moveTo(len * .5f * dir, 0f); p.cubicTo(len * .3f * dir, -len * .14f, len * .05f * dir, -len * .17f, -len * .2f * dir, -len * .1f)
    p.cubicTo(-len * .35f * dir, -len * .05f, -len * .42f * dir, wag * .5f, -len * .5f * dir, wag); p.cubicTo(-len * .42f * dir, len * .04f + wag * .5f, -len * .3f * dir, len * .09f, -len * .1f * dir, len * .11f)
    p.cubicTo(len * .15f * dir, len * .13f, len * .4f * dir, len * .08f, len * .5f * dir, 0f); p.close(); drawPath(p, body)
    val fin = Path(); fin.moveTo(len * .02f * dir, -len * .14f); fin.lineTo(-len * .08f * dir, -len * .31f); fin.lineTo(-len * .15f * dir, -len * .11f); fin.close(); drawPath(fin, body)
    val tail = Path(); tail.moveTo(-len * .46f * dir, wag); tail.lineTo(-len * .6f * dir, wag - len * .1f); tail.lineTo(-len * .55f * dir, wag); tail.lineTo(-len * .6f * dir, wag + len * .1f); tail.close(); drawPath(tail, body)
    drawOval(light.copy(alpha = .8f), Offset(-len * .1f * dir - len * .09f, len * .03f), Size(len * .25f, len * .06f))   // pale belly patch
    drawOval(light.copy(alpha = .9f), Offset(len * .22f * dir - len * .035f, -len * .045f), Size(len * .07f, len * .035f)) }   // eye patch
}
private inline fun DrawScope.translate2(x: Float, y: Float, block: DrawScope.() -> Unit) = translate(x, y, block)

private fun DrawScope.squid(cx: Float, cy: Float, len: Float, t: Float, body: Color, glow: Color) {
  translate2(cx, cy + sin(t * .6f) * len * .08f) {
    val m = Path(); m.moveTo(0f, -len * .5f); m.cubicTo(len * .1f, -len * .35f, len * .1f, -len * .15f, len * .06f, 0f); m.lineTo(-len * .06f, 0f); m.cubicTo(-len * .1f, -len * .15f, -len * .1f, -len * .35f, 0f, -len * .5f); m.close(); drawPath(m, body)
    val f = Path(); f.moveTo(0f, -len * .5f); f.lineTo(len * .12f, -len * .4f); f.lineTo(0f, -len * .34f); f.lineTo(-len * .12f, -len * .4f); f.close(); drawPath(f, body)
    drawCircle(body, len * .07f, Offset(0f, len * .02f)); drawCircle(glow.copy(alpha = .9f), len * .018f, Offset(-len * .035f, len * .02f)); drawCircle(glow.copy(alpha = .9f), len * .018f, Offset(len * .035f, len * .02f))
    for (i in 0 until 8) { val x0 = (i - 3.5f) * len * .016f; val sw = sin(t * 1.2f + i) * len * .06f; val tp = Path(); tp.moveTo(x0, len * .06f); tp.quadraticBezierTo(x0 + sw, len * .22f, x0 * 2f + sin(t * 1.2f + i + 1f) * len * .09f, len * (.34f + .04f * (i % 2)))
      drawPath(tp, body, style = Stroke(len * .012f)) }
    for (s in listOf(-1f, 1f)) { val tp = Path(); tp.moveTo(s * len * .02f, len * .06f); tp.quadraticBezierTo(s * len * .08f + sin(t + s) * len * .06f, len * .3f, s * len * .04f + sin(t * .9f + s) * len * .1f, len * .6f); drawPath(tp, body, style = Stroke(len * .008f)) } }
}
private fun DrawScope.angler(cx: Float, cy: Float, len: Float, t: Float, body: Color, glow: Color) {
  translate2(cx, cy + sin(t * .5f) * len * .05f) {
    drawOval(body, Offset(-len * .3f, -len * .22f), Size(len * .6f, len * .44f)); val tail = Path(); tail.moveTo(len * .26f, 0f); tail.lineTo(len * .46f, -len * .14f); tail.lineTo(len * .46f, len * .14f); tail.close(); drawPath(tail, body)
    for (i in 0 until 6) { val x = -len * .3f + i * len * .045f; val tp = Path(); tp.moveTo(x, len * .02f); tp.lineTo(x + len * .02f, len * .1f); tp.lineTo(x + len * .04f, len * .02f); tp.close(); drawPath(tp, glow.copy(alpha = .8f)) }
    val st = Path(); st.moveTo(-len * .15f, -len * .2f); st.quadraticBezierTo(-len * .3f, -len * .45f, -len * .45f, -len * .3f + sin(t * 2f) * len * .02f); drawPath(st, body, style = Stroke(len * .012f))
    val lx = -len * .45f; val ly = -len * .3f + sin(t * 2f) * len * .02f; drawCircle(Brush.radialGradient(listOf(glow.copy(alpha = .9f), Color.Transparent), Offset(lx, ly), len * .22f), len * .22f, Offset(lx, ly)); drawCircle(Color.White, len * .02f, Offset(lx, ly))
    drawCircle(glow.copy(alpha = .9f), len * .02f, Offset(-len * .2f, -len * .05f)) }
}

// Draws one theme at time t (seconds). Everything moves slowly and keeps going.
fun DrawScope.drawTheme(name: String, t: Float) {
  val w = size.width; val h = size.height; val a = Th.fam(.15f); val b = Th.fam(.5f); val c = Th.fam(.85f)
  when (name) {
    "Aurora" -> for (i in 0 until 4) { val p = Path(); val base = h * (.16f + .12f * i); p.moveTo(0f, base); var x = 0f
      while (x <= w) { p.lineTo(x, base + sin(x / w * 6f + t * (.35f + .12f * i) + i) * h * .05f); x += 12f }
      p.lineTo(w, base + h * .24f); p.lineTo(0f, base + h * .24f); p.close()
      drawPath(p, Brush.verticalGradient(listOf((if (i % 2 == 0) a else c).copy(alpha = .30f), Color.Transparent), startY = base - h * .05f, endY = base + h * .24f)) }
    "Bubbles" -> for (i in 0 until 16) { val r = w * (.02f + .05f * rnd(i, 1)); val x = w * (rnd(i, 2) + .03f * sin(t * .5f + i)); val y = h + r - ((t * (.04f + .04f * rnd(i, 3)) + rnd(i, 4)) % 1f) * (h + 2f * r)
      val col = if (i % 2 == 0) a else c; drawCircle(col.copy(alpha = .09f), r, Offset(x, y)); drawCircle(col.copy(alpha = .35f), r, Offset(x, y), style = Stroke(1.5.dp.toPx())) }
    "Neon grid" -> { val hy = h * .52f; val warm = Color.hsv((Th.effHue + 75f) % 360f, .85f, 1f); val hot = Color.hsv((Th.effHue + 40f) % 360f, .95f, .85f)
      drawRect(Brush.verticalGradient(listOf(Color.Black, Th.bg, hot.copy(alpha = .4f)), startY = 0f, endY = hy), size = Size(w, hy))
      val r = w * .30f; val cx = w * .52f; val cy = hy - r * .30f   // the striped sun
      drawCircle(Brush.radialGradient(listOf(hot.copy(alpha = .35f), Color.Transparent), Offset(cx, cy), r * 1.6f), r * 1.6f, Offset(cx, cy))
      clipPath(Path().apply { addOval(Rect(Offset(cx, cy), r)) }) { var y = cy - r; var i = 0; while (y < cy + r) { val bh = 3.dp.toPx(); drawRect(lerp(warm, hot, ((y - (cy - r)) / (2f * r)).coerceIn(0f, 1f)), Offset(cx - r, y), Size(2f * r, bh)); y += bh + (1.2f + i * .3f).dp.toPx(); i++ } }
      // a wire mesh of mountains that scrolls toward you, nearer ones hiding what's behind
      val camZ = t * 1.4f; val dz = 1.5f; val rows = 24; val k = w * .6f; val camH = 3.2f; val z0 = 1.6f; val floorC = Th.fam(.85f); val peakC = Th.fam(.05f)
      fun ht(x: Float, zw: Float): Float { var s = 0f; val c0 = floor(zw / 14f).toInt(); for (cc in c0 - 1..c0 + 1) for (j in 0..1) { val id = cc * 2 + j; val px = (rnd(id, 1) - .5f) * 15f; val pz = cc * 14f + rnd(id, 2) * 14f; val amp = 1.2f + 3.2f * rnd(id, 3); val dx = x - px; val dzz = zw - pz; s += amp * exp(-(dx * dx / 3.5f + dzz * dzz / 7f)) }; return s }
      var prev: Array<Offset>? = null
      for (j in rows downTo 0) { val z = z0 + j * dz - (camZ % dz); val zw = z + camZ; var avg = 0f
        val pts = Array(25) { xi -> val x = (xi - 12) * .9f; val hg = ht(x, zw); avg += hg / 25f; Offset(w / 2f + x * k / z, hy + (camH - hg) * k / z) }
        val fill = Path().apply { moveTo(pts[0].x, h); pts.forEach { lineTo(it.x, it.y) }; lineTo(pts[24].x, h); close() }; drawPath(fill, Th.bg)
        val fade = (1f - j / rows.toFloat()).coerceIn(0f, 1f); val col = lerp(floorC, peakC, avg.coerceIn(0f, 1f))
        val rp = Path().apply { moveTo(pts[0].x, pts[0].y); for (i in 1 until 25) lineTo(pts[i].x, pts[i].y) }; drawPath(rp, col.copy(alpha = .25f + .6f * fade), style = Stroke(1.2.dp.toPx()))
        prev?.let { pv -> for (i in 0 until 25) drawLine(col.copy(alpha = .2f + .5f * fade), pv[i], pts[i], 1.dp.toPx()) }; prev = pts } }
    "Sunset plains" -> { val nf = nightF(t); val bh = Th.baseHue; val hy = h * .6f
      val dayTop = Color.hsv(bh, .6f, .22f); val dayMid = Color.hsv((bh + 20f) % 360f, .65f, .72f); val dayLow = Color.hsv((bh + 40f) % 360f, .45f, 1f)
      val nh = (bh + 180f) % 360f; val niTop = Color.hsv(nh, .6f, .05f); val niMid = Color.hsv((nh + 15f) % 360f, .55f, .20f); val niLow = Color.hsv((nh + 30f) % 360f, .45f, .38f)
      val low = lerp(dayLow, niLow, nf)
      drawRect(Brush.verticalGradient(listOf(lerp(dayTop, niTop, nf), lerp(dayMid, niMid, nf), low), startY = 0f, endY = hy + h * .03f), size = Size(w, hy + h * .04f))
      if (nf > .02f) for (i in 0 until 60) { val tw = .4f + .6f * (.5f + .5f * sin(t * (1f + rnd(i, 3) * 2f) + i)); drawCircle(Color.White.copy(alpha = nf * tw * .85f), (.7f + rnd(i, 4) * 1.4f).dp.toPx(), Offset(rnd(i, 1) * w, rnd(i, 2) * hy * .85f)) }
      val (cxf, elev, isSun) = celestial(t); val sr = w * .12f; val sx = w * cxf; val sy = hy + sr * .9f - elev * (h * .40f + sr * .9f)   // the sun or the moon arcs over, then dips below the horizon
      clipRect(0f, 0f, w, hy + h * .035f) {
        if (isSun) { drawCircle(Brush.radialGradient(listOf(low.copy(alpha = .75f), Color.Transparent), Offset(sx, sy), sr * 3.2f), sr * 3.2f, Offset(sx, sy)); drawCircle(Color.hsv((bh + 45f) % 360f, .22f, 1f), sr, Offset(sx, sy)) }
        else { drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha = .30f), Color.Transparent), Offset(sx, sy), sr * 2.6f), sr * 2.6f, Offset(sx, sy)); drawCircle(Color(0xFFEFF2FF), sr * .8f, Offset(sx, sy)); drawCircle(lerp(niMid, Color.Black, .25f), sr * .7f, Offset(sx + sr * .35f, sy - sr * .1f)) } }
      if (nf > .3f) { val ph = (t % 9f) / 1.3f; if (ph < 1f) { val x0 = w * (.95f - ph * .55f); val y0 = h * (.04f + ph * .25f); drawLine(Brush.linearGradient(listOf(Color.White.copy(alpha = (1f - ph) * nf), Color.Transparent), Offset(x0, y0), Offset(x0 + w * .16f, y0 - h * .07f)), Offset(x0, y0), Offset(x0 + w * .16f, y0 - h * .07f), 2.dp.toPx()) } }   // shooting stars at night
      if (nf < .95f) for (i in 0 until 6) { val cx = ((rnd(i, 1) * w + t * (3f + 5f * rnd(i, 2))) % (w + 260f)) - 130f; val cy = h * (.06f + .26f * rnd(i, 3)); val cw = w * (.14f + .16f * rnd(i, 4))   // clouds drift by day
        for (q in 0 until 4) drawOval(Color.White.copy(alpha = (1f - nf) * .22f), Offset(cx + q * cw * .22f, cy - (q % 2) * h * .006f), Size(cw * .5f, h * .02f)) }
      for (layer in 0 until 6) { val p = Path(); val base = hy + h * (.005f + .045f * layer); p.moveTo(0f, h); p.lineTo(0f, base); var x = 0f
        while (x <= w) { p.lineTo(x, base + sin(x / w * (2.5f + layer * .8f) + t * (.02f + .012f * layer) + layer * 2f) * h * (.012f + .005f * layer)); x += 10f }
        p.lineTo(w, h); p.close(); drawPath(p, lerp(Color.hsv((bh + 30f) % 360f, .5f, .38f - .05f * layer), Color.hsv((nh + 20f) % 360f, .5f, .13f - .015f * layer), nf)) }
      for (i in 0 until 70) { val gx = w * rnd(i, 7); val gy = hy + h * .22f + h * .16f * rnd(i, 8); val sway = sin(t * .8f + i) * 6f
        drawLine(lerp(Color.hsv((bh + 30f) % 360f, .5f, .14f), Color.hsv((nh + 20f) % 360f, .5f, .05f), nf), Offset(gx, gy), Offset(gx + sway, gy - h * .04f - h * .03f * rnd(i, 9)), 1.5.dp.toPx()) } }
    "Lab" -> { drawRect(Th.bg); var gx = 0f; while (gx < w) { drawLine(a.copy(alpha = .05f), Offset(gx, 0f), Offset(gx, h), 1.dp.toPx()); gx += 36.dp.toPx() }; var gy = 0f; while (gy < h) { drawLine(a.copy(alpha = .05f), Offset(0f, gy), Offset(w, gy), 1.dp.toPx()); gy += 36.dp.toPx() }
      for (f in 0 until 3) { val fx = w * (.2f + .3f * f); val fw = w * .15f; val fy = h * .93f; val liquid = if (f % 2 == 0) b else c   // bubbling flasks
        val fl = Path().apply { moveTo(fx - fw * .2f, fy - fw * 1.9f); lineTo(fx - fw * .2f, fy - fw * 1.1f); lineTo(fx - fw, fy); lineTo(fx + fw, fy); lineTo(fx + fw * .2f, fy - fw * 1.1f); lineTo(fx + fw * .2f, fy - fw * 1.9f) }
        clipPath(fl) { drawRect(liquid.copy(alpha = .22f), Offset(fx - fw, fy - fw * .75f), Size(fw * 2f, fw * .75f)); for (i in 0 until 6) { val bt = (t * (.25f + .1f * rnd(f * 7 + i, 1)) + rnd(f * 7 + i, 2)) % 1f; drawCircle(liquid.copy(alpha = .5f * (1f - bt)), (2f + 3f * rnd(i, f)).dp.toPx(), Offset(fx + (rnd(f * 7 + i, 3) - .5f) * fw * 1.2f + sin(t * 2f + i) * 4f, fy - bt * fw * 1.5f)) } }
        drawPath(fl, liquid.copy(alpha = .55f), style = Stroke(1.5.dp.toPx())) }
      val cx = w * .86f; var yy = h * .08f; while (yy < h * .72f) { val ph = yy * .03f + t * .8f; val x1 = cx + sin(ph) * w * .06f; val x2 = cx - sin(ph) * w * .06f   // a slowly turning DNA helix
        drawCircle(a.copy(alpha = .35f + .3f * cos(ph)), 2.5f.dp.toPx(), Offset(x1, yy)); drawCircle(c.copy(alpha = .35f - .3f * cos(ph)), 2.5f.dp.toPx(), Offset(x2, yy)); if ((yy / 8f).toInt() % 3 == 0) drawLine(b.copy(alpha = .25f), Offset(x1, yy), Offset(x2, yy), 1.dp.toPx()); yy += 8.dp.toPx() }
      for (m in 0 until 3) { val mx = w * (.3f + .4f * (.5f + .5f * sin(t * .1f + m * 2f))); val my = h * (.2f + .2f * m + .05f * sin(t * .13f + m)); val atoms = (0 until 4).map { i -> val an = t * .3f + i * 1.57f + m; Offset(mx + cos(an) * w * .07f, my + sin(an) * w * .07f) }   // drifting molecules
        atoms.forEach { drawLine(b.copy(alpha = .3f), Offset(mx, my), it, 1.5.dp.toPx()); drawCircle(a.copy(alpha = .5f), 4.dp.toPx(), it) }; drawCircle(c.copy(alpha = .6f), 6.dp.toPx(), Offset(mx, my)) }
      val sy = ((t * .12f) % 1f) * h; drawRect(Brush.verticalGradient(listOf(Color.Transparent, a.copy(alpha = .18f), Color.Transparent), startY = sy - 40f, endY = sy + 40f), Offset(0f, sy - 40f), Size(w, 80f)) }
    "Matrix" -> { drawRect(Th.bg); val cols = (w / 14.dp.toPx()).toInt().coerceAtLeast(4); val cw = w / cols; val chars = "01<>/|=+*#\$%&ABCDEFGHJKLMNPRSTUVWXYZ"
      val paint = android.graphics.Paint().apply { textSize = cw * .95f; typeface = android.graphics.Typeface.MONOSPACE }
      drawIntoCanvas { cv -> for (i in 0 until cols) { val speed = .15f + rnd(i, 1) * .35f; val head = ((t * speed + rnd(i, 2)) % 1f) * h * 1.4f; val len = 12 + (rnd(i, 3) * 14).toInt()
        for (j in 0 until len) { val y = head - j * cw * 1.1f; if (y < 0f || y > h) continue; val al = 1f - j / len.toFloat(); val col = if (j == 0) Color.White else Th.fam(.5f); paint.color = col.copy(alpha = al * .85f).toArgb()
          cv.nativeCanvas.drawText(chars[(i * 31 + j * 17 + (t * (3f + rnd(i, 4) * 4f)).toInt()) % chars.length].toString(), i * cw, y, paint) } } } }
    "Rainy night" -> { drawRect(Brush.verticalGradient(listOf(Th.bg, Th.fam(.3f).copy(alpha = .25f)), startY = 0f, endY = h)); drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha = .18f), Color.Transparent), Offset(w * .75f, h * .15f), w * .35f), w * .35f, Offset(w * .75f, h * .15f))
      for (i in 0 until 9) { val bw = w * (.09f + .07f * rnd(i, 1)); val bx = i * w / 8.5f - bw * .3f; val bh = h * (.18f + .2f * rnd(i, 2)); drawRect(Th.bg.copy(alpha = .95f), Offset(bx, h * .8f - bh), Size(bw, bh))
        for (r in 0 until 6) for (q in 0 until 3) if (rnd(i * 20 + r * 3 + q, 5) > .45f) drawRect(Th.fam(.6f).copy(alpha = if (rnd(i * 20 + r * 3 + q, 6) > .9f) (.2f + .5f * (.5f + .5f * sin(t * 2f + r))) else .5f), Offset(bx + bw * (.12f + .3f * q), h * .8f - bh + bh * (.1f + .14f * r)), Size(bw * .16f, bh * .06f)) }
      drawRect(Th.bg, Offset(0f, h * .8f), Size(w, h * .2f))
      for (i in 0 until 5) { val rt = (t * .7f + rnd(i, 7)) % 1f; val rr = rt * w * .08f; drawOval(Color.White.copy(alpha = .25f * (1f - rt)), Offset(w * rnd(i, 8) - rr, h * (.84f + .13f * rnd(i, 9)) - rr * .25f), Size(rr * 2f, rr * .5f), style = Stroke(1.dp.toPx())) }
      for (i in 0 until 110) { val x = (rnd(i, 1) * w * 1.2f + t * 40f) % (w * 1.2f) - w * .1f; val y = ((rnd(i, 2) + t * (.7f + rnd(i, 3) * .5f)) % 1f) * h; drawLine(Color.White.copy(alpha = .22f), Offset(x, y), Offset(x - 5.dp.toPx(), y + 14.dp.toPx()), 1.dp.toPx()) }
      if (rnd(floor(t / 7f).toInt(), 11) > .6f && (t % 7f) < .18f) drawRect(Color.White.copy(alpha = .10f)) }
    "Snowfall" -> { drawRect(Brush.verticalGradient(listOf(Th.bg, Th.fam(.4f).copy(alpha = .22f)), startY = 0f, endY = h))
      for (i in 0 until 10) { val tx = w * (i / 9.5f); val th = h * (.12f + .1f * rnd(i, 1)); val tw = w * .12f; val col = lerp(Th.bg, Th.fam(.5f), .12f); for (q in 0 until 3) { val p = Path().apply { moveTo(tx, h * .86f - th + q * th * .28f); lineTo(tx - tw * (.5f + q * .22f), h * .86f - th * .72f + q * th * .3f); lineTo(tx + tw * (.5f + q * .22f), h * .86f - th * .72f + q * th * .3f); close() }; drawPath(p, col) } }
      val g = Path().apply { moveTo(0f, h); lineTo(0f, h * .9f); var x = 0f; while (x <= w) { lineTo(x, h * .9f + sin(x / w * 5f) * h * .012f); x += 12f }; lineTo(w, h); close() }; drawPath(g, Color.White.copy(alpha = .75f))
      for (layer in 0 until 3) for (i in 0 until 26 - layer * 5) { val sp = .03f + .03f * layer + .02f * rnd(i, layer); val x = w * rnd(i, 20 + layer) + sin(t * .7f + i) * 18f; val y = ((rnd(i, 30 + layer) + t * sp) % 1f) * h; drawCircle(Color.White.copy(alpha = .5f + .15f * layer), (1.2f + layer * 1.1f).dp.toPx(), Offset(x, y)) } }
    "Deep sea" -> { drawRect(Brush.verticalGradient(listOf(Th.fam(.5f).copy(alpha = .30f), Th.bg), startY = 0f, endY = h)); val dark = lerp(Th.bg, Color.Black, .5f)
      for (i in 0 until 5) { val rx = w * (.1f + .2f * i) + sin(t * .2f + i) * w * .05f; val p = Path().apply { moveTo(rx, 0f); lineTo(rx + w * .08f, 0f); lineTo(rx + w * .2f + sin(t * .15f + i) * 30f, h * .75f); lineTo(rx - w * .04f + sin(t * .15f + i) * 30f, h * .75f); close() }; drawPath(p, Brush.verticalGradient(listOf(Th.fam(.6f).copy(alpha = .13f), Color.Transparent), startY = 0f, endY = h * .75f)) }   // light from above
      val wx = ((t * .012f) % 1.6f - .3f) * w; val wy = h * .2f; translate2(wx, wy) { drawOval(dark.copy(alpha = .55f), Offset(-w * .3f, -h * .035f), Size(w * .6f, h * .07f)); val tl = Path().apply { moveTo(-w * .28f, 0f); lineTo(-w * .4f, -h * .05f + sin(t * .5f) * h * .01f); lineTo(-w * .4f, h * .05f + sin(t * .5f) * h * .01f); close() }; drawPath(tl, dark.copy(alpha = .55f)) }   // a huge whale far off
      orca(((t * .035f) % 1.5f - .25f) * w, h * .38f + sin(t * .3f) * h * .015f, w * .5f, 1f, t, dark, Color.White.copy(alpha = .5f))
      orca(w * 1.2f - ((t * .028f + .5f) % 1.5f) * w, h * .52f + sin(t * .35f + 1f) * h * .015f, w * .34f, -1f, t, dark, Color.White.copy(alpha = .4f))
      squid(w * (.3f + .25f * sin(t * .06f)), h * .68f + sin(t * .22f) * h * .05f, h * .3f, t, dark, c)
      angler(w * (.75f + .08f * sin(t * .1f)), h * .86f, w * .3f, t, dark, c)
      for (i in 0 until 7) { val kx = w * (i / 6.5f); val kh = h * (.14f + .1f * rnd(i, 1)); val p = Path(); p.moveTo(kx, h); var y = h; while (y > h - kh) { p.lineTo(kx + sin(y * .02f + t * .7f + i) * 10f, y); y -= 8f }; drawPath(p, dark, style = Stroke(5.dp.toPx())) }
      for (i in 0 until 50) { val x = w * rnd(i, 1) + sin(t * .3f + i) * 8f; val y = ((rnd(i, 2) - t * .01f * (1f + rnd(i, 3))) % 1f + 1f) % 1f * h; drawCircle(Color.White.copy(alpha = .18f + .15f * rnd(i, 4)), (.7f + rnd(i, 5)).dp.toPx(), Offset(x, y)) } }
    "Galaxy" -> { drawRect(Th.bg); for (i in 0 until 70) { val tw = .3f + .7f * (.5f + .5f * sin(t * (1f + rnd(i, 3) * 2f) + i)); drawCircle(Color.White.copy(alpha = tw * .6f), (.6f + rnd(i, 4) * 1.3f).dp.toPx(), Offset(rnd(i, 1) * w, rnd(i, 2) * h)) }
      val gx = w * .5f; val gy = h * .42f; val rr = w * .5f; drawCircle(Brush.radialGradient(listOf(Th.fam(.55f).copy(alpha = .55f), Color.Transparent), Offset(gx, gy), rr * .5f), rr * .5f, Offset(gx, gy))
      for (i in 0 until 900) { val arm = i % 3; val rad = Math.pow(rnd(i, 1).toDouble(), .7).toFloat() * rr; val an = arm * 2.094f + rad / rr * 3.4f + t * .035f + (rnd(i, 2) - .5f) * .5f; val x = gx + cos(an) * rad; val y = gy + sin(an) * rad * .5f
        drawCircle(lerp(Color(0xFFFFF1D0), Th.fam(rnd(i, 3)), (rad / rr).coerceIn(0f, 1f)).copy(alpha = .75f * (1f - rad / rr * .6f)), (.5f + rnd(i, 4) * 1.3f).dp.toPx(), Offset(x, y)) } }
  }
}

@Composable fun themeClock(active: Boolean): State<Float> { val t = remember { mutableFloatStateOf(0f) }
  LaunchedEffect(active) { if (active) { var last = 0L; while (true) { val n = withFrameNanos { it }; if (last != 0L) t.floatValue += (n - last) / 1e9f; last = n } } }
  return t }

// behind every page. The picture is recorded once into a layer, so the glass panels can show a blurred copy of it cheaply.
@Composable fun ThemeBackground(t: State<Float>, layer: GraphicsLayer) {
  LaunchedEffect(Th.theme) { snapshotFlow { t.value }.collect { if (Th.theme == "Sunset plains") { val nf = nightF(it); if (abs(nf - Th.night) >= .02f) Th.night = nf } else if (Th.night != 0f) Th.night = 0f } }   // the sunset's day and night change the app's colors
  Box(Modifier.fillMaxSize().drawWithContent { layer.record(this, layoutDirection, IntSize(size.width.toInt(), size.height.toInt())) { drawRect(Th.bg); if (Th.theme != "None") drawTheme(Th.theme, t.value) }; drawLayer(layer) }) }

// Settings > Theme: pick a theme, then a color. A small live preview shows the choice.
@Composable fun ThemeSettings() {
  val c = LocalContext.current; val st = remember { Store(c) }; val t = themeClock(Th.theme != "None")
  Text("Theme", color = Color.Gray); Row(Modifier.horizontalScroll(rememberScrollState())) { THEMES.forEach { Pick(it, Th.theme == it) { Th.theme = it; st.theme = it } } }
  Box(Modifier.fillMaxWidth().height(140.dp).clip(RoundedCornerShape(16.dp)).background(Th.bg), Alignment.Center) {
    if (Th.theme != "None") Canvas(Modifier.fillMaxSize()) { drawTheme(Th.theme, t.value) }
    Text(if (Th.theme == "None") "None: the plain black pages" else Th.theme, color = Color.White, fontSize = 14.sp) }
  Text("Color", color = Color.Gray); ThemeColorRow(st)
  Text(if (Th.theme == "None") "On None, the color sets the highlights: buttons, chips, sliders and the tab bar. Pick a theme to also color its background." else "The color sets a family of colors close to it for the background. Pages and cards stay nearly neutral, and only highlights use the strong color. Your groups keep their own colors.", color = Color.Gray, fontSize = 12.sp)
}

// the X is the default; then 23 colors, six to a row, a full block
@OptIn(ExperimentalLayoutApi::class)
@Composable fun ThemeColorRow(st: Store) { FlowRow(maxItemsInEachRow = 6) {
  val sel = Th.hue < 0f
  Box(Modifier.padding(4.dp).size(44.dp).clip(CircleShape).background(Th.card2).border(if (sel) 3.dp else 1.dp, if (sel) Color.White else Color.DarkGray, CircleShape).clickable { Th.hue = -1f; st.themeHue = -1f }, Alignment.Center) { Ico("close", 20.dp, Color.White) }
  THEME_HUES.forEach { hu -> val on = Th.hue == hu
    Box(Modifier.padding(4.dp).size(44.dp).clip(CircleShape).background(Color.hsv(hu, .6f, 1f)).border(if (on) 3.dp else 1.dp, if (on) Color.White else Color.DarkGray, CircleShape).clickable { Th.hue = hu; st.themeHue = hu }) } } }
