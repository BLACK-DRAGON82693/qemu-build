package com.finite.functions
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.os.Bundle
import android.widget.RemoteViews
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.edit
import androidx.core.graphics.createBitmap

class GroupWidget : AppWidgetProvider() {
  override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { ids.forEach { drawWidget(c, m, it) } }
  override fun onAppWidgetOptionsChanged(c: Context, m: AppWidgetManager, id: Int, o: Bundle) { drawWidget(c, m, id) }
  override fun onDeleted(c: Context, ids: IntArray) { Store(c).p.edit { ids.forEach { remove("w$it") } } }
}

// Placing a widget asks which group it shows (or uses the group you pressed "Add widget" on)
class WidgetConfig : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState); val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, 0); setResult(RESULT_CANCELED)
    val st = Store(this)
    fun bind(gid: String) { st.p.edit { putString("w$id", gid); remove("pending") }; drawWidget(this, AppWidgetManager.getInstance(this), id)
      setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)); finish() }
    st.p.getString("w$id", null)?.let { bind(it); return }
    st.p.getString("pending", null)?.let { bind(it); return }
    val gs = st.groups(); if (gs.isEmpty()) { Toast.makeText(this, "Make a group first", Toast.LENGTH_LONG).show(); finish(); return }
    setContent { MaterialTheme(colorScheme = darkColorScheme(primary = androidx.compose.ui.graphics.Color.White)) { Column(Modifier.fillMaxSize().padding(24.dp)) {
      Text("Choose a group"); gs.forEach { (gid, name) -> Text(name, modifier = Modifier.fillMaxWidth().clickable { bind(gid) }.padding(16.dp)) } } } }
  }
}

fun Context.addWidget(g: Group) {
  val m = AppWidgetManager.getInstance(this)
  if (!m.isRequestPinAppWidgetSupported) { Toast.makeText(this, "Your launcher can't add widgets from here. Use the widget picker.", Toast.LENGTH_LONG).show(); return }
  Store(this).p.edit { putString("pending", g.id) }; m.requestPinAppWidget(ComponentName(this, GroupWidget::class.java), null, PendingIntent.getBroadcast(this, 0, Intent(this, WidgetPinned::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE))
}
fun Context.refreshWidgets() { val m = AppWidgetManager.getInstance(this); m.getAppWidgetIds(ComponentName(this, GroupWidget::class.java)).forEach { drawWidget(this, m, it) } }

fun drawWidget(c: Context, m: AppWidgetManager, id: Int) {
  val st = Store(c); if (st.p.getString("w$id", null) == null) st.p.getString("pending", null)?.let { st.p.edit { putString("w$id", it); remove("pending") } }
  val g = st.groups().firstOrNull { it.id == st.p.getString("w$id", "") } ?: return
  val o = m.getAppWidgetOptions(id); val d = c.resources.displayMetrics.density
  var w = (o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 72) * d).toInt().coerceAtLeast(60); var h = (o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 72) * d).toInt().coerceAtLeast(60)
  val k = minOf(1f, 360f / maxOf(w, h)); w = (w * k).toInt(); h = (h * k).toInt()
  val rv = RemoteViews(c.packageName, R.layout.widget); rv.setImageViewBitmap(R.id.img, c.widgetBitmap(g, w, h))
  val i = Intent(c, GroupActivity::class.java).putExtra("id", g.id).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
  rv.setOnClickPendingIntent(R.id.img, PendingIntent.getActivity(c, id, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
  m.updateAppWidget(id, rv)
}

// Soft = rounded square, Sharp = square, Circle, Rectangle = fills the whole (stretched) widget
fun Context.widgetBitmap(g: Group, w: Int, h: Int): Bitmap {
  val b = createBitmap(w, h); val c = Canvas(b); val m = minOf(w, h).toFloat(); val cx = w / 2f; val cy = h / 2f; val path = Path()
  when (g.wshape) { "Circle" -> path.addCircle(cx, cy, m / 2, Path.Direction.CW); "Sharp" -> path.addRect(cx - (m / 2), cy - (m / 2), cx + (m / 2), cy + (m / 2), Path.Direction.CW)
    "Rectangle" -> path.addRoundRect(0f, 0f, w.toFloat(), h.toFloat(), m * .18f, m * .18f, Path.Direction.CW)
    else -> path.addRoundRect(cx - (m / 2), cy - (m / 2), cx + (m / 2), cy + (m / 2), m * .22f, m * .22f, Path.Direction.CW) }
  c.clipPath(path); val src = groupBitmap(g); val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
  if (g.mode == "Picture") { val s = maxOf(w, h) / 2f; c.drawBitmap(src, null, RectF(cx - s, cy - s, cx + s, cy + s), p) }
  else { c.drawColor(g.icolor.toInt()); c.drawBitmap(src, null, RectF(cx - (m / 2), cy - (m / 2), cx + (m / 2), cy + (m / 2)), p) }
  return b
}

// The launcher reports the new widget's id here, so a widget placed with the button is linked right away
class WidgetPinned : BroadcastReceiver() {
  override fun onReceive(c: Context, i: Intent) { val id = i.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, 0); val st = Store(c); val gid = st.p.getString("pending", null) ?: return
    if (id != 0) { st.p.edit { putString("w$id", gid); remove("pending") }; drawWidget(c, AppWidgetManager.getInstance(c), id) } }
}
