package com.finite.functions
import android.app.StatusBarManager
import android.content.ComponentName
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File
import kotlinx.coroutines.launch
import android.graphics.drawable.Icon
import android.os.Build
import android.widget.Toast
import androidx.core.content.ContextCompat
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.zIndex
import kotlin.math.roundToInt
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
  override fun onStop() { super.onStop(); Backup.flush(this) }   // save everything as the app leaves the screen
  override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); Th.load(Store(this)); setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Th.accent, onPrimary = Color.Black, secondaryContainer = Th.card2)) { MainApp() } } }
}

@Composable fun MainApp() {
  var tab by remember { mutableStateOf(2) }
  val clock = themeClock(Th.theme != "None"); val layer = rememberGraphicsLayer()
  CompositionLocalProvider(LocalThemeT provides clock, LocalBackdrop provides layer) { Box(Modifier.fillMaxSize().background(Th.bg)) { ThemeBackground(clock, layer)
  Scaffold(containerColor = Color.Transparent, bottomBar = {
    if (Th.theme != "None") ThemedNavBar(tab) { tab = it } else NavigationBar(containerColor = Th.nav) {
      listOf("Tools", "Library", "Music", "Groups", "Settings").forEachIndexed { i, t -> NavigationBarItem(tab == i, { tab = i }, { Ico(listOf("wrench", "folder", "music", "grid", "info")[i], modifier = if (i == 3) Modifier.graphicsLayer { rotationZ = 45f; scaleX = .78f; scaleY = .78f } else Modifier) }, label = { Text(t) }) } } }) { pad ->
    Box(Modifier.padding(pad).fillMaxSize().padding(16.dp)) { AnimatedContent(tab, transitionSpec = { themeTransition(initialState, targetState) }, label = "section") { t -> when (t) { 0 -> ToolsTab(); 1 -> FilesTab(); 2 -> LibraryTab(); 3 -> GroupsTab(); else -> InfoTab() } } } } } }
}

@Composable fun InfoTab() {
  val c = LocalContext.current
  Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
    Text("Settings", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    Req("Notifications", "Lets music keep playing with lock screen controls.") { c.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, c.packageName)) }
    Req("Unrestricted battery", "Keeps music playing with the screen off.") { c.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
    var qsOpen by remember { mutableStateOf(false) }; var thOpen by remember { mutableStateOf(false) }
    SecHead("Quick settings", qsOpen) { qsOpen = !qsOpen }
    if (qsOpen) Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
    var sn by remember { mutableStateOf(Store(c).showNames) }
    Sw("Show group names in the quick settings overlay", sn) { sn = it; Store(c).showNames = it }
    var ts by remember { mutableStateOf(Store(c).tileSize) }; var stk by remember { mutableStateOf(Store(c).tileStack) }; var cov by remember { mutableStateOf(Store(c).tileCover) }
    Text("Tile icon size ${(ts * 100).toInt()}%", color = Color.Gray); TSlider(ts, { ts = it; Store(c).tileSize = it }, Modifier.fillMaxWidth(), valueRange = .5f..2f)
    Text("How the group icons stack", color = Color.Gray); Row { listOf("Grid", "Vertical", "Horizontal").forEach { Pick(it, it == stk) { stk = it; Store(c).tileStack = it } } }
    Text("How much of the screen the tile overlay covers", color = Color.Gray); Row(Modifier.horizontalScroll(rememberScrollState())) { listOf("Full", "Top half", "Bottom half", "Left half", "Right half").forEach { Pick(it, it == cov) { cov = it; Store(c).tileCover = it } } }
    TileOrder()
    Req("Quick settings tile", "Adds the Finite Functions tile. It opens an overlay with all your groups.") {
      if (Build.VERSION.SDK_INT >= 33) c.getSystemService(StatusBarManager::class.java).requestAddTileService(ComponentName(c, GroupsTile::class.java), "Finite Functions", Icon.createWithResource(c, R.drawable.ic_tile), ContextCompat.getMainExecutor(c)) { }
      else Toast.makeText(c, "Swipe down twice, tap the pencil, and drag Finite Functions into your tiles", Toast.LENGTH_LONG).show() }
    }
    SecHead("Theme", thOpen) { thOpen = !thOpen }
    if (thOpen) Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(14.dp)) { ThemeSettings() }
    Text("Adding files to Library", color = Color.Gray); var lm by remember { mutableStateOf(Store(c).libMode) }
    Row(Modifier.horizontalScroll(rememberScrollState())) { Pick("Move into the app's folder", lm == "Move") { lm = "Move"; Store(c).libMode = "Move" }; Pick("Shortcut only", lm == "Shortcut") { lm = "Shortcut"; Store(c).libMode = "Shortcut" } }
    Text("Backup", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    val lastSave = File(c.filesDir, "backup.json").lastModified()
    Text(if (lastSave > 0) "Saved automatically. Last save: " + java.text.DateFormat.getDateTimeInstance().format(java.util.Date(lastSave)) else "Saved automatically as you make changes.", color = Color.Gray, fontSize = 13.sp)
    val folderPick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u -> if (u != null) { c.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION); Store(c).p.edit().putString("bkdir", u.toString()).apply(); Backup.flush(c); LibMirror.changed(c) } }
    var rc by remember { mutableStateOf(false) }
    Req("Backup folder", "A second copy that survives uninstalling. Pick it now, and again on a new install before Reconnect.") { folderPick.launch(null) }
    var ms by remember { mutableStateOf("") }; LaunchedEffect(Unit) { while (true) { ms = Store(c).p.getString("mirrorstat", "") ?: ""; kotlinx.coroutines.delay(1000) } }
    if (ms.isNotEmpty() && Backup.folder(c) != null) Text("Library copy in the folder: ${ms.replace("/", " of ")} files", color = Color.Gray, fontSize = 13.sp)
    Req("Reconnect", "After a reinstall: brings back your colors, groups and playlists and finds your songs again.") { rc = true }
    if (rc) ReconnectCard { rc = false }
    Text("Android asks you to confirm each widget and quick settings tile you add. Background blur needs Android 12+ with window blur enabled on your phone.", color = Color.Gray, fontSize = 13.sp)
  }
}

@Composable fun Req(t: String, d: String, go: () -> Unit) {
  Row(Modifier.fillMaxWidth().border(1.dp, Color.DarkGray, RoundedCornerShape(16.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
    Column(Modifier.weight(1f)) { Text(t, color = Color.White, fontWeight = FontWeight.Bold); Text(d, color = Color.Gray, fontSize = 13.sp) }
    TTextButton(go) { Text("Open") } }
}

// Hold a group and drag it to change where it sits in the tile overlay
@Composable fun TileOrder() {
  val c = LocalContext.current; val st = remember { Store(c) }; var gs by remember { mutableStateOf(st.orderedGroups()) }
  var dragI by remember { mutableStateOf(-1) }; var dy by remember { mutableStateOf(0f) }; val h = with(LocalDensity.current) { 58.dp.toPx() }
  Text("Order of the groups in the tile (hold and drag)", color = Color.Gray)
  Column { gs.forEachIndexed { i, g -> val on = dragI == i
    Row(Modifier.fillMaxWidth().height(52.dp).zIndex(if (on) 1f else 0f).graphicsLayer { translationY = if (on) dy else 0f }.clip(RoundedCornerShape(14.dp)).background(if (on) Color(0xFF333333) else Th.card)
      .pointerInput(g.id) { detectDragGesturesAfterLongPress(onDragStart = { dragI = i; dy = 0f }, onDrag = { _, d -> dy += d.y },
        onDragEnd = { val to = (i + (dy / h).roundToInt()).coerceIn(0, gs.size - 1); if (to != i) { val l = gs.toMutableList(); l.add(to, l.removeAt(i)); gs = l; st.tileOrder = l.map { it.id } }; dragI = -1; dy = 0f },
        onDragCancel = { dragI = -1; dy = 0f }) }.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
      Image(remember(g) { c.groupBitmap(g).asImageBitmap() }, null, Modifier.size(36.dp).clip(CircleShape)); Text(g.name, color = Color.White, modifier = Modifier.padding(start = 12.dp)) }
    Spacer(Modifier.height(6.dp)) } }
}

@Composable fun RecRow(name: String, p: Float, note: String) = Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
  Box(Modifier.size(28.dp), Alignment.Center) { if (p >= 1f) Ico("check", 22.dp) else CircularProgressIndicator(progress = { p }, color = Color.White, trackColor = Color(0xFF333333), strokeWidth = 3.dp, modifier = Modifier.size(26.dp)) }
  Text(name, color = Color.White, modifier = Modifier.weight(1f).padding(start = 12.dp))
  Column(horizontalAlignment = Alignment.End) { Text("${(p * 100).toInt()}%", color = Color.White); if (note.isNotEmpty()) Text(note, color = Color.Gray, fontSize = 11.sp) } }

// The loading card: one ring and one percentage for each section
@Composable fun ReconnectCard(onClose: () -> Unit) {
  val c = LocalContext.current; val s = remember { RecState() }; val scope = rememberCoroutineScope()
  val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) scope.launch { Reconnect.run(c, s, true) } }
  val tree = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u -> if (u != null) { c.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION); Store(c).p.edit().putString("bkdir", u.toString()).apply(); scope.launch { Reconnect.run(c, s, false) } } }
  LaunchedEffect(Unit) { Reconnect.run(c, s, false) }
  CenterCard("Reconnecting", false, { }, locked = s.status == "run") {
    if (s.source.isNotEmpty()) Text("From the ${s.source}", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
    RecRow("Colors", s.colors, ""); RecRow("Groups", s.groups, ""); RecRow("Music", s.music, s.note)
    when (s.status) {
      "perm" -> { Text("Music needs the Music and audio permission to find your songs again.", color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp)); Row { TTextButton({ perm.launch(Backup.audioPerm()) }) { Text("Allow") }; TTextButton(onClose) { Text("Close") } } }
      "norec" -> { Text("No saved record found.", color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp)); Row { TTextButton({ tree.launch(null) }) { Text("Pick backup folder") }; TTextButton(onClose) { Text("Close") } } }
      "done" -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { TTextButton(onClose) { Text("Done") } } } }
}
