package com.finite.functions
import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.os.Build
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.zIndex
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import androidx.core.content.ContextCompat
import androidx.media3.common.*
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt
import java.util.Collections

// Where the carried songs land when dropped on row `over` (the grabbed row was `di`)
fun reorder(l: List<Song>, ids: Set<String>, over: Int, di: Int): List<Song> {
  val tgt = l.getOrNull(over) ?: return l.toList(); if (tgt.u in ids) return l.toList()   // always a copy, so a drop that changes nothing can never empty the playlist
  val moving = l.filter { it.u in ids }; val rest = l.filter { it.u !in ids }; val k = rest.indexOf(tgt) + (if (over > di) 1 else 0)
  return rest.take(k) + moving + rest.drop(k)
}
// Up and down move every selected song together
fun moveSel(l: MutableList<Song>, ids: Set<String>, dir: Int) { val idx = l.indices.filter { l[it].u in ids }; for (i in if (dir < 0) idx else idx.reversed()) { val j = i + dir; if (j in l.indices && l[j].u !in ids) Collections.swap(l, i, j) } }

@OptIn(ExperimentalFoundationApi::class)
@Composable fun Chip(t: String, on: Boolean, onLong: () -> Unit, modifier: Modifier = Modifier, hot: Boolean = false, font: FontFamily? = null, f: () -> Unit) = Text(t, color = chipText(on), fontFamily = font,
  modifier = modifier.padding(end = 6.dp).chipLook(on).then(if (hot) Modifier.border(2.dp, Color.White, RoundedCornerShape(50)) else Modifier)
    .combinedClickable(onLongClick = onLong, onClick = f).padding(horizontal = 14.dp, vertical = 8.dp))

// The cover picture, slid and zoomed: pos = [x, y, zoom], x and y run -1..1 across the part that overflows
@Composable fun CoverImg(img: ImageBitmap, pos: FloatArray, modifier: Modifier = Modifier) = Canvas(modifier) {
  val iw = img.width.toFloat(); val ih = img.height.toFloat(); val s0 = maxOf(size.width / iw, size.height / ih) * pos[2]; val dw = iw * s0; val dh = ih * s0
  val x = (size.width - dw) / 2 + pos[0] * (dw - size.width) / 2; val y = (size.height - dh) / 2 + pos[1] * (dh - size.height) / 2
  drawImage(img, IntOffset.Zero, IntSize(img.width, img.height), IntOffset(x.roundToInt(), y.roundToInt()), IntSize(dw.roundToInt(), dh.roundToInt()))
}

// Small popup next to whatever you touched; red for deleting
@Composable fun PopCard(at: Offset, origin: Offset, red: Boolean, title: String, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
  val cfg = LocalConfiguration.current; val dn = LocalDensity.current; val maxOff = with(dn) { (cfg.screenWidthDp.dp - 240.dp).toPx() } - origin.x; val o = at - origin
  Popup(alignment = Alignment.TopStart, offset = IntOffset(o.x.coerceIn(0f, maxOf(0f, maxOff)).roundToInt(), o.y.roundToInt()), onDismissRequest = onDismiss, properties = PopupProperties(focusable = true)) {
    Column(Modifier.widthIn(max = 230.dp).clip(RoundedCornerShape(16.dp)).background(if (red) Color(0xFF2A0F0F) else Color(0xFF1E1E1E)).border(1.dp, if (red) Color(0xFFB71C1C) else Color(0xFF444444), RoundedCornerShape(16.dp)).padding(8.dp)) {
      Text(title, color = if (red) Color(0xFFFF8A80) else Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(8.dp)); content() } }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable fun LibraryTab() {
  val ctx = LocalContext.current; val st = remember { Store(ctx) }; val dn = LocalDensity.current; val cfg = LocalConfiguration.current; val scope = rememberCoroutineScope()
  var lib by remember { mutableStateOf(st.lib()) }; var cur by remember { mutableStateOf("All") }; var covers by remember { mutableStateOf(st.effCovers()) }; var posVer by remember { mutableStateOf(0) }
  var ctrl by remember { mutableStateOf<MediaController?>(null) }; var playing by remember { mutableStateOf(false) }; var np by remember { mutableStateOf("") }; var shuf by remember { mutableStateOf(false) }
  var picked by remember { mutableStateOf(setOf<String>()) }
  var delSong by remember { mutableStateOf<Pair<Song, Offset>?>(null) }; var delList by remember { mutableStateOf<Pair<String, Offset>?>(null) }; var cvMenu by remember { mutableStateOf<Pair<Song, Offset>?>(null) }
  var coverTarget by remember { mutableStateOf<Song?>(null) }; var adj by remember { mutableStateOf<Song?>(null) }
  val listState = rememberLazyListState(); var dragU by remember { mutableStateOf<String?>(null) }; var dragRoot by remember { mutableStateOf(Offset.Zero) }; var carry by remember { mutableStateOf(setOf<String>()) }
  var listTop by remember { mutableStateOf(0f) }; var listBottom by remember { mutableStateOf(0f) }; var origin by remember { mutableStateOf(Offset.Zero) }; var lastEnd by remember { mutableStateOf(0L) }
  val chipRects = remember { mutableStateMapOf<String, Rect>() }; var pend by remember { mutableStateOf<Pair<String, Set<String>>?>(null) }; var pendAt by remember { mutableStateOf(Offset.Zero) }
  fun edit(f: (LinkedHashMap<String, MutableList<Song>>) -> Unit) { val m = st.lib(); f(m); st.saveLib(m); lib = m }
  DisposableEffect(Unit) {
    val f = MediaController.Builder(ctx, SessionToken(ctx, ComponentName(ctx, PlayerService::class.java))).buildAsync()
    f.addListener({ ctrl = f.get().also { c -> playing = c.isPlaying; c.addListener(object : Player.Listener { override fun onIsPlayingChanged(p: Boolean) { playing = p } }) } }, ContextCompat.getMainExecutor(ctx))
    onDispose { MediaController.releaseFuture(f) } }
  val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
  LaunchedEffect(Unit) { if (Build.VERSION.SDK_INT >= 33) notif.launch(Manifest.permission.POST_NOTIFICATIONS) }
  val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { us -> edit { m -> us.forEach { u ->
    ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
    val n = ctx.contentResolver.query(u, null, null, null, null)?.use { if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null } ?: "Track"
    val s = Song(u.toString(), n.substringBeforeLast('.'))
    for (k in listOf("All", cur)) m[k]?.let { if (it.none { x -> x.u == s.u }) it.add(s) } }
    scope.launch(Dispatchers.IO) { us.forEach { u -> val k = u.toString(); ctx.extractArt(k)?.let { e -> st.setEmbedded(k, e) }; ctx.refreshArt(k) }   // pick up album art from the new files
      st.p.edit().putStringSet("scanned", st.p.getStringSet("scanned", emptySet())!! + us.map { it.toString() }).apply(); covers = st.effCovers() } } }
  LaunchedEffect(Unit) { withContext(Dispatchers.IO) {   // once: pull album art out of songs you added earlier
    val done = st.p.getStringSet("scanned", emptySet())!!.toMutableSet(); var any = false
    for (s in st.lib()["All"] ?: emptyList()) { if (s.u in done) continue; done.add(s.u); ctx.extractArt(s.u)?.let { e -> st.setEmbedded(s.u, e); ctx.refreshArt(s.u); any = true }; if (any) { covers = st.effCovers(); any = false } }
    st.p.edit().putStringSet("scanned", done).apply() } }
  val coverPick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> val s = coverTarget
    if (u != null && s != null) { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); st.setCover(s.u, ctx.keepPic(u)); covers = st.effCovers(); posVer++; Thread { ctx.refreshArt(s.u) }.start() }; coverTarget = null }
  var pendingPlay by remember { mutableStateOf<Int?>(null) }
  fun play(i: Int) { val l = lib[cur]?.takeIf { it.isNotEmpty() } ?: return; val c = ctrl
    if (c == null) { pendingPlay = i; return }   // the player isn't connected yet: start as soon as it is, instead of losing the tap
    c.setMediaItems(l.map { MediaItem.Builder().setUri(it.u).setRequestMetadata(MediaItem.RequestMetadata.Builder().setMediaUri(android.net.Uri.parse(it.u)).build()).setMediaMetadata(MediaMetadata.Builder().setTitle(it.t).setArtist(if (cur == "All") "Finite Functions" else cur).setArtworkUri(st.artUri(it.u)).build()).build() }, i, 0L)
    c.repeatMode = Player.REPEAT_MODE_ALL; c.playWhenReady = true; c.prepare(); c.play()
    scope.launch { delay(800); if (c.mediaItemCount > 0 && !c.isPlaying && !c.playWhenReady && c.playbackState != Player.STATE_IDLE) c.play() } }   // if it still ended up paused, start it
  LaunchedEffect(ctrl, pendingPlay) { val p = pendingPlay; if (ctrl != null && p != null) { pendingPlay = null; play(p) } }
  fun nearest(): Int { val y = dragRoot.y - listTop; return listState.layoutInfo.visibleItemsInfo.minByOrNull { abs(y - (it.offset + it.size / 2f)) }?.index ?: -1 }
  fun sendTo(k: String, ids: Set<String>, copy: Boolean) { edit { m -> val src = (m[cur] ?: mutableListOf()).filter { it.u in ids }
    m[k]?.let { t -> src.forEach { s -> if (t.none { x -> x.u == s.u }) t.add(s) } }
    if (!copy && cur != "All" && k != cur) m[cur]?.removeAll { it.u in ids } }; picked = emptySet(); carry = emptySet() }
  // Dropped on a playlist chip: ask copy or move there. Dropped on the list: reorder. Barely moved: it was a long press, so select.
  fun finishDrag(total: Float, s: Song) {
    lastEnd = System.currentTimeMillis(); val u = dragU; dragU = null; val ids = carry
    if (total < 20f) { picked = if (s.u in picked) picked - s.u else picked + s.u; carry = emptySet(); return }
    val hit = chipRects.entries.firstOrNull { dragRoot in it.value }?.key
    if (hit != null) { pend = hit to ids; pendAt = dragRoot; return }
    val over = nearest()
    edit { m -> val l = m[cur] ?: return@edit; val n = reorder(l, ids, over, l.indexOfFirst { it.u == u }).toList(); if (n.size == l.size) { l.clear(); l.addAll(n) } }
    carry = emptySet(); picked = emptySet()
  }
  LaunchedEffect(dragU) { while (dragU != null) { val y = dragRoot.y; if (y < listTop + 90f) listState.scrollBy(-16f) else if (y > listBottom - 90f) listState.scrollBy(16f); delay(16) } }
  val songs = lib[cur] ?: emptyList(); val over = if (dragU != null) nearest() else -1; val di = songs.indexOfFirst { it.u == dragU }; val hover = if (dragU != null) chipRects.entries.firstOrNull { dragRoot in it.value }?.key else null
  val newIdx = if (dragU != null) reorder(songs, carry, over, di).withIndex().associate { it.value.u to it.index } else emptyMap()   // where every row will end up, so the gap shows for one song or many
  val ratio = (cfg.screenWidthDp - 32f) / 56f
  Box(Modifier.onGloballyPositioned { origin = it.positionInRoot() }) {
    Column {
      Row(Modifier.horizontalScroll(rememberScrollState())) { lib.keys.forEach { k -> Chip(k, k == cur, { if (k != "All") delList = k to (chipRects[k]?.bottomLeft ?: Offset.Zero) }, Modifier.onGloballyPositioned { chipRects[k] = it.boundsInRoot() }, hover == k) { cur = k } } }
      Row(verticalAlignment = Alignment.CenterVertically) {
        TButton({ pick.launch(arrayOf("audio/*")) }) { Text("Add MP3s") }; Spacer(Modifier.width(8.dp))
        OutlinedTextField(np, { np = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("New playlist") })
        IcoBtn("plus") { if (np.isNotBlank() && np != "All") { edit { it.putIfAbsent(np, mutableListOf()) }; cur = np; np = "" } } }
      Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        IcoBtn("prev") { ctrl?.seekToPrevious() }; IcoBtn(if (playing) "pause" else "play") { val c = ctrl; if (c != null) { if (c.isPlaying) c.pause() else if (c.mediaItemCount == 0) play(0) else c.play() } }
        IcoBtn("next") { ctrl?.seekToNext() }; IcoBtn("shuffle", if (shuf) Color.White else Color.Gray) { shuf = !shuf; ctrl?.shuffleModeEnabled = shuf } }
      LazyColumn(Modifier.weight(1f).onGloballyPositioned { listTop = it.positionInRoot().y; listBottom = listTop + it.size.height }, state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        itemsIndexed(songs, key = { _, s -> s.u }) { i, s ->
          val on = s.u in picked; val img = remember(covers[s.u]) { covers[s.u]?.let { ctx.loadImg(it) } }; val pos = remember(posVer, covers[s.u]) { st.coverPos(s.u) }
          var co by remember { mutableStateOf<LayoutCoordinates?>(null) }
          val info = listState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == i }; val hpx = (info?.size ?: 0) + with(dn) { 8.dp.toPx() }
          val shiftT = if (dragU == null || s.u in carry) 0f else ((newIdx[s.u] ?: i) - i) * hpx
          val shift by animateFloatAsState(shiftT, tween(120))
          Box(Modifier.fillMaxWidth()
            .pointerInput(s.u) { var total = 0f
              detectDragGesturesAfterLongPress(
                onDragStart = { off -> total = 0f; dragU = s.u; carry = if (s.u in picked) picked else setOf(s.u); dragRoot = co?.localToRoot(off) ?: Offset.Zero },
                onDrag = { _, d -> total += abs(d.x) + abs(d.y); dragRoot += d },
                onDragEnd = { finishDrag(total, s) }, onDragCancel = { dragU = null; carry = emptySet() }) }
            .onGloballyPositioned { co = it }
            .graphicsLayer { translationY = shift; alpha = if (s.u in carry && dragU != null) 0f else 1f }
            .clip(RoundedCornerShape(50)).background(Color.Black).border(if (on) 4.dp else 1.dp, if (on) Color.White else Color(0xFF444444), RoundedCornerShape(50))
            .clickable { if (System.currentTimeMillis() - lastEnd > 300) { if (picked.isNotEmpty()) picked = if (on) picked - s.u else picked + s.u else play(i) } }) {
            if (img != null) { CoverImg(img, pos, Modifier.matchParentSize()); Box(Modifier.matchParentSize().background(Color.Black.copy(alpha = .55f))) }
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(s.t, color = Color.White, maxLines = 1, modifier = Modifier.weight(1f).padding(start = 20.dp))
              IcoBtn("up") { edit { m -> m[cur]?.let { moveSel(it, if (on) picked else setOf(s.u), -1) } } }
              IcoBtn("down") { edit { m -> m[cur]?.let { moveSel(it, if (on) picked else setOf(s.u), 1) } } }
              IcoBtnAt("plus") { cvMenu = s to it }; IcoBtnAt("close") { delSong = s to it } } } } }
    }
    // the dragged song floats above everything, so nothing clips it
    val gs = songs.firstOrNull { it.u == dragU }
    if (gs != null) { val gi = remember(covers[gs.u]) { covers[gs.u]?.let { ctx.loadImg(it) } }
      Box(Modifier.fillMaxWidth().height(52.dp).zIndex(10f).offset { IntOffset(0, (dragRoot.y - origin.y - 26.dp.toPx()).roundToInt()) }.graphicsLayer { scaleX = 1.03f; scaleY = 1.03f }
        .clip(RoundedCornerShape(50)).background(Color.Black).border(3.dp, Color.White, RoundedCornerShape(50)), Alignment.CenterStart) {
        if (gi != null) { CoverImg(gi, st.coverPos(gs.u), Modifier.matchParentSize()); Box(Modifier.matchParentSize().background(Color.Black.copy(alpha = .55f))) }
        Text(gs.t, color = Color.White, maxLines = 1, modifier = Modifier.padding(start = 20.dp))
        if (carry.size > 1) Box(Modifier.align(Alignment.CenterEnd).padding(end = 14.dp).size(26.dp).clip(CircleShape).background(Color.White), Alignment.Center) { Text("${carry.size}", color = Color.Black, fontSize = 13.sp) } } }
    pend?.let { (k, ids) -> PopCard(pendAt, origin, false, "To $k", { pend = null; carry = emptySet() }) {
      Row { TTextButton({ sendTo(k, ids, true); pend = null }) { Text("Copy") }; if (cur != "All") TTextButton({ sendTo(k, ids, false); pend = null }) { Text("Move") }
        TTextButton({ pend = null; carry = emptySet() }) { Text("Cancel") } } } }
    cvMenu?.let { (s, at) -> val has = covers[s.u] != null; PopCard(at, origin, false, "Cover", { cvMenu = null }) {
      TTextButton({ coverTarget = s; cvMenu = null; coverPick.launch(arrayOf("image/*")) }) { Text(if (has) "Change cover" else "Add cover") }
      if (has) { TTextButton({ adj = s; cvMenu = null }) { Text("Adjust position") } }
      if (st.covers().containsKey(s.u)) { TTextButton({ st.removeCover(s.u); covers = st.effCovers(); posVer++; cvMenu = null; Thread { ctx.refreshArt(s.u) }.start() }) { Text("Remove cover") } }
      TTextButton({ cvMenu = null }) { Text("Cancel") } } }
    val redBtn = ButtonDefaults.textButtonColors(contentColor = Color(0xFFFF5252))
    delSong?.let { (s, at) -> PopCard(at, origin, true, "Delete music?", { delSong = null }) {
      Text(if (cur == "All") "Delete ${s.t}?" else "Remove ${s.t} from this playlist? It stays in All.", color = Color.White, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 8.dp))
      Row { TTextButton({ delSong = null }) { Text("Cancel") }
        TTextButton({ edit { m -> if (cur == "All") m.values.forEach { it.removeAll { x -> x.u == s.u } } else m[cur]?.removeAll { x -> x.u == s.u } }; delSong = null }, danger = true) { Text("Delete") } } } }
    delList?.let { (k, at) -> PopCard(at, origin, true, "Delete playlist?", { delList = null }) {
      Text("Delete $k? The music stays in All.", color = Color.White, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 8.dp))
      Row { TTextButton({ delList = null }) { Text("Cancel") }; TTextButton({ edit { it.remove(k) }; if (cur == k) cur = "All"; delList = null }, danger = true) { Text("Delete") } } } }
  }
  adj?.let { s -> val img = remember(s.u, covers[s.u]) { covers[s.u]?.let { ctx.loadImg(it) } }
    var pz by remember(s.u) { mutableStateOf(st.coverPos(s.u).toList()) }; var bw by remember { mutableStateOf(1f) }; var bh by remember { mutableStateOf(1f) }
    Dialog(onDismissRequest = { adj = null }) { Column(Modifier.clip(RoundedCornerShape(20.dp)).background(Color(0xFF1E1E1E)).padding(16.dp)) {
      Text("Drag to move, pinch to zoom", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(bottom = 10.dp))
      Box(Modifier.fillMaxWidth().aspectRatio(ratio).clip(RoundedCornerShape(50)).background(Color.Black).onSizeChanged { bw = it.width.toFloat(); bh = it.height.toFloat() }
        .pointerInput(s.u) { detectTransformGestures { _, pan, zoom, _ -> if (img != null) {
          val z = (pz[2] * zoom).coerceIn(1f, 4f); val s0 = maxOf(bw / img.width, bh / img.height) * z; val ovx = (img.width * s0 - bw) / 2; val ovy = (img.height * s0 - bh) / 2
          pz = listOf(if (ovx > 1f) (pz[0] + pan.x / ovx).coerceIn(-1f, 1f) else 0f, if (ovy > 1f) (pz[1] + pan.y / ovy).coerceIn(-1f, 1f) else 0f, z) } } }, Alignment.CenterStart) {
        if (img != null) CoverImg(img, pz.toFloatArray(), Modifier.matchParentSize()); Box(Modifier.matchParentSize().background(Color.Black.copy(alpha = .55f)))
        Text(s.t, color = Color.White, maxLines = 1, modifier = Modifier.padding(start = 20.dp)) }
      Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.End) { TTextButton({ pz = listOf(0f, 0f, 1f) }) { Text("Reset") }
        TTextButton({ st.setCoverPos(s.u, pz[0], pz[1], pz[2]); posVer++; adj = null; Thread { ctx.refreshArt(s.u) }.start() }) { Text("Done") } } } } }
}

// The same dark rounded card as the small popups, but in the middle of the screen (red for deleting). locked = can't be dismissed.
@Composable fun CenterCard(title: String, red: Boolean, onDismiss: () -> Unit, locked: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
  Dialog(onDismissRequest = onDismiss, properties = DialogProperties(dismissOnBackPress = !locked, dismissOnClickOutside = !locked)) {
    Column(Modifier.widthIn(max = 320.dp).clip(RoundedCornerShape(16.dp)).background(if (red) Color(0xFF2A0F0F) else Color(0xFF1E1E1E)).border(1.dp, if (red) Color(0xFFB71C1C) else Color(0xFF444444), RoundedCornerShape(16.dp)).padding(16.dp)) {
      Text(title, color = if (red) Color(0xFFFF8A80) else Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp)); content() } }
}
