package com.finite.functions
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.graphics.PathParser

// 24x24 line icons: thick, round caps and joins, like the logo
val ICONS = mapOf(
  "play" to "M7 4 L19 12 L7 20 Z", "pause" to "M8 5 V19 M16 5 V19", "next" to "M6 5 L15 12 L6 19 Z M19 5 V19", "prev" to "M18 5 L9 12 L18 19 Z M5 5 V19",
  "shuffle" to "M3 7 H6 C12 7 12 17 18 17 H21 M18 14 L21 17 L18 20 M3 17 H6 C8 17 9 16 10 14.5 M14 9.5 C15 8 16 7 18 7 H21 M18 4 L21 7 L18 10",
  "left" to "M15 6 L9 12 L15 18", "right" to "M9 6 L15 12 L9 18", "up" to "M6 15 L12 9 L18 15", "down" to "M6 9 L12 15 L18 9", "plus" to "M12 5 V19 M5 12 H19", "close" to "M6 6 L18 18 M18 6 L6 18", "check" to "M5 12.5 L10 17.5 L19 7",
  "search" to "M11 4 A7 7 0 1 0 11 18 A7 7 0 1 0 11 4 M16.5 16.5 L21 21", "sliders" to "M4 7 H20 M4 17 H20 M9 4 V10 M15 14 V20",
  "grid" to "M4 4 H10 V10 H4 Z M14 4 H20 V10 H14 Z M4 14 H10 V20 H4 Z M14 14 H20 V20 H14 Z", "info" to "M12 3 A9 9 0 1 0 12 21 A9 9 0 1 0 12 3 M12 11 V17 M12 7.5 V7.6",
  "edit" to "M4 20 H8 L19 9 L15 5 L4 16 Z M13 7 L17 11", "pin" to "M9 4 H15 L14 10 L17 13 H7 L10 10 Z M12 13 V20", "trash" to "M5 7 H19 M9 7 V4 H15 V7 M7 7 L8 20 H16 L17 7 M10 11 V16 M14 11 V16",
  "camera" to "M3 8 H7 L9 5 H15 L17 8 H21 V19 H3 Z M12 10.5 A3.5 3.5 0 1 0 12 17.5 A3.5 3.5 0 1 0 12 10.5",
  "controller" to "M8 5 H16 C19.5 5 21 9 21 14 C21 17 20 19 18 19 C16.5 19 16 18 15 17 H9 C8 18 7.5 19 6 19 C4 19 3 17 3 14 C3 9 4.5 5 8 5 Z M8 10 V14 M6 12 H10 M15.5 11 H15.6 M18 13.5 H18.1",
  "tv" to "M3 7 H21 V19 H3 Z M8 3 L12 7 L16 3", "music" to "M9 18 V6 L19 4 V16 M9 18 A3 3 0 1 1 3 18 A3 3 0 1 1 9 18 M19 16 A3 3 0 1 1 13 16 A3 3 0 1 1 19 16",
  "phone" to "M6 3 H10 L11.5 8 L9 9.5 C10 12 12 14 14.5 15 L16 12.5 L21 14 V18 C21 19.5 20 21 18 21 C10 21 3 14 3 6 C3 4 4.5 3 6 3 Z",
  "chat" to "M4 5 H20 V16 H11 L6 20 V16 H4 Z", "globe" to "M12 3 A9 9 0 1 0 12 21 A9 9 0 1 0 12 3 M3 12 H21 M12 3 C8 8 8 16 12 21 M12 3 C16 8 16 16 12 21",
  "cart" to "M2 4 H5 L7 15 H18 L20 7 H6 M9 19.5 H9.1 M17 19.5 H17.1", "folder" to "M3 6 H9 L11 9 H21 V19 H3 Z",
  "audio" to "M4 9 H8 L13 5 V19 L8 15 H4 Z M16.5 9 C17.8 10.5 17.8 13.5 16.5 15 M19 6.5 C21.5 9.5 21.5 14.5 19 17.5",
  "thermo" to "M10 14.5 V5 A2 2 0 0 1 14 5 V14.5 A4 4 0 1 1 10 14.5 Z M12 9 V16 M16.5 6 H18.5 M16.5 9 H18.5",
  "notepage" to "M6 3 H14 L19 8 V21 H6 Z M14 3 V8 H19 M9 12 H16 M9 15 H16 M9 18 H13",
  "ai" to "M3 19 L7.5 6 L12 19 M5 14.5 H10 M16 6 V19 M14 6 H18 M14 19 H18",
  "weather" to "M5.1 10 A3.2 3.2 0 1 1 10.9 10 M8 1.8 V3 M3.2 4 L4.2 5 M12.8 4 L11.8 5 M2 8.6 H3.2 M14 8.6 H12.8 M7 20 A3 3 0 0 1 7 14 A5 5 0 0 1 16.5 13 A3.5 3.5 0 0 1 17 20 Z",
  "bulb" to "M9 18 H15 M10 21 H14 M12 3 A6 6 0 0 0 8.5 14 C9 15 9 16 9 17 H15 C15 16 15 15 15.5 14 A6 6 0 0 0 12 3 Z",
  "book" to "M12 6 C9 4 6 4 3 5 V19 C6 18 9 18 12 20 C15 18 18 18 21 19 V5 C18 4 15 4 12 6 Z M12 6 V20",
  "clef" to "M4 15 V12 A8 8 0 0 1 20 12 V15 M3.5 14 H7.5 V20 H3.5 Z M16.5 14 H20.5 V20 H16.5 Z",
  "gear" to "M12 5.5 A6.5 6.5 0 1 0 12 18.5 A6.5 6.5 0 1 0 12 5.5 M12 3 V5.5 M12 18.5 V21 M3 12 H5.5 M18.5 12 H21 M5.6 5.6 L7.4 7.4 M16.6 16.6 L18.4 18.4 M18.4 5.6 L16.6 7.4 M7.4 16.6 L5.6 18.4",
  "calendar" to "M4 6 H20 V20 H4 Z M4 10 H20 M8 3 V7 M16 3 V7 M8 14 H8.1 M12 14 H12.1 M16 14 H16.1 M8 17.5 H8.1 M12 17.5 H12.1",
  "clock" to "M12 3 A9 9 0 1 0 12 21 A9 9 0 1 0 12 3 M12 7 V12 L15.5 14",
  "mappin" to "M12 21 C12 21 5 14.5 5 9.5 A7 7 0 0 1 19 9.5 C19 14.5 12 21 12 21 Z M12 7.5 A2.5 2.5 0 1 0 12 12.5 A2.5 2.5 0 1 0 12 7.5",
  "mail" to "M3 6 H21 V18 H3 Z M3 7 L12 13.5 L21 7",
  "heart" to "M12 20 C12 20 4 14.5 4 9 A4.5 4.5 0 0 1 12 7 A4.5 4.5 0 0 1 20 9 C20 14.5 12 20 12 20 Z",
  "star" to "M12 3.5 L14.6 9.2 L20.8 9.8 L16.1 13.9 L17.6 20 L12 16.8 L6.4 20 L7.9 13.9 L3.2 9.8 L9.4 9.2 Z",
  "wrench" to "M4 9 H20 V19 H4 Z M9 9 V7 A1.5 1.5 0 0 1 10.5 5.5 H13.5 A1.5 1.5 0 0 1 15 7 V9 M4 13.5 H20 M11 12 V15 H13 V12",
  "scissors" to "M6 6.5 A2.5 2.5 0 1 0 6 11.5 A2.5 2.5 0 1 0 6 6.5 M6 12.5 A2.5 2.5 0 1 0 6 17.5 A2.5 2.5 0 1 0 6 12.5 M8 10.5 L20 18 M8 13.5 L20 6",
  "imgbox" to "M4 5 H20 V19 H4 Z M4 15 L9 10 L13 14 L16 11 L20 15 M15.5 8.5 H15.6",
  "share" to "M18 8 A2.5 2.5 0 1 0 18 3 A2.5 2.5 0 1 0 18 8 M6 15 A2.5 2.5 0 1 0 6 10 A2.5 2.5 0 1 0 6 15 M18 21 A2.5 2.5 0 1 0 18 16 A2.5 2.5 0 1 0 18 21 M8.2 11.5 L15.8 7 M8.2 13.5 L15.8 18",
  "download" to "M12 4 V15 M7 10.5 L12 15.5 L17 10.5 M5 20 H19",
  "list" to "M4 6 H20 M4 12 H20 M4 18 H20",
  "qr" to "M4 4 H10 V10 H4 Z M14 4 H20 V10 H14 Z M4 14 H10 V20 H4 Z M14 14 H16 M18 14 H20 M14 18 V20 M17 17 H20 V20",
  "convert" to "M4 8 H18 M14 4 L18 8 L14 12 M20 16 H6 M10 12 L6 16 L10 20",
  "mic" to "M12 3 A3 3 0 0 1 15 6 V11 A3 3 0 0 1 9 11 V6 A3 3 0 0 1 12 3 Z M6 11 A6 6 0 0 0 18 11 M12 17 V21 M9 21 H15",
  "radio" to "M4 9 H20 V20 H4 Z M7 9 L17 4 M8 14.5 A2.5 2.5 0 1 0 13 14.5 A2.5 2.5 0 1 0 8 14.5 M16 13 H17 M16 16 H17",
  "filmstrip" to "M5 3 H19 V21 H5 Z M5 7 H8 M5 12 H8 M5 17 H8 M16 7 H19 M16 12 H19 M16 17 H19 M8 3 V21 M16 3 V21",
  "vinyl" to "M12 3 A9 9 0 1 0 12 21 A9 9 0 1 0 12 3 M12 10 A2 2 0 1 0 12 14 A2 2 0 1 0 12 10 M12 6 A6 6 0 0 1 18 12",
  "speaker" to "M6 3 H18 V21 H6 Z M12 7 H12.1 M12 11 A3 3 0 1 0 12 17 A3 3 0 1 0 12 11",
  "videocam" to "M3 7 H15 V17 H3 Z M15 11 L21 8 V16 L15 13",
  "photo" to "M3 5 H21 V19 H3 Z M3 16 L8 11 L12 15 L15 12 L21 18 M16 9 H16.1",
  "playcircle" to "M12 3 A9 9 0 1 0 12 21 A9 9 0 1 0 12 3 M10 8.5 L16 12 L10 15.5 Z",
  "podcast" to "M8 15 A5 5 0 0 1 8 9 M16 9 A5 5 0 0 1 16 15 M5 18 A9 9 0 0 1 5 6 M19 6 A9 9 0 0 1 19 18 M12 10 A2 2 0 1 0 12 14 A2 2 0 1 0 12 10",
  "newspaper" to "M4 5 H18 V19 H6 A2 2 0 0 1 4 17 Z M18 8 H20 V17 A2 2 0 0 1 18 19 M7 9 H15 M7 12 H15 M7 15 H12",
  "joystick" to "M12 4 A2 2 0 1 0 12 8 A2 2 0 1 0 12 4 M12 8 V14 M5 14 H19 V20 H5 Z M8 17 H8.1 M16 17 H16.1",
  "ticket" to "M3 7 H21 V10 A2 2 0 0 0 21 14 V17 H3 V14 A2 2 0 0 0 3 10 Z M15 7 V17",
  "equalizer" to "M5 20 V12 M9 20 V6 M13 20 V10 M17 20 V4 M21 20 V14",
  "plug" to "M9 3 V8 M15 3 V8 M6 8 H18 V12 A6 6 0 0 1 6 12 Z M12 18 V21",
  "battery" to "M3 8 H19 V16 H3 Z M19 10.5 H21 V13.5 H19 M6 11 V13 M9 11 V13",
  "power" to "M12 3 V12 M7 6.5 A8 8 0 1 0 17 6.5",
  "bolt" to "M13 3 L5 13 H11 L10 21 L19 10 H13 Z",
  "eye" to "M2 12 C5 6 19 6 22 12 C19 18 5 18 2 12 Z M12 9 A3 3 0 1 0 12 15 A3 3 0 1 0 12 9",
  "database" to "M5 6 C5 3 19 3 19 6 C19 9 5 9 5 6 V18 C5 21 19 21 19 18 V6 M5 12 C5 15 19 15 19 12",
  "laptop" to "M5 6 H19 V15 H5 Z M2 19 H22 L20.5 15 H3.5 Z",
  "tablet" to "M6 3 H18 V21 H6 Z M11 18 H13",
  "monitor" to "M3 5 H21 V16 H3 Z M9 20 H15 M12 16 V20",
  "printer" to "M7 8 V3 H17 V8 M7 17 H5 V10 H19 V17 H17 M7 14 H17 V21 H7 Z",
  "mouse" to "M12 3 C16 3 17 6 17 9 V15 C17 18 15 21 12 21 C9 21 7 18 7 15 V9 C7 6 8 3 12 3 Z M12 3 V10 M7 10 H17",
  "magnet" to "M5 4 V12 A7 7 0 0 0 19 12 V4 H15 V12 A3 3 0 0 1 9 12 V4 Z M5 8 H9 M15 8 H19",
  "tag" to "M3 4 H12 L21 13 L13 21 L4 12 Z M8 8 H8.1",
  "card" to "M3 6 H21 V18 H3 Z M3 10 H21 M6 15 H10",
  "coin" to "M12 3 A9 9 0 1 0 12 21 A9 9 0 1 0 12 3 M12 7 V17 M9.5 9.5 C9.5 8 14.5 8 14.5 9.8 C14.5 12 9.5 11.5 9.5 14 C9.5 16 14.5 16 14.5 14.5",
  "receipt" to "M5 3 H19 V21 L17 19.5 L14.5 21 L12 19.5 L9.5 21 L7 19.5 L5 21 Z M8 8 H16 M8 12 H16 M8 16 H12",
  "basket" to "M3 10 H21 L19 20 H5 Z M8 10 L12 4 L16 10 M9 14 V17 M12 14 V17 M15 14 V17",
  "store" to "M3 9 L5 4 H19 L21 9 Z M3 9 C3 12 8 12 8 9 C8 12 16 12 16 9 C16 12 21 12 21 9 M5 12 V20 H19 V12 M10 20 V15 H14 V20",
  "percent" to "M7 7 A2 2 0 1 0 7 11 A2 2 0 1 0 7 7 M17 13 A2 2 0 1 0 17 17 A2 2 0 1 0 17 13 M19 5 L5 19",
  "banknote" to "M2 7 H22 V17 H2 Z M12 9.5 A2.5 2.5 0 1 0 12 14.5 A2.5 2.5 0 1 0 12 9.5 M5 10 H5.1 M19 14 H19.1",
  "tshirt" to "M8 3 L3 6 L5 10 L7 9 V20 H17 V9 L19 10 L21 6 L16 3 C15 5 9 5 8 3 Z",
  "glasses" to "M3 13 A3.5 3.5 0 1 0 10 13 A3.5 3.5 0 1 0 3 13 M14 13 A3.5 3.5 0 1 0 21 13 A3.5 3.5 0 1 0 14 13 M10 12 C11 11 13 11 14 12 M3 13 L2 8 M21 13 L22 8",
  "watch" to "M8 3 H16 L15 7 M8 21 H16 L15 17 M7 7 H17 V17 H7 Z M12 10 V12.5 L14 13.5",
  "crown" to "M3 8 L8 12 L12 5 L16 12 L21 8 L19 19 H5 Z",
  "cake" to "M4 12 H20 V20 H4 Z M4 15 C7 17 9 13 12 15 C15 17 17 13 20 15 M12 12 V8 M11 5 H13",
  "wine" to "M7 3 H17 L16.5 9 A4.5 4.5 0 0 1 7.5 9 Z M12 13.5 V20 M8 20 H16",
  "mug" to "M5 4 H15 V20 H5 Z M15 7 H18 A2 2 0 0 1 20 9 V13 A2 2 0 0 1 18 15 H15 M5 8 C5 6 9 6 10 4 C11 6 15 6 15 8",
  "icecream" to "M7 11 A5 5 0 1 1 17 11 Z M7 11 L12 21 L17 11",
  "apple" to "M12 7 C9 5 4 7 5 13 C6 18 9 21 12 19 C15 21 18 18 19 13 C20 7 15 5 12 7 Z M12 7 C12 5 13 3 15 3",
  "pizza" to "M12 21 L4 6 C9 2 15 2 20 6 Z M9.5 9 H9.6 M14 8.5 H14.1 M12 13 H12.1",
  "bus" to "M5 3 H19 V18 H5 Z M5 11 H19 M5 7 H19 M8 21 V18 M16 21 V18 M8 15 H8.1 M16 15 H16.1",
  "train" to "M7 3 H17 A2 2 0 0 1 19 5 V16 A2 2 0 0 1 17 18 H7 A2 2 0 0 1 5 16 V5 A2 2 0 0 1 7 3 Z M5 10 H19 M8 14 H8.1 M16 14 H16.1 M8 21 L10 18 M16 21 L14 18",
  "boat" to "M3 15 H21 L18 20 H6 Z M12 3 V15 M12 4 L19 13 H12 M12 7 L7 13 H12",
  "anchor" to "M12 3 A2 2 0 1 0 12 7 A2 2 0 1 0 12 3 M12 7 V20 M7 11 H17 M4 14 C4 18 8 20 12 20 C16 20 20 18 20 14 M4 14 L2 12 M20 14 L22 12",
  "compass" to "M12 3 A9 9 0 1 0 12 21 A9 9 0 1 0 12 3 M15.5 8.5 L13.5 13.5 L8.5 15.5 L10.5 10.5 Z",
  "map" to "M3 6 L9 4 L15 6 L21 4 V18 L15 20 L9 18 L3 20 Z M9 4 V18 M15 6 V20",
  "tent" to "M2 20 H22 M12 4 L3 20 M12 4 L21 20 M12 20 L12 13 L9.5 20 M12 13 L14.5 20",
  "mountain" to "M2 20 L9 7 L13 14 L16 10 L22 20 Z M7.5 10.5 L9 12 L10.5 10.5",
  "tree" to "M12 3 L5 12 H9 L5 18 H19 L15 12 H19 Z M12 18 V21",
  "umbrella" to "M3 12 A9 9 0 0 1 21 12 Z M12 12 V19 A2 2 0 0 1 8 19",
  "sun" to "M12 8 A4 4 0 1 0 12 16 A4 4 0 1 0 12 8 M12 2 V4 M12 20 V22 M2 12 H4 M20 12 H22 M5 5 L6.5 6.5 M17.5 17.5 L19 19 M19 5 L17.5 6.5 M6.5 17.5 L5 19",
  "suitcase" to "M3 8 H21 V20 H3 Z M9 8 V5 H15 V8 M3 13 H21 M11 13 H13 V15 H11 Z",
  "flag" to "M5 21 V3 M5 4 H18 L15 8 L18 12 H5",
  "snowflake" to "M12 2 V22 M3.5 7 L20.5 17 M3.5 17 L20.5 7 M9.5 4 L12 6 L14.5 4 M9.5 20 L12 18 L14.5 20",
  "fuel" to "M5 20 V5 A2 2 0 0 1 7 3 H13 A2 2 0 0 1 15 5 V20 M4 20 H16 M7 8 H13 M15 8 H17 L19 10 V17 A1.5 1.5 0 0 0 22 17 V8 L19 5",
  "drop" to "M12 3 C16 9 19 12 19 15 A7 7 0 0 1 5 15 C5 12 8 9 12 3 Z",
  "trophy" to "M7 4 H17 V10 A5 5 0 0 1 7 10 Z M7 6 H4 V8 A3 3 0 0 0 7 11 M17 6 H20 V8 A3 3 0 0 1 17 11 M12 15 V18 M8 21 H16 M9 18 H15",
  "medal" to "M8 3 L12 10 L16 3 M12 12 A5 5 0 1 0 12 22 A5 5 0 1 0 12 12 M12 15 V19",
  "target" to "M12 3 A9 9 0 1 0 12 21 A9 9 0 1 0 12 3 M12 7 A5 5 0 1 0 12 17 A5 5 0 1 0 12 7 M12 11 A1 1 0 1 0 12 13 A1 1 0 1 0 12 11",
  "flame" to "M12 3 C13 8 18 10 18 15 A6 6 0 0 1 6 15 C6 12 8 10 9 8 C10 10 11 10 12 3 Z M12 20 A2.5 2.5 0 0 1 9.5 17.5 C9.5 15.5 11.5 15 12 13 C13 14.5 14.5 15.5 14.5 17.5 A2.5 2.5 0 0 1 12 20",
  "smile" to "M12 3 A9 9 0 1 0 12 21 A9 9 0 1 0 12 3 M9 10 H9.1 M15 10 H15.1 M8 14 C9.5 17 14.5 17 16 14",
  "ghost" to "M5 21 V11 A7 7 0 0 1 19 11 V21 L16.5 18.5 L14 21 L12 18.5 L10 21 L7.5 18.5 Z M9.5 11 H9.6 M14.5 11 H14.6",
  "balloon" to "M12 3 C16 3 18 6 18 9 C18 13 15 15 12 17 C9 15 6 13 6 9 C6 6 8 3 12 3 Z M12 17 L11 19 H13 Z M12 19 C11 20 13 21 12 22",
  "gem" to "M6 4 H18 L22 10 L12 21 L2 10 Z M2 10 H22 M9 4 L7 10 L12 21 L17 10 L15 4",
  "soccer" to "M12 3 A9 9 0 1 0 12 21 A9 9 0 1 0 12 3 M12 8 L15.5 10.5 L14 14.5 H10 L8.5 10.5 Z M12 8 V3 M15.5 10.5 L20 9 M14 14.5 L17 18.5 M10 14.5 L7 18.5 M8.5 10.5 L4 9",
  "pawn" to "M12 3 A3 3 0 1 0 12 9 A3 3 0 1 0 12 3 M9 11 H15 M10.5 9 L9 17 M13.5 9 L15 17 M6 21 H18 L17 17 H7 Z",
  "wand" to "M4 20 L15 9 M15 9 L17 11 L6 22 M16 4 V7 M14.5 5.5 H17.5 M19 9 V11 M18 10 H20",
  "sparkles" to "M10 4 L12 10 L18 12 L12 14 L10 20 L8 14 L2 12 L8 10 Z M19 3 V7 M17 5 H21 M19 17 V21 M17 19 H21",
  "flower" to "M12 20 V11 M7 4 C7 9 9 11 12 11 C15 11 17 9 17 4 L14.5 6.5 L12 4 L9.5 6.5 Z M12 16 C10 16 8 15 7 13 M12 17 C14 17 16 16 17 14",
  "clover" to "M12 12 C9 7 4 8 5 11 C6 13 9 12 12 12 M12 12 C15 7 20 8 19 11 C18 13 15 12 12 12 M12 12 C9 17 4 16 5 13 C6 11 9 12 12 12 M12 12 C15 17 20 16 19 13 C18 11 15 12 12 12 M12 14 V21",
  "fish" to "M3 12 C6 6 14 6 17 12 C14 18 6 18 3 12 Z M17 12 L22 7 V17 Z M7.5 11 H7.6",
  "feather" to "M20 4 C10 4 5 9 5 17 L4 21 M5 17 C12 17 17 12 20 4 M9 13 L15 12",
  "wifi" to "M3 9.5 C8 5 16 5 21 9.5 M6 13 C9.5 10 14.5 10 18 13 M9 16.5 C11 15 13 15 15 16.5 M12 19.5 H12.1",
  "home" to "M3 11 L12 4 L21 11 M5 10 V20 H19 V10 M10 20 V14 H14 V20",
  "bell" to "M6 17 V11 A6 6 0 0 1 18 11 V17 L20 19 H4 Z M10 21 H14",
  "lock" to "M5 11 H19 V20 H5 Z M8 11 V8 A4 4 0 0 1 16 8 V11 M12 14.5 V16.5",
  "key" to "M7 3.5 A3.5 3.5 0 1 0 7 10.5 A3.5 3.5 0 1 0 7 3.5 M9.6 9.6 L20 20 M15.5 15.5 L18 13 M18.5 18 L20.5 15.5",
  "shield" to "M12 3 L19 6 V12 C19 16.5 15.5 19.5 12 21 C8.5 19.5 5 16.5 5 12 V6 Z M9 12 L11 14 L15 10",
  "bag" to "M5 8 H19 L20 20 H4 Z M9 8 V6 A3 3 0 0 1 15 6 V8",
  "gift" to "M4 9 H20 V13 H4 Z M5 13 V20 H19 V13 M12 9 V20 M12 9 C9 9 8 4.5 10.5 4.5 C12.5 4.5 12 9 12 9 C12 9 11.5 4.5 13.5 4.5 C16 4.5 15 9 12 9",
  "wallet" to "M4 7 H18 V5 H6 A2 2 0 0 0 4 7 V19 H20 V9 H4 M16 14 H16.1",
  "chart" to "M4 20 H20 M7 20 V13 M12 20 V8 M17 20 V4",
  "coffee" to "M5 9 H16 V15 A4 4 0 0 1 12 19 H9 A4 4 0 0 1 5 15 Z M16 10 H18 A2 2 0 0 1 18 14 H16 M8 3 V6 M12 3 V6",
  "fork" to "M7 3 V9 A2 2 0 0 0 11 9 V3 M9 3 V21 M16 3 C14 5 14 10 16 12 V21 M16 3 V12",
  "car" to "M4 13.5 V10 L6 6.5 H18 L20 10 V13.5 H4 Z M4 10 H20 M5.2 17.5 A1.8 1.8 0 1 0 8.8 17.5 A1.8 1.8 0 1 0 5.2 17.5 M15.2 17.5 A1.8 1.8 0 1 0 18.8 17.5 A1.8 1.8 0 1 0 15.2 17.5",
  "plane" to "M3 13 L21 4 L17 21 L12 14 L3 13 Z M21 4 L12 14",
  "bike" to "M3.5 17 A3.5 3.5 0 1 0 10.5 17 A3.5 3.5 0 1 0 3.5 17 M13.5 17 A3.5 3.5 0 1 0 20.5 17 A3.5 3.5 0 1 0 13.5 17 M7 17 L10 9 H15 L17 17 M10 9 L9 6 H7 M15 9 L14 6 H16",
  "dumbbell" to "M2 9 V15 M5 7 V17 M19 7 V17 M22 9 V15 M5 12 H19",
  "pulse" to "M2 12 H7 L9.5 5 L13 19 L15.5 12 H22",
  "clapper" to "M4 10 H20 V20 H4 Z M4 10 L3 6 L19 3 L20 7 M8 8.5 L7 5 M12.5 7.5 L11.5 4",
  "dice" to "M4 4 H20 V20 H4 Z M8 8 H8.1 M12 12 H12.1 M16 16 H16.1 M16 8 H16.1 M8 16 H8.1",
  "puzzle" to "M5 8 H9 V6 A2 2 0 0 1 13 6 V8 H17 V12 H19 A2 2 0 0 1 19 16 H17 V20 H5 Z",
  "palette" to "M12 3 A9 9 0 1 0 12 21 C14 21 14 18.5 12.5 17.5 C11 16.5 12 14 14 14 H17 C19.5 14 21 12 21 10 C21 6 17 3 12 3 Z M7.5 11 H7.6 M10 7.5 H10.1 M14.5 7.5 H14.6",
  "rocket" to "M12 2.5 C16 5 17 10 15.5 15 H8.5 C7 10 8 5 12 2.5 Z M8.5 15 L5.5 18 L8 18.5 M15.5 15 L18.5 18 L16 18.5 M12 10 H12.1 M10 19 L12 22 L14 19",
  "cloud" to "M7 19 A4 4 0 0 1 7 11 A5.5 5.5 0 0 1 17.5 10 A4.5 4.5 0 0 1 17.5 19 Z",
  "moon" to "M20 14.5 A8 8 0 1 1 9.5 4 A6.5 6.5 0 0 0 20 14.5 Z",
  "leaf" to "M5 19 C5 9 11 4 20 4 C20 13 15 19 5 19 Z M5 19 L13 11",
  "paw" to "M12 12 C8 12 6 15 6 17 C6 20 9 20 12 18.5 C15 20 18 20 18 17 C18 15 16 12 12 12 Z M5.5 9 H5.6 M9 5.5 H9.1 M15 5.5 H15.1 M18.5 9 H18.6")
// The preset symbols for group icons, in tabs so 50 of them stay easy to find
val PRESET_TABS = listOf(
  "Media" to listOf("camera", "controller", "tv", "music", "audio", "clef", "phone", "chat", "mail", "clapper", "book", "notepage", "mic", "radio", "filmstrip", "vinyl", "speaker", "videocam", "photo", "playcircle", "podcast", "newspaper", "joystick", "ticket", "equalizer"),
  "Home" to listOf("home", "bell", "lock", "key", "shield", "gear", "clock", "calendar", "wifi", "thermo", "bulb", "ai", "plug", "battery", "power", "bolt", "eye", "database", "laptop", "tablet", "monitor", "printer", "mouse", "magnet", "tag"),
  "Shop" to listOf("cart", "bag", "gift", "wallet", "chart", "folder", "coffee", "fork", "card", "coin", "receipt", "basket", "store", "percent", "banknote", "tshirt", "glasses", "watch", "crown", "cake", "wine", "mug", "icecream", "apple", "pizza"),
  "Travel" to listOf("car", "plane", "bike", "mappin", "globe", "weather", "cloud", "moon", "leaf", "bus", "train", "boat", "anchor", "compass", "map", "tent", "mountain", "tree", "umbrella", "sun", "suitcase", "flag", "snowflake", "fuel", "drop"),
  "Fun" to listOf("heart", "star", "dumbbell", "pulse", "dice", "puzzle", "palette", "rocket", "paw", "trophy", "medal", "target", "flame", "smile", "ghost", "balloon", "gem", "soccer", "pawn", "wand", "sparkles", "flower", "clover", "fish", "feather"))   // 25 in each group
val PRESETS = PRESET_TABS.flatMap { (_, second) -> second }

@Composable fun Ico(n: String, size: Dp = 24.dp, color: Color = Color.White, modifier: Modifier = Modifier) {
  val path = remember(n) { PathParser.createPathFromPathData(ICONS.getValue(n)).asComposePath() }
  Canvas(modifier.size(size)) { val s = this.size.width / 24f
    withTransform({ scale(s, s, Offset.Zero) }) { drawPath(path, color, style = Stroke(2.25f, cap = StrokeCap.Round, join = StrokeJoin.Round)) } }
}
@Composable fun IcoBtn(n: String, tint: Color = Color.White, f: () -> Unit) = Box(Modifier.clickable { f() }.padding(8.dp)) { Ico(n, 24.dp, tint) }

@Composable fun IcoBtnAt(n: String, tint: Color = Color.White, f: (Offset) -> Unit) { var p by remember { mutableStateOf(Offset.Zero) }; Box(Modifier.onGloballyPositioned { p = it.positionInRoot() }.clickable { f(p) }.padding(8.dp)) { Ico(n, 24.dp, tint) } }

fun drawIcon(c: android.graphics.Canvas, n: String, cx: Float, cy: Float, size: Float, color: Int) {
  val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { style = android.graphics.Paint.Style.STROKE; strokeWidth = 2.25f; strokeCap = android.graphics.Paint.Cap.ROUND; strokeJoin = android.graphics.Paint.Join.ROUND; this.color = color }
  c.save(); c.translate(cx - (size / 2), cy - (size / 2)); c.scale(size / 24f, size / 24f); c.drawPath(PathParser.createPathFromPathData(ICONS.getValue(n)), p); c.restore()
}
