package com.finite.functions
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.ui.text.style.TextAlign
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch
import kotlin.math.*
import kotlin.random.Random

// Shake detector: sends an impulse when the phone is shaken (used by the loose overlay)
class Shake(private val c: Context) : SensorEventListener {
  val flow = MutableSharedFlow<Offset>(extraBufferCapacity = 8); private var last = 0L
  override fun onSensorChanged(e: SensorEvent) { val x = e.values[0]; val y = e.values[1]; val z = e.values[2]; val now = System.currentTimeMillis()
    if (sqrt(x * x + y * y + z * z) - 9.81f > 8f && now - last > 120) { last = now; flow.tryEmit(Offset(-x * 45f, y * 45f)) } }
  override fun onAccuracyChanged(s: Sensor?, a: Int) {}
  fun start() { c.getSystemService(SensorManager::class.java).let { it.registerListener(this, it.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_GAME) } }
  fun stop() { c.getSystemService(SensorManager::class.java).unregisterListener(this) }
}

// One player connection for the whole app, never released: the music service stays up after an overlay closes, so the music keeps playing
object PlayerHub {
  var ctrl: MediaController? = null; var curPl: String? = null
  private var fut: com.google.common.util.concurrent.ListenableFuture<MediaController>? = null; private val waiting = ArrayList<(MediaController) -> Unit>()
  fun with(c: Context, f: (MediaController) -> Unit) { ctrl?.let { f(it); return }; waiting.add(f)
    if (fut == null) { val app = c.applicationContext; val x = MediaController.Builder(app, SessionToken(app, ComponentName(app, PlayerService::class.java))).buildAsync(); fut = x
      x.addListener({ val m = x.get(); ctrl = m; waiting.forEach { it(m) }; waiting.clear() }, ContextCompat.getMainExecutor(app)) } }
}

// Plays a group's playlist bubble through the same background player as the Music tab; tapping again pauses or resumes
class PlRunner(private val c: Context, enabled: Boolean) {
  val playing = mutableStateOf<String?>(null); private var ctrl: MediaController? = null; private var gone = false
  private val l = object : Player.Listener { override fun onIsPlayingChanged(p: Boolean) { playing.value = if (p) PlayerHub.curPl else null } }
  init { if (enabled) PlayerHub.with(c) { x -> if (!gone) { ctrl = x; x.addListener(l); playing.value = if (x.isPlaying) PlayerHub.curPl else null } } }
  fun toggle(name: String) { val x = ctrl ?: return
    if (PlayerHub.curPl == name && x.mediaItemCount > 0) { if (x.isPlaying) x.pause() else x.play(); return }
    val songs = Store(c).lib()[name] ?: return; if (songs.isEmpty()) return
    PlayerHub.curPl = name; x.setMediaItems(songs.map { MediaItem.Builder().setUri(it.u).setRequestMetadata(MediaItem.RequestMetadata.Builder().setMediaUri(Uri.parse(it.u)).build()).setMediaMetadata(MediaMetadata.Builder().setTitle(it.t).setArtist(if (name == "All") "Finite Functions" else name).setArtworkUri(Store(c).artUri(it.u)).build()).build() }, 0, 0L); x.repeatMode = Player.REPEAT_MODE_ALL; x.playWhenReady = true; x.prepare(); x.play()
    runCatching { c.applicationContext.startService(Intent(c, PlayerService::class.java)) } }   // marks the service as started so it outlives this overlay
  fun release() { gone = true; ctrl?.removeListener(l) }   // only stops listening; the connection stays
}

// The group's apps and playlists in the order you set; a deleted playlist just drops out
fun listFor(c: Context, g: Group): List<AppInfo> { val all = AppCache.apps ?: c.apps(); val lib = Store(c).lib()
  return g.apps.mapNotNull { p -> if (p.startsWith("pl:")) Uri.decode(p.removePrefix("pl:")).let { n -> if (lib.containsKey(n)) AppInfo(p, n) else null } else all.firstOrNull { it.pkg == p } } }

// The whole overlay. Shared by the activity (widgets, fallback) and the quick settings dialog, which doesn't pause the app underneath.
@Composable fun GroupOverlay(g: Group, list: List<AppInfo>, shakes: Flow<Offset>, playing: String?, go: (AppInfo) -> Unit, setBlur: (Int) -> Unit, done: () -> Unit) {
  var scrim by remember { mutableStateOf(false) }; var closing by remember { mutableStateOf(false) }; val prog = remember { Animatable(0f) }; val scope = rememberCoroutineScope()
  LaunchedEffect(Unit) { scrim = true; delay(380); prog.animateTo(1f, tween(900)) }   // tint first, then the group
  val close: () -> Unit = { if (!closing) { closing = true; scope.launch { prog.animateTo(0f, tween(700)); scrim = false; delay(380); done() } } }   // group out, then tint
  BackHandler { close() }
  val a by animateFloatAsState(if (scrim) .7f else 0f, tween(350))
  val lastBlur = remember { intArrayOf(-99) }   // only change the blur when it visibly changes, each change makes Android redo the window
  SideEffect { if (g.blur) { val r = (a / .7f * 60).toInt(); if (abs(r - lastBlur[0]) >= 4 || r == 0 || r >= 59) { lastBlur[0] = r; setBlur(r) } } }
  val seeds = remember { List(400) { Random.nextFloat() } }; val full = g.shape == "Strip" || (g.shape == "Dots" && g.loose)
  val ctx = LocalContext.current; val pic = remember(g.fillPic, g.fill) { if (g.fill == "Picture" && g.fillPic.isNotEmpty()) ctx.loadImg(g.fillPic) else null }
  CompositionLocalProvider(LocalPlaying provides playing, LocalPlLook provides g.looks(), LocalFillPic provides pic) {
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = a)).clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { close() }, contentAlignment = Alignment.Center) {
      Loose(g.loose && g.shape != "Dots" && g.shape != "Strip", shakes) {
        Box((if (full) Modifier.fillMaxSize() else Modifier).fx(g.anim, prog.value, seeds, Color(g.color), closing)) {
          when (g.shape) { "Dots" -> Dots(g, list, go, shakes); "Wheel" -> Wheel(g, list, go); "Strip" -> Strip(g, list, go); "Rings" -> Rings(g, list, go); "Cloud" -> Cloud(g, list, go); "Blob" -> Blob(g, list, go, shakes); else -> Panel(g, list, go) } } }
      // with loose on, an own-bubble name bounces around by itself
      if (g.loose && g.nameOwn && g.namePos != "Off" && g.shape != "Dots") Loose(true, shakes, 1.4f, when (g.namePos) { "Left" -> -1; "Right" -> 1; else -> 0 }) { Box(Modifier.fx(g.anim, prog.value, seeds, Color(g.color), closing)) { NameBubble(g) } }
    } }
}

class GroupActivity : ComponentActivity() {
  private val sh by lazy { Shake(this) }; private var pl: PlRunner? = null; private var loose = false
  override fun onResume() { super.onResume(); if (loose) sh.start() }
  override fun onPause() { super.onPause(); sh.stop() }
  override fun onDestroy() { pl?.release(); super.onDestroy() }
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState); @Suppress("DEPRECATION") overridePendingTransition(0, 0)
    val g = Store(this).groups().firstOrNull { it.id == intent.getStringExtra("id") } ?: return finish()
    loose = g.loose; Thread { Snd.warm(g.sound) }.start(); val list = listFor(this, g)
    val runner = PlRunner(this, g.apps.any { it.startsWith("pl:") }); pl = runner
    val go: (AppInfo) -> Unit = { if (it.pkg.startsWith("pl:")) runner.toggle(it.label) else { launch(it.pkg); finish() } }
    if (g.blur && Build.VERSION.SDK_INT >= 31) window.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
    setContent { GroupOverlay(g, list, sh.flow, runner.playing.value, go, { r -> if (Build.VERSION.SDK_INT >= 31) { val at = window.attributes; at.blurBehindRadius = r; window.attributes = at } }) { finish() } }
  }
}

// One progress value (0..1) drives every open animation; closing runs it backwards (Cut breaks apart instead).
fun Modifier.fx(kind: String, p: Float, seeds: List<Float>, col: Color, closing: Boolean): Modifier = when (kind) {
  "Fade" -> graphicsLayer { alpha = p }
  "Slide" -> graphicsLayer { alpha = p; translationY = (1f - p) * 900f }
  "Scale" -> graphicsLayer { alpha = p; scaleX = .7f + .3f * p; scaleY = scaleX }
  else -> graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }.drawWithContent {
    val self = this; val w = size.width; val h = size.height
    if (p <= 0f) return@drawWithContent
    if (p >= 1f) { drawContent(); return@drawWithContent }
    when (kind) {
      "Cubes" -> { val cell = maxOf(w, h) / 12f; val path = Path(); var r = 0; var y = 0f
        while (y < h) { var c = 0; var x = 0f
          while (x < w) { val lp = ((p - seeds[(r * 31 + c) % seeds.size] * .5f) / .5f).coerceIn(0f, 1f); val s = cell * lp
            path.addRect(Rect(x + (cell - s) / 2, y + (cell - s) / 2, x + (cell + s) / 2, y + (cell + s) / 2)); x += cell; c++ }
          y += cell; r++ }
        clipPath(path) { self.drawContent() } }
      "Lines" -> { val n = 14; val sh = h / n; val slide = (p / .6f).coerceIn(0f, 1f); val thick = ((p - .6f) / .4f).coerceIn(0f, 1f)
        for (i in 0 until n) { val dir = if (i % 2 == 0) -1f else 1f; val vh = sh * (.12f + .88f * thick); val top = i * sh + (sh - vh) / 2
          clipRect(0f, top, w, top + vh) { translate(left = dir * (1f - slide) * w) { self.drawContent() } } } }
      "Decloak" -> { val path = Path(); val big = hypot(w, h) * .6f   // random points and edge points spread into uneven rippling patches
        for (i in 0 until 12) { val edge = i < 6
          val sx = if (edge) when (i % 4) { 0 -> seeds[i] * w; 1 -> w; 2 -> seeds[i + 20] * w; else -> 0f } else seeds[i + 40] * w
          val sy = if (edge) when (i % 4) { 0 -> 0f; 1 -> seeds[i + 10] * h; 2 -> h; else -> seeds[i + 30] * h } else seeds[i + 60] * h
          val st = if (edge) seeds[i + 80] * .1f else .1f + seeds[i + 80] * .3f; val r = big * ((p - st) / (1f - st)).coerceIn(0f, 1f)
          if (r > 1f) { val pts = 20
            for (k in 0 until pts) { val a = k * 2f * PI.toFloat() / pts; val rr = r * (1f + .18f * sin(a * 4f + i * 1.7f + p * 9f)); val x = sx + cos(a) * rr; val y = sy + sin(a) * rr
              if (k == 0) path.moveTo(x, y) else path.lineTo(x, y) }
            path.close() } }
        translate(left = sin(p * 40f) * 6f * (1f - p)) { clipPath(path) { self.drawContent() } }
        drawRect(Color.White.copy(alpha = .3f + .7f * p), blendMode = BlendMode.DstIn) }
      "Swirl" -> { val cx = w / 2; val cy = h / 2
        if (p < .3f) drawCircle(col, 12.dp.toPx(), Offset(cx, 12.dp.toPx() + (cy - 12.dp.toPx()) * (p / .3f)))
        else { val q = (p - .3f) / .7f; val path = Path().apply { addOval(Rect(Offset(cx, cy), q * hypot(w, h) / 2)) }
          clipPath(path) { rotate((1f - q) * 270f, Offset(cx, cy)) { self.drawContent() } } } }
      "Wave" -> { val cx = w / 2; val cy = h / 2; val big = hypot(w, h) / 2   // a drop lands in the middle, rings spread and the shape appears inside them
        if (p < .25f) drawCircle(col, 10.dp.toPx(), Offset(cx, 10.dp.toPx() + (cy - 10.dp.toPx()) * (p / .25f)))
        else { val q = (p - .25f) / .75f; val r = q * big; val path = Path()
          for (k in 0 until 48) { val an = k * 2f * PI.toFloat() / 48; val rr = r * (1f + .03f * sin(an * 6f - q * 14f) * (1f - q)); val x = cx + cos(an) * rr; val y = cy + sin(an) * rr; if (k == 0) path.moveTo(x, y) else path.lineTo(x, y) }
          path.close(); clipPath(path) { self.drawContent() }
          for (i in 0 until 3) { val rr = r * (1f - i * .22f); if (rr > 2f) drawCircle(Color.White.copy(alpha = ((.5f - i * .14f) * (1f - q)).coerceAtLeast(0f)), rr, Offset(cx, cy), style = Stroke(2.dp.toPx())) } } }
      "Beam" -> { val a = Offset(w + 40f, -40f); val b = Offset(-40f, h + 40f); val dx = b.x - a.x; val dy = b.y - a.y; val l = hypot(dx, dy); val ux = dx / l; val uy = dy / l; val nx = -uy; val ny = ux
        if (p < .3f) { val t = p / .3f; drawLine(Color.White, a, Offset(a.x + dx * t, a.y + dy * t), 4.dp.toPx(), StrokeCap.Round) }
        else { val q = (p - .3f) / .7f; val hw = q * hypot(w, h); val s = Offset(a.x - ux * hw, a.y - uy * hw); val e = Offset(b.x + ux * hw, b.y + uy * hw)
          val path = Path().apply { moveTo(s.x + nx * hw, s.y + ny * hw); lineTo(e.x + nx * hw, e.y + ny * hw); lineTo(e.x - nx * hw, e.y - ny * hw); lineTo(s.x - nx * hw, s.y - ny * hw); close() }
          clipPath(path) { self.drawContent() }
          val wc = Color.White.copy(alpha = 1f - q)
          drawLine(wc, Offset(s.x + nx * hw, s.y + ny * hw), Offset(e.x + nx * hw, e.y + ny * hw), 3.dp.toPx()); drawLine(wc, Offset(s.x - nx * hw, s.y - ny * hw), Offset(e.x - nx * hw, e.y - ny * hw), 3.dp.toPx()) } }
      "Cut" -> {   // flashes mark the edges, a jittered mesh of 18 triangles fills the shape; closing breaks the triangles apart again and again
        val m = minOf(w, h) * .08f
        fun v(r: Int, c: Int): Offset { val i = (r * 4 + c) * 2; val bx = c / 3f * w; val by = r / 3f * h
          return Offset(if (c == 0 || c == 3) bx else bx + (seeds[i] - .5f) * 2f * m, if (r == 0 || r == 3) by else by + (seeds[i + 1] - .5f) * 2f * m) }
        val tris = ArrayList<List<Offset>>()
        for (r in 0 until 3) for (c in 0 until 3) { val a = v(r, c); val b = v(r, c + 1); val d = v(r + 1, c + 1); val e = v(r + 1, c)
          if (seeds[300 + r * 3 + c] > .5f) { tris.add(listOf(a, b, d)); tris.add(listOf(a, d, e)) } else { tris.add(listOf(a, b, e)); tris.add(listOf(b, d, e)) } }
        fun shrink(t: List<Offset>, f: Float): Path { val cx = (t[0].x + t[1].x + t[2].x) / 3f; val cy = (t[0].y + t[1].y + t[2].y) / 3f
          return Path().apply { t.forEachIndexed { i, o -> val x = cx + (o.x - cx) * f; val y = cy + (o.y - cy) * f; if (i == 0) moveTo(x, y) else lineTo(x, y) }; close() } }
        fun split(t: List<Offset>): List<List<Offset>> { val a = t[0]; val b = t[1]; val c = t[2]; val ab = (a + b) / 2f; val bc = (b + c) / 2f; val ac = (a + c) / 2f
          return listOf(listOf(a, ab, ac), listOf(ab, b, bc), listOf(ac, bc, c), listOf(ab, bc, ac)) }
        if (!closing) {
          val fl = (p / .4f).coerceIn(0f, 1f); val tq = ((p - .4f) / .6f).coerceIn(0f, 1f)
          val rank = IntArray(tris.size); tris.indices.sortedBy { seeds[320 + it] }.forEachIndexed { rk, k -> rank[k] = rk }
          val path = Path(); val gap = .94f + .06f * ((tq - .9f) / .1f).coerceIn(0f, 1f)
          tris.forEachIndexed { k, t -> val a = ((tq - rank[k] / tris.size.toFloat() * .7f) / .3f).coerceIn(0f, 1f); if (a > 0f) path.addPath(shrink(t, gap * a)) }
          clipPath(path) { self.drawContent() }
          val lines = listOf(v(0, 0) to v(0, 3), v(0, 3) to v(3, 3), v(3, 3) to v(3, 0), v(3, 0) to v(0, 0), v(1, 0) to v(1, 3), v(0, 2) to v(3, 2))
          lines.forEachIndexed { i, (s0, e0) -> val pr = ((fl - i * .13f) / .22f).coerceIn(0f, 1f)
            if (pr > 0f) drawLine(Color.White.copy(alpha = if (pr < 1f) 1f else .6f * (1f - tq)), s0, Offset(s0.x + (e0.x - s0.x) * pr, s0.y + (e0.y - s0.y) * pr), if (pr < 1f) 4.dp.toPx() else 1.5.dp.toPx(), StrokeCap.Round) }
        } else {
          val b = 1f - p; val l = (b * 3f).toInt().coerceAtMost(2); val f = b * 3f - l
          var pieces: List<List<Offset>> = tris; repeat(l) { pieces = pieces.flatMap { split(it) } }
          val sc = (.96f - .06f * (l + f) - .9f * b * b).coerceAtLeast(0f); val path = Path(); pieces.forEach { path.addPath(shrink(it, sc)) }
          clipPath(path) { self.drawContent() }; drawRect(Color.White.copy(alpha = (1f - b * b).coerceIn(0f, 1f)), blendMode = BlendMode.DstIn) }
      }
      else -> drawContent()
    }
  }
}

// Loose overlay: shaking slides the whole piece around the screen; it bounces off the edges and slows down
@Composable fun Loose(on: Boolean, shakes: Flow<Offset>, mult: Float = 1f, hAlign: Int? = null, content: @Composable () -> Unit) {
  if (!on) { content(); return }
  val cfg = LocalConfiguration.current; val dn = LocalDensity.current; val W = with(dn) { cfg.screenWidthDp.dp.toPx() }; val H = with(dn) { cfg.screenHeightDp.dp.toPx() }
  var cw by remember { mutableStateOf(0f) }; var ch by remember { mutableStateOf(0f) }; val st = remember { FloatArray(4) }; var tick by remember { mutableIntStateOf(0) }
  LaunchedEffect(Unit) { launch { shakes.collect { st[2] += it.x * mult; st[3] += it.y * mult } }
    var last = 0L; var placed = hAlign == null
    while (true) { val t = withFrameNanos { it }; val dt = if (last == 0L) 0f else minOf(.03f, (t - last) / 1e9f); last = t
      if (!placed && cw > 0f) { st[0] = hAlign!! * maxOf(0f, (W - cw) / 2 - 16f * dn.density); st[1] = -(H / 2 - ch / 2 - 90f * dn.density); placed = true; tick++ }
      if (abs(st[2]) + abs(st[3]) > 1f) { val mx = maxOf(0f, (W - cw) / 2); val my = maxOf(0f, (H - ch) / 2)
        st[0] += st[2] * dt; st[1] += st[3] * dt
        if (abs(st[0]) > mx) { st[0] = mx * sign(st[0]); st[2] = -st[2] * .8f }; if (abs(st[1]) > my) { st[1] = my * sign(st[1]); st[3] = -st[3] * .8f }
        val f = 1f - 1.2f * dt; st[2] *= f; st[3] *= f; tick++ } } }
  Box(Modifier.onSizeChanged { cw = it.width.toFloat(); ch = it.height.toFloat() }.offset { val t = tick; IntOffset(st[0].roundToInt(), st[1].roundToInt()) }) { content() }
}

fun Modifier.square() = layout { m, c -> val p = m.measure(c); val d = maxOf(p.width, p.height); layout(d, d) { p.place((d - p.width) / 2, (d - p.height) / 2) } }

// The name's own bubble, in the same shape as the overlay (a true circle for Dots and Wheel)
@Composable fun NameBubble(g: Group) {
  val shape = when (g.shape) { "Sharp", "Strip" -> RectangleShape; "Dots", "Wheel", "Rings", "Blob" -> CircleShape; else -> RoundedCornerShape(28.dp) }
  Text(g.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 2, textAlign = TextAlign.Center, lineHeight = 18.sp, fontFamily = Fonts.family(LocalContext.current, g.font),
    modifier = Modifier.widthIn(max = 260.dp).clip(shape).background(Color(g.color).copy(alpha = g.alpha)).fillTex(g).then(if (g.shape in listOf("Dots", "Wheel", "Rings", "Blob")) Modifier.square() else Modifier).padding(horizontal = 18.dp, vertical = 10.dp))
}

@Composable fun Name(g: Group, inside: Boolean = false) {   // own bubble, or plain text inside the usual bubble
  if (g.namePos == "Off") return
  val arr = when (g.namePos) { "Left" -> Arrangement.Start; "Right" -> Arrangement.End; else -> Arrangement.Center }
  Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = arr) {
    if (g.nameOwn && !inside) NameBubble(g) else Text(g.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, fontFamily = Fonts.family(LocalContext.current, g.font)) }
}

@Composable fun AppIcon(a: AppInfo, size: Dp, onClick: (AppInfo) -> Unit) = ItemIcon(a, size, CircleShape, 2.dp) { onClick(a) }

@Composable fun Panel(g: Group, list: List<AppInfo>, go: (AppInfo) -> Unit) {   // Soft or Sharp rectangle
  val shape = if (g.shape == "Sharp") RectangleShape else RoundedCornerShape(28.dp); val gs = rememberLazyGridState(); var first by remember { mutableStateOf(true) }
  LaunchedEffect(gs) { snapshotFlow { gs.firstVisibleItemIndex }.collect { idx -> if (first) first = false else Snd.step(g.sound, idx / 3) } }
  val scope = rememberCoroutineScope(); val busy = remember { booleanArrayOf(false) }; val ownEnd = remember { longArrayOf(0L) }
  LaunchedEffect(gs.isScrollInProgress) { if (!gs.isScrollInProgress && g.lock && !busy[0] && System.currentTimeMillis() - ownEnd[0] > 250 && (gs.canScrollForward || gs.canScrollBackward) && gs.layoutInfo.visibleItemsInfo.isNotEmpty()) {   // auto app lock: only a list that really scrolls, one nudge at a time
    val li = gs.layoutInfo; val mid = li.viewportSize.height / 2f; val c = li.visibleItemsInfo.minByOrNull { abs(it.offset.y + it.size.height / 2f - mid) }!!; val d = c.offset.y + c.size.height / 2f - mid
    if (abs(d) > 2f) { busy[0] = true; scope.launch { val got = gs.animateScrollBy(d); ownEnd[0] = System.currentTimeMillis(); busy[0] = false; if (abs(got) > 1f) Snd.lock(g.sound, gs.firstVisibleItemIndex / 3) } } } }
  Column(Modifier.fillMaxWidth((.85f * g.size).coerceAtMost(.96f)).padding(vertical = 24.dp)) { if (g.nameOwn && !g.loose) Name(g)
    Column(Modifier.clip(shape).background(Color(g.color).copy(alpha = g.alpha)).fillTex(g).pointerInput(Unit) { detectTapGestures { } }.padding(20.dp)) { if (!g.nameOwn) Name(g, true)
      LazyVerticalGrid(GridCells.Fixed(if (g.size > 1.5f) 2 else 3), Modifier.heightIn(max = minOf(420f * g.size, LocalConfiguration.current.screenHeightDp * .7f).dp), state = gs) { items(list) { a -> AppItem(a, CircleShape, true, (56 * g.size).dp) { go(a) } } } } }
}

private fun rowsFor(n: Int) = when (n) { 1 -> listOf(1); 2 -> listOf(2); 3 -> listOf(2, 1); 4 -> listOf(2, 2); else -> listOf(3, 2) }
private fun diam(n: Int, sz: Float): Float { val r = rowsFor(n); val w = r.maxOf { it } * 44f * sz; val h = r.size * 44f * sz; return sqrt(w * w + h * h) + 14f * sz }

@Composable fun Bubble(apps: List<AppInfo>, sz: Float, col: Color, go: (AppInfo) -> Unit, modifier: Modifier = Modifier, g: Group? = null) {
  var k = 0
  Box(modifier.padding(5.dp).size(diam(apps.size, sz).dp).clip(CircleShape).background(col).fillTexN(g), Alignment.Center) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) { rowsFor(apps.size).forEach { n -> Row { repeat(n) { AppIcon(apps[k++], (40 * sz).dp, go) } } } } }
}

// Random circles, 1 to 5 apps each. Loose: every circle bounces on its own and off the other circles.
@OptIn(ExperimentalLayoutApi::class)
@Composable fun Dots(g: Group, list: List<AppInfo>, go: (AppInfo) -> Unit, shakes: Flow<Offset>) {
  val sz = g.size; val col = Color(g.color).copy(alpha = g.alpha)
  val bubbles = remember { chunkApps(list, g.rnd) }
  LaunchedEffect(Unit) { if (g.sound != "Off") { delay(400); bubbles.forEachIndexed { i, _ -> Snd.step(g.sound, i); delay(90) } } }
  if (!g.loose) Column(Modifier.padding(16.dp).pointerInput(Unit) { detectTapGestures { } }, horizontalAlignment = Alignment.CenterHorizontally) { Name(g, !g.nameOwn)
    FlowRow(horizontalArrangement = Arrangement.Center, verticalArrangement = Arrangement.Center) { bubbles.forEach { (apps, dy) -> Bubble(apps, sz, col, go, Modifier.offset(y = dy.dp), g) } } }
  else BoxWithConstraints(Modifier.fillMaxSize()) {
    val dn = LocalDensity.current; val W = with(dn) { this@BoxWithConstraints.maxWidth.toPx() }; val H = with(dn) { this@BoxWithConstraints.maxHeight.toPx() }; val n = bubbles.size
    val nm = g.nameOwn && g.namePos != "Off"; val cnt = if (nm) n + 1 else n   // the name bubble is one more body: it bounces and collides too
    val rs = remember(cnt) { FloatArray(cnt) { if (it < n) with(dn) { (diam(bubbles[it].first.size, sz) / 2 + 5f).dp.toPx() } else with(dn) { 44.dp.toPx() } } }
    val s = remember(cnt) { Array(4) { FloatArray(cnt) } }; var tick by remember { mutableIntStateOf(0) }   // x, y, vx, vy per body
    LaunchedEffect(cnt) {
      for (i in 0 until n) { val ang = i * 2.4f; val rad = 70f * sqrt(i.toFloat()) * dn.density; s[0][i] = cos(ang) * rad; s[1][i] = sin(ang) * rad + (if (nm) 60f * dn.density else 0f) }
      if (nm) { val ha = when (g.namePos) { "Left" -> -1f; "Right" -> 1f; else -> 0f }; s[0][n] = ha * (W / 2 - rs[n] - 16f * dn.density); s[1][n] = -(H / 2 - rs[n] - 90f * dn.density) }
      launch { shakes.collect { for (i in 0 until cnt) { s[2][i] += it.x * (1f + (i % 3) * .25f); s[3][i] += it.y * (1f + (i % 2) * .3f) } } }
      var last = 0L
      while (true) { val t = withFrameNanos { it }; val dt = if (last == 0L) 0f else minOf(.03f, (t - last) / 1e9f); last = t
        for (i in 0 until cnt) { s[0][i] += s[2][i] * dt; s[1][i] += s[3][i] * dt
          val mx = W / 2 - rs[i]; val my = H / 2 - rs[i]
          if (abs(s[0][i]) > mx) { s[0][i] = mx * sign(s[0][i]); s[2][i] = -s[2][i] * .85f }; if (abs(s[1][i]) > my) { s[1][i] = my * sign(s[1][i]); s[3][i] = -s[3][i] * .85f }
          val f = 1f - .8f * dt; s[2][i] *= f; s[3][i] *= f }
        for (i in 0 until cnt) for (j in i + 1 until cnt) { val dx = s[0][j] - s[0][i]; val dy = s[1][j] - s[1][i]; val d = hypot(dx, dy); val md = rs[i] + rs[j]
          if (d < md && d > .01f) { val nx = dx / d; val ny = dy / d; val push = (md - d) / 2
            s[0][i] -= nx * push; s[1][i] -= ny * push; s[0][j] += nx * push; s[1][j] += ny * push
            val rv = (s[2][i] - s[2][j]) * nx + (s[3][i] - s[3][j]) * ny
            if (rv > 0) { if (rv > 60f) Snd.step(g.sound, 0); val mi = rs[i] * rs[i]; val mj = rs[j] * rs[j]; val imp = 2 * rv / (mi + mj)
              s[2][i] -= imp * mj * nx; s[3][i] -= imp * mj * ny; s[2][j] += imp * mi * nx; s[3][j] += imp * mi * ny } } }
        tick++ } }
    if (!nm && g.namePos != "Off") Box(Modifier.fillMaxWidth().padding(top = 48.dp)) { Name(g, true) }   // name inside the usual bubble stays put
    bubbles.forEachIndexed { i, (apps, _) -> Box(Modifier.align(Alignment.Center).offset { val t = tick; IntOffset(s[0][i].roundToInt(), s[1][i].roundToInt()) }) { Bubble(apps, sz, col, go, Modifier, g) } }
    if (nm) Box(Modifier.align(Alignment.Center).offset { val t = tick; IntOffset(s[0][n].roundToInt(), s[1][n].roundToInt()) }.onSizeChanged { rs[n] = maxOf(it.width, it.height) / 2f }) { NameBubble(g) }
  }
}

// Spin the wheel with a drag or flick; the app it lands on shows in the middle (tap it to open)
@Composable fun Wheel(g: Group, list: List<AppInfo>, go: (AppInfo) -> Unit) {
  if (list.isEmpty()) return
  val n = list.size; val scope = rememberCoroutineScope(); var rot by remember { mutableFloatStateOf(0f) }
  val omega = remember { floatArrayOf(0f) }; val job = remember { arrayOfNulls<Job>(1) }
  var settled by remember { mutableStateOf(true) }; val lockT by animateFloatAsState(if (g.lock && settled) 1f else 0f, tween(260))   // with auto lock the chosen app slides into the middle
  val step = 360f / n; val sel = (((-rot / step).roundToInt() % n) + n) % n
  val r0 = minOf(130f, maxOf(95f, n * 56f / 6.283f)); val i0 = minOf(52f, 6.283f * r0 / n * .85f)
  val z = minOf(g.size, (LocalConfiguration.current.screenWidthDp - 24f) / (2 * r0 + i0 + 16)); val r = r0 * z; val icon = i0 * z; val box = 2 * r + icon + 16 * z; val cw = minOf(110f, (r - icon / 2 - 6f) * 2f).coerceAtLeast(40f); val ci = minOf(48f, cw * .45f)
  var first by remember { mutableStateOf(true) }; LaunchedEffect(sel) { if (first) first = false else Snd.step(g.sound, sel) }
  Column(horizontalAlignment = Alignment.CenterHorizontally) { if (g.nameOwn && !g.loose) Name(g)
    Box(Modifier.size(box.dp).clip(CircleShape).background(Color(g.color).copy(alpha = g.alpha)).fillTex(g).pointerInput(Unit) { detectTapGestures { } }
      .pointerInput(n) { detectDragGestures(
        onDragStart = { job[0]?.cancel(); omega[0] = 0f; settled = false },
        onDragEnd = { val v = omega[0] * 1000f
          job[0] = scope.launch { animateDecay(rot, v, FloatExponentialDecaySpec()) { value, _ -> rot = value }; if (g.lock) { animate(rot, (rot / step).roundToInt() * step) { value, _ -> rot = value }; Snd.lock(g.sound, (((-rot / step).roundToInt() % n) + n) % n); settled = true } } },
        onDrag = { ch, _ -> val cx = size.width / 2f; val cy = size.height / 2f
          val a1 = atan2(ch.previousPosition.y - cy, ch.previousPosition.x - cx); val a2 = atan2(ch.position.y - cy, ch.position.x - cx)
          var d = Math.toDegrees((a2 - a1).toDouble()).toFloat(); if (d > 180) d -= 360; if (d < -180) d += 360
          rot += d; omega[0] = d / maxOf(1L, ch.uptimeMillis - ch.previousUptimeMillis) }) },
      contentAlignment = Alignment.Center) {
      if (!g.nameOwn) Box(Modifier.align(Alignment.TopCenter).padding(top = (box * .1f).dp)) { Name(g, true) }
      list.forEachIndexed { i, a -> val ang = Math.toRadians((rot + i * step - 90f).toDouble())
        val f = if (i == sel) 1f - lockT else 1f
        Box(Modifier.offset { IntOffset((cos(ang) * r.dp.roundToPx() * f).roundToInt(), (sin(ang) * r.dp.roundToPx() * f).roundToInt()) }.graphicsLayer { alpha = f }) { AppIcon(a, icon.dp, go) } }
      Column(Modifier.width(cw.dp).graphicsLayer { alpha = if (g.lock) lockT else 1f }.clip(RoundedCornerShape(16.dp)).then(if (!g.lock || lockT > .6f) Modifier.clickable { go(list[sel]) } else Modifier).padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        AppIcon(list[sel], ci.dp, go); Text(list[sel].label, color = Color.White, fontSize = if (list[sel].label.length > 22) 10.sp else 12.sp, maxLines = 2, textAlign = TextAlign.Center, lineHeight = 14.sp) } } }
}

// A band across the screen, top right to bottom left. Drag or flick along it; apps loop around endlessly.
@Composable fun Strip(g: Group, list: List<AppInfo>, go: (AppInfo) -> Unit) {
  if (list.isEmpty()) return
  val cfg = LocalConfiguration.current; val dn = LocalDensity.current; val sz = g.size; val n = list.size
  val wPx = with(dn) { cfg.screenWidthDp.dp.toPx() }; val hPx = with(dn) { cfg.screenHeightDp.dp.toPx() }; val len = hypot(wPx, hPx); val ang = Math.toDegrees(atan2(hPx, wPx).toDouble()).toFloat()
  val s = maxOf(with(dn) { (76f * sz).dp.toPx() }, len / n); val loop = s * n
  var t by remember { mutableFloatStateOf(0f) }; val v = remember { floatArrayOf(0f) }; val job = remember { arrayOfNulls<Job>(1) }; val scope = rememberCoroutineScope()
  val nearI = (((-t / s).roundToInt() % n) + n) % n; var first by remember { mutableStateOf(true) }; LaunchedEffect(nearI) { if (first) first = false else Snd.step(g.sound, nearI) }
  Box(Modifier.fillMaxSize()) {
    if (!(g.loose && g.nameOwn)) Box(Modifier.fillMaxWidth().padding(top = 48.dp)) { Name(g, !g.nameOwn) }
    Box(Modifier.align(Alignment.Center).graphicsLayer { rotationZ = -ang }.requiredSize(with(dn) { len.toDp() }, (110f * sz).dp).background(Color(g.color).copy(alpha = g.alpha)).fillTex(g)
      .pointerInput(Unit) { detectTapGestures { } }
      .pointerInput(loop) { detectDragGestures(
        onDragStart = { job[0]?.cancel(); v[0] = 0f },
        onDragEnd = { val vel = v[0] * 1000f; job[0] = scope.launch { animateDecay(t, vel, FloatExponentialDecaySpec()) { x, _ -> t = x }; if (g.lock) { animate(t, (t / s).roundToInt() * s) { x, _ -> t = x }; Snd.lock(g.sound, (((-t / s).roundToInt() % n) + n) % n) } } },
        onDrag = { ch, d -> t += d.x; v[0] = d.x / maxOf(1L, ch.uptimeMillis - ch.previousUptimeMillis) }) },
      contentAlignment = Alignment.Center) {
      list.forEachIndexed { i, a -> val pos = ((i * s + t) % loop + loop) % loop - loop / 2; val near = abs(pos) < s / 2
        Column(Modifier.offset { IntOffset(pos.roundToInt(), 0) }.graphicsLayer { rotationZ = ang; val sc = 1f + .5f * (1f - minOf(abs(pos) / s, 1f)); scaleX = sc; scaleY = sc }, horizontalAlignment = Alignment.CenterHorizontally) {
          AppIcon(a, (52 * sz).dp, go); if (near) Text(a.label, color = Color.White, fontSize = if (a.label.length > 22) 9.sp else 11.sp, maxLines = 2, textAlign = TextAlign.Center, lineHeight = 13.sp, modifier = Modifier.widthIn(max = 130.dp)) } } } }
}

// Dots grouping: random sizes (1 to 5 apps) and positions, or with Random off a fixed pattern in your app order
fun chunkApps(list: List<AppInfo>, random: Boolean): List<Pair<List<AppInfo>, Int>> {
  val r = Random(System.nanoTime()); val pat = listOf(3, 2, 4, 1, 5); val out = mutableListOf<Pair<List<AppInfo>, Int>>(); var i = 0; var k = 0
  while (i < list.size) { val n = minOf(if (random) r.nextInt(1, 6) else pat[k++ % pat.size], list.size - i); out.add(list.subList(i, i + n) to (if (random) r.nextInt(-14, 15) else 0)); i += n }
  return out
}

// Rings: concentric rings of apps with a small gap between each. Each ring spins on its own; the app at the top of the last ring you touched shows in the middle.
@Composable fun Rings(g: Group, list: List<AppInfo>, go: (AppInfo) -> Unit) {
  if (list.isEmpty()) return
  val sz = g.size; val cfg = LocalConfiguration.current; val scope = rememberCoroutineScope(); val icon0 = 46f; val gap0 = 62f; val fillPic = LocalFillPic.current
  val rings = remember(list, g.ringMap) { buildRings(list, g.rings()) }
  val total = 2 * (64f + gap0 * (rings.size - 1)) + icon0 + 28f; val z = minOf(sz, (cfg.screenWidthDp - 24f) / total)
  fun ic(k: Int) = minOf(icon0, 6.283f * (64f + gap0 * k) / rings[k].size * .85f)   // a crowded ring gets smaller icons
  val rot = remember(rings) { mutableStateListOf<Float>().apply { repeat(rings.size) { add(0f) } } }
  val omega = remember { floatArrayOf(0f) }; val jobs = remember(rings) { arrayOfNulls<Job>(rings.size) }; var active by remember { mutableStateOf(0) }
  fun pick(k: Int): Int { val m = rings[k].size; return (((-rot[k] / (360f / m)).roundToInt() % m) + m) % m }
  val act = active.coerceIn(0, rings.size - 1); val sel = pick(act)
  var first by remember { mutableStateOf(true) }; LaunchedEffect(sel, act) { if (first) first = false else Snd.step(g.sound, sel) }
  Column(horizontalAlignment = Alignment.CenterHorizontally) { if (g.nameOwn && !g.loose) Name(g)
    Box(Modifier.size((total * z).dp).pointerInput(Unit) { detectTapGestures { } }
      .drawBehind { withFill(g, fillPic) { rings.forEachIndexed { k, _ -> drawCircle(Color(g.color).copy(alpha = g.alpha), ((64f + gap0 * k) * z).dp.toPx(), style = Stroke(((icon0 + 6f) * z).dp.toPx())) } } }
      .pointerInput(rings) { var ringIdx = 0
        detectDragGestures(
          onDragStart = { off -> val c = Offset(size.width / 2f, size.height / 2f); val dd = (off - c).getDistance() / density / z
            ringIdx = rings.indices.minByOrNull { abs(64f + gap0 * it - dd) } ?: 0; active = ringIdx; jobs[ringIdx]?.cancel(); omega[0] = 0f },
          onDragEnd = { val k = ringIdx; val v = omega[0] * 1000f; val step = 360f / rings[k].size
            jobs[k] = scope.launch { animateDecay(rot[k], v, FloatExponentialDecaySpec()) { value, _ -> rot[k] = value }; if (g.lock) { animate(rot[k], (rot[k] / step).roundToInt() * step) { value, _ -> rot[k] = value }; Snd.lock(g.sound, pick(k)) } } },
          onDrag = { ch, _ -> val c = Offset(size.width / 2f, size.height / 2f); val a1 = atan2(ch.previousPosition.y - c.y, ch.previousPosition.x - c.x); val a2 = atan2(ch.position.y - c.y, ch.position.x - c.x)
            var dd = Math.toDegrees((a2 - a1).toDouble()).toFloat(); if (dd > 180) dd -= 360; if (dd < -180) dd += 360
            rot[ringIdx] = rot[ringIdx] + dd; omega[0] = dd / maxOf(1L, ch.uptimeMillis - ch.previousUptimeMillis) }) },
      contentAlignment = Alignment.Center) {
      Column(Modifier.width((56 * z).dp).clip(RoundedCornerShape(12.dp)).clickable { go(rings[act][sel]) }, horizontalAlignment = Alignment.CenterHorizontally) {
        AppIcon(rings[act][sel], (30 * z).dp, go); Text(rings[act][sel].label, color = Color.White, fontSize = 10.sp, maxLines = 2, textAlign = TextAlign.Center, lineHeight = 11.sp) }
      rings.forEachIndexed { k, ap -> val step = 360f / ap.size; val rad = (64f + gap0 * k) * z
        ap.forEachIndexed { i, ai -> val ang = Math.toRadians((rot[k] + i * step - 90f).toDouble())
          Box(Modifier.offset { IntOffset((cos(ang) * rad.dp.roundToPx()).roundToInt(), (sin(ang) * rad.dp.roundToPx()).roundToInt()) }) { AppIcon(ai, (ic(k) * z).dp, go) } } } } }
}

// Cloud: a puffy cloud of overlapping circles with the apps in rows inside. A new cloud each time unless Random is off.
@OptIn(ExperimentalLayoutApi::class)
@Composable fun Cloud(g: Group, list: List<AppInfo>, go: (AppInfo) -> Unit) {
  val sz = g.size; val cfg = LocalConfiguration.current; val n = list.size.coerceAtLeast(1); val icon = 52f * sz; val cell = icon + 10f
  val cols = maxOf(2, minOf(ceil(sqrt(n * 1.6f)).toInt(), ((cfg.screenWidthDp - 90f) / cell).toInt().coerceAtLeast(2)))
  val puffs = remember { val r = Random(if (g.rnd) System.nanoTime() else 7L); List(14) { Triple(r.nextFloat(), r.nextFloat(), r.nextFloat()) } }
  Column(horizontalAlignment = Alignment.CenterHorizontally) { if (g.nameOwn && !g.loose) Name(g)
    Box(Modifier.padding(8.dp).pointerInput(Unit) { detectTapGestures { } }, Alignment.Center) {
      Box(Modifier.matchParentSize().cloudBg(Color(g.color), g.alpha, puffs, g, LocalFillPic.current))
      Column(Modifier.padding(30.dp), horizontalAlignment = Alignment.CenterHorizontally) { if (!g.nameOwn) Name(g, true)
        FlowRow(Modifier.width((cols * cell).dp), horizontalArrangement = Arrangement.Center, verticalArrangement = Arrangement.Center) { list.forEach { a -> Box(Modifier.size(cell.dp), Alignment.Center) { AppIcon(a, icon.dp, go) } } } } } }
}

// Blob: slime. It wobbles, stretches when you drag it, sloshes when you shake the phone, and the apps float around inside it.
@Composable fun Blob(g: Group, list: List<AppInfo>, go: (AppInfo) -> Unit, shakes: Flow<Offset>) {
  if (list.isEmpty()) return
  val dn = LocalDensity.current; val cfg = LocalConfiguration.current; val n = list.size; val d = dn.density; val sz = g.size; val fillPic = LocalFillPic.current
  val rc = (46f * sz / 2f + 3f) * d; val maxR = (cfg.screenWidthDp - 24f) / 2f * d
  val R = minOf(maxR * .85f, maxOf(100f * sz * d, sqrt(n * 4f * rc * rc / (.55f * 3.1416f))))
  val s = remember(n) { Array(4) { FloatArray(n) } }; val sq = remember { floatArrayOf(0f, 0f, 0f, 0f) }; val radii = remember { FloatArray(48) { R } }; var tick by remember { mutableIntStateOf(0) }
  LaunchedEffect(n) {
    for (i in 0 until n) { val an = i * 2.4f; val rad = (R - rc) * .8f * sqrt((i + .5f) / n); s[0][i] = cos(an) * rad; s[1][i] = sin(an) * rad; s[2][i] = (Random.nextFloat() - .5f) * 120f * d; s[3][i] = (Random.nextFloat() - .5f) * 120f * d }
    launch { shakes.collect { for (i in 0 until n) { s[2][i] += it.x * 1.2f; s[3][i] += it.y * 1.2f }; sq[2] += it.x * .3f; sq[3] += it.y * .3f } }
    var last = 0L; var tt = 0f
    while (true) { val t = withFrameNanos { it }; val dt = if (last == 0L) 0f else minOf(.03f, (t - last) / 1e9f); last = t; tt += dt
      for (i in 0 until n) { s[0][i] += s[2][i] * dt; s[1][i] += s[3][i] * dt
        val dist = hypot(s[0][i], s[1][i]); val lim = R - rc
        if (dist > lim && dist > .01f) { val nx = s[0][i] / dist; val ny = s[1][i] / dist; s[0][i] = nx * lim; s[1][i] = ny * lim; val vn = s[2][i] * nx + s[3][i] * ny
          if (vn > 0) { s[2][i] -= 1.8f * vn * nx; s[3][i] -= 1.8f * vn * ny; sq[2] += nx * vn * .02f; sq[3] += ny * vn * .02f } }
        val f = 1f - .5f * dt; s[2][i] = s[2][i] * f + (Random.nextFloat() - .5f) * 400f * d * dt; s[3][i] = s[3][i] * f + (Random.nextFloat() - .5f) * 400f * d * dt }
      for (i in 0 until n) for (j in i + 1 until n) { val dx = s[0][j] - s[0][i]; val dy = s[1][j] - s[1][i]; val dd = hypot(dx, dy); val md = rc * 2
        if (dd < md && dd > .01f) { val nx = dx / dd; val ny = dy / dd; val push = (md - dd) / 2; s[0][i] -= nx * push; s[1][i] -= ny * push; s[0][j] += nx * push; s[1][j] += ny * push
          val rv = (s[2][i] - s[2][j]) * nx + (s[3][i] - s[3][j]) * ny; if (rv > 0) { s[2][i] -= rv * nx; s[3][i] -= rv * ny; s[2][j] += rv * nx; s[3][j] += rv * ny } } }
      sq[0] += sq[2] * dt; sq[1] += sq[3] * dt; sq[2] += (-40f * sq[0] - 5f * sq[2]) * dt; sq[3] += (-40f * sq[1] - 5f * sq[3]) * dt   // the squish springs back
      for (k in 0 until 48) { val an = k * 2f * PI.toFloat() / 48; var r = R * (1f + .035f * sin(3f * an + tt * 2.2f) + .025f * sin(5f * an - tt * 3.1f)) + (sq[0] * cos(an) + sq[1] * sin(an)) * .5f
        for (i in 0 until n) { val dist = hypot(s[0][i], s[1][i]); val over = dist + rc - R * .9f   // an app pushing on the wall makes the slime bulge there
          if (over > 0f) { var da = abs(atan2(s[1][i], s[0][i]) - an); if (da > PI.toFloat()) da = 2f * PI.toFloat() - da; r += over * .8f * exp(-da * da / .12f) } }
        radii[k] = r }
      tick++ } }
  val box = (2f * R * 1.2f / d)
  Column(horizontalAlignment = Alignment.CenterHorizontally) { if (g.nameOwn && !g.loose) Name(g)
    Box(Modifier.size(box.dp).pointerInput(Unit) { detectDragGestures { _, dr -> sq[0] = (sq[0] + dr.x * .5f).coerceIn(-R * .35f, R * .35f); sq[1] = (sq[1] + dr.y * .5f).coerceIn(-R * .35f, R * .35f); for (i in 0 until n) { s[2][i] += dr.x * 8f; s[3][i] += dr.y * 8f } } }
      .drawBehind { val t = tick; val cx = size.width / 2; val cy = size.height / 2; val path = Path()
        fun pt(k: Int): Offset { val kk = (k + 48) % 48; val an = kk * 2f * PI.toFloat() / 48; return Offset(cx + cos(an) * radii[kk], cy + sin(an) * radii[kk]) }
        val st = (pt(47) + pt(0)) / 2f; path.moveTo(st.x, st.y); for (k in 0 until 48) { val c = pt(k); val e = (pt(k) + pt(k + 1)) / 2f; path.quadraticBezierTo(c.x, c.y, e.x, e.y) }; path.close()
        withFill(g, fillPic) { drawPath(path, Color(g.color).copy(alpha = g.alpha)) } }, Alignment.Center) {
      if (!g.nameOwn) Box(Modifier.align(Alignment.TopCenter).padding(top = 6.dp)) { Name(g, true) }
      list.forEachIndexed { i, a -> Box(Modifier.offset { val t = tick; IntOffset(s[0][i].roundToInt(), s[1][i].roundToInt()) }) { AppIcon(a, (46f * sz).dp, go) } } } }
}

// The cloud: a body inset from the edges with puffs sitting on its outline on all four sides, so everything stays inside the box and nothing can be clipped.
fun Modifier.cloudBg(color: Color, alpha: Float, puffs: List<Triple<Float, Float, Float>>, g: Group? = null, pic: ImageBitmap? = null) = drawBehind {
  val pw = size.width; val ph = size.height; val ins = 18.dp.toPx(); var k = 0
  drawIntoCanvas { cv -> cv.saveLayer(Rect(0f, 0f, pw, ph), Paint().apply { this.alpha = alpha })   // one even opacity where puffs overlap
    drawRoundRect(color, Offset(ins, ins), Size(pw - 2 * ins, ph - 2 * ins), CornerRadius(ins))
    fun puff(x: Float, y: Float) { val (a, b, c) = puffs[k++ % puffs.size]; drawCircle(color, (10f + c * 8f).dp.toPx(), Offset(x, y)) }
    val step = 24.dp.toPx(); var x = ins + step / 2
    while (x < pw - ins) { puff(x + (puffs[k % puffs.size].first - .5f) * 8.dp.toPx(), ins); puff(x, ph - ins); x += step }
    var y = ins + step / 2; while (y < ph - ins) { puff(ins, y + (puffs[k % puffs.size].second - .5f) * 8.dp.toPx()); puff(pw - ins, y); y += step }
    if (g != null && g.fill != "Solid") drawFill(g, pic, BlendMode.SrcAtop)
    cv.restore() }
}

@Composable fun Modifier.fillTexN(g: Group?): Modifier = if (g == null) this else fillTex(g)
