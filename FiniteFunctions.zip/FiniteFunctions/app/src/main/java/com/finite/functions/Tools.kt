package com.finite.functions
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

// The Tools tab: a grid of tools, each opening its own page. A new tool is one more card and one more page.
@Composable fun ToolsTab() {
  var open by remember { mutableStateOf<String?>(null) }
  BackHandler(enabled = open != null) { open = null }
  val o = open
  if (o == null) Column {
    Text("Tools", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 12.dp))
    LazyVerticalGrid(GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
      item { ToolCard("audio", "Volume boost", "Make your music louder") { open = "boost" } }
      item { ToolCard("scissors", "Audio cutter", "Cut a part out of a song") { open = "cut" } }
      item { ToolCard("imgbox", "GIF maker", "Turn a video or pictures into a GIF") { open = "gif" } }
      item { ToolCard("clock", "Playback speed", "Slow music down or speed it up") { open = "speed" } }
      item { ToolCard("qr", "QR maker", "Turn a link or text into a QR code") { open = "qr" } }
      item { ToolCard("convert", "Image converter", "Change pictures to JPEG, PNG or WEBP") { open = "img" } } } }
  else Column(Modifier.fillMaxSize()) {
    Row(verticalAlignment = Alignment.CenterVertically) { IcoBtn("left") { open = null }
      Text(when (o) { "boost" -> "Volume boost"; "cut" -> "Audio cutter"; "speed" -> "Playback speed"; "qr" -> "QR maker"; "img" -> "Image converter"; else -> "GIF maker" }, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
    if (o == "gif") Box(Modifier.weight(1f)) { GifPage() }   // the GIF maker scrolls by itself and keeps its Export bar pinned to the bottom
    else Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) { when (o) { "boost" -> BoostPage(); "speed" -> SpeedPage(); "qr" -> QrPage(); "img" -> ImgConvPage(); else -> CutterPage() } } }
}

@Composable fun ToolCard(icon: String, name: String, desc: String, f: () -> Unit) = GlassBox(RoundedCornerShape(16.dp), Modifier.fillMaxWidth().clickable { f() }) { Column(Modifier.padding(16.dp)) {
  Ico(icon, 30.dp); Spacer(Modifier.height(10.dp)); Text(name, color = Color.White, fontWeight = FontWeight.Bold); Text(desc, color = Color.Gray, fontSize = 12.sp) } }

// Volume boost: 100% (off) up to 400% in steps of 25, with a tick of vibration at each step. Applies to the Music tab and playlist bubbles.
@Composable fun BoostPage() {
  val c = LocalContext.current; val st = remember { Store(c) }; var v by remember { mutableStateOf(st.boost.toFloat()) }; val hap = LocalHapticFeedback.current
  Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth().padding(top = 16.dp)) {
    Text("${v.toInt()}%", color = Color.White, fontSize = 56.sp, fontWeight = FontWeight.Bold)
    Text(if (v == 100f) "Normal volume" else if (v < 100f) "Quieter than normal" else "Louder than the volume slider allows", color = Color.Gray, fontSize = 13.sp)
    TSlider(v, { n -> val s = (n / 25f).roundToInt() * 25f; if (s != v) { v = s; st.boost = s.toInt(); hap.performHapticFeedback(HapticFeedbackType.TextHandleMove) } }, Modifier.padding(vertical = 16.dp), valueRange = 50f..500f, steps = 17)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("50%", color = Color.Gray, fontSize = 12.sp); Text("500%", color = Color.Gray, fontSize = 12.sp) }
    Text("Applies to the Music tab and the playlist bubbles in your groups, and takes effect straight away on a song that's playing. Loud songs start to crackle sooner than quiet ones.", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 16.dp))
    Text("High boost can damage your hearing, especially in headphones. Android's own loud-volume warning doesn't see this boost.", color = Color(0xFFFF8A80), fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp)) }
}

// a major tool takes two slots: the card is as wide as two normal ones
@Composable fun MajorToolCard(icon: String, name: String, desc: String, f: () -> Unit) = GlassBox(RoundedCornerShape(16.dp), Modifier.fillMaxWidth().clickable { f() }) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
  Ico(icon, 38.dp); Spacer(Modifier.width(14.dp)); Column { Text(name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp); Text(desc, color = Color.Gray, fontSize = 12.sp) } } }
