package com.finite.functions
import android.content.*
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.RectF
import android.media.MediaMetadataRetriever
import java.io.File
import android.graphics.Paint
import android.net.Uri
import android.widget.Toast
import androidx.core.content.edit
import androidx.core.net.toUri
import androidx.core.graphics.createBitmap
import androidx.core.graphics.scale
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import org.json.*

data class Song(val u: String, val t: String)
data class Group(val id: String, val name: String, val color: Long = 0xFF222222, val icolor: Long = 0xFF222222, val anim: String = "Scale", val mode: String = "Collage", val preset: String = "controller", val pic: String = "", val apps: List<String> = listOf(), val shape: String = "Soft", val blur: Boolean = false, val alpha: Float = 1f, val namePos: String = "Middle", val size: Float = 1f, val loose: Boolean = false, val wshape: String = "Circle", val nameOwn: Boolean = true, val sound: String = "Rolling", val lock: Boolean = true, val rnd: Boolean = true, val glyph: Long = 0L, val plLook: String = "", val ringMap: String = "", val font: String = "", val fill: String = "Solid", val fillPic: String = "")
data class AppInfo(val pkg: String, val label: String)

class Store(c: Context) {
  val p: SharedPreferences = c.getSharedPreferences("ff", 0)
  var speed: Float get() = p.getFloat("speed", 1f); set(v) { p.edit { putFloat("speed", v) } }   // playback speed, 1 = normal
  var keepPitch: Boolean get() = p.getBoolean("keeppitch", true); set(v) { p.edit { putBoolean("keeppitch", v) } }
  var theme: String get() = p.getString("theme", "None")!!; set(v) { p.edit { putString("theme", v) } }
  var themeHue: Float get() = p.getFloat("thhue", -1f); set(v) { p.edit { putFloat("thhue", v) } }
  var boost: Int get() = p.getInt("boost", 100); set(v) { p.edit { putInt("boost", v) } }   // volume boost in percent, 100 = off
  var libMode: String get() = p.getString("libmode", "Move")!!; set(v) { p.edit { putString("libmode", v) } }   // Move into the app folder, or Shortcut only
  var tileSize: Float get() = p.getFloat("tsize", 1f); set(v) { p.edit { putFloat("tsize", v) } }
  var tileStack: String get() = p.getString("tstack", "Grid")!!; set(v) { p.edit { putString("tstack", v) } }
  var tileCover: String get() = p.getString("tcover", "Full")!!; set(v) { p.edit { putString("tcover", v) } }
  var tileOrder: List<String> get() = p.getString("torder", "")!!.split(",").filter { it.isNotEmpty() }; set(v) { p.edit { putString("torder", v.joinToString(",")) } }
  fun orderedGroups(): List<Group> { val o = tileOrder; return groups().sortedBy { (id) -> o.indexOf(id).let { if (it < 0) Int.MAX_VALUE else it } } }   // the order set in Settings; new groups go last
  var showNames: Boolean get() = p.getBoolean("shownames", false); set(v) { p.edit { putBoolean("shownames", v) } }
  init { if (!p.getBoolean("mig_beam", false)) { saveGroups(groups().map { if (it.anim == "Cut") it.copy(anim = "Beam") else it }); p.edit { putBoolean("mig_beam", true) } } }   // old Cut became Beam
  fun lib(): LinkedHashMap<String, MutableList<Song>> {
    val m = LinkedHashMap<String, MutableList<Song>>(); val j = JSONObject(p.getString("lib", "{\"All\":[]}")!!)
    j.keys().forEach { k -> val a = j.getJSONArray(k); m[k] = MutableList(a.length()) { i -> a.getJSONObject(i).let { Song(it.getString("u"), it.getString("t")) } } }
    val all = m.getOrPut("All") { mutableListOf() }; val seen = all.mapTo(mutableSetOf()) { (u) -> u }   // All always holds every song from every playlist
    m.values.toList().forEach { l -> l.forEach { s -> if (seen.add(s.u)) all.add(s) } }
    return m }
  fun saveLib(m: Map<String, List<Song>>) { val j = JSONObject(); m.forEach { (k, v) -> j.put(k, JSONArray(v.map { (u, t) -> JSONObject().put("u", u).put("t", t) })) }; p.edit { putString("lib", j.toString()) } }
  fun groups(): List<Group> { val a = JSONArray(p.getString("groups", "[]")); return List(a.length()) { i -> a.getJSONObject(i).let { Group(it.getString("id"), it.getString("name"), it.getLong("color"), it.optLong("icolor", 0xFF222222), it.getString("anim"), it.getString("mode"), it.getString("preset").let { p -> if (p in ICONS) p else "controller" }, it.getString("pic"), it.getString("apps").split(",").filter { s -> s.isNotEmpty() }, shape = it.optString("shape", "Soft"), blur = it.optBoolean("blur"), alpha = it.optDouble("alpha", 1.0).toFloat(), namePos = it.optString("namePos", "Middle"), size = it.optDouble("size", 1.0).toFloat(), loose = it.optBoolean("loose"), wshape = it.optString("wshape", "Circle"), nameOwn = it.optBoolean("nameOwn", true), sound = it.optString("sound", if (it.optBoolean("click", true)) "Rolling" else "Off"), lock = it.optBoolean("lock", true), rnd = it.optBoolean("rnd", true), glyph = it.optLong("glyph", 0L), plLook = it.optString("plLook", ""), ringMap = it.optString("ringMap", ""), font = it.optString("font", ""), fill = it.optString("fill", "Solid"), fillPic = it.optString("fillPic", "")) } } }
  fun saveGroups(l: List<Group>) { p.edit { putString("groups", JSONArray(l.map { JSONObject().put("id", it.id).put("name", it.name).put("color", it.color).put("icolor", it.icolor).put("anim", it.anim).put("mode", it.mode).put("preset", it.preset).put("pic", it.pic).put("apps", it.apps.joinToString(",")).put("shape", it.shape).put("blur", it.blur).put("alpha", it.alpha.toDouble()).put("namePos", it.namePos).put("size", it.size.toDouble()).put("loose", it.loose).put("wshape", it.wshape).put("nameOwn", it.nameOwn).put("sound", it.sound).put("lock", it.lock).put("rnd", it.rnd).put("glyph", it.glyph).put("plLook", it.plLook).put("ringMap", it.ringMap).put("font", it.font).put("fill", it.fill).put("fillPic", it.fillPic) }).toString()) } }
}

fun Context.apps(): List<AppInfo> = packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
  .asSequence().map { AppInfo(it.activityInfo.packageName, it.loadLabel(packageManager).toString()) }.filter { it.pkg != packageName }.distinctBy { it.pkg }.sortedBy { it.label.lowercase() }.toList()
fun Context.launch(pkg: String) { val i = packageManager.getLaunchIntentForPackage(pkg)
  if (i == null) { Toast.makeText(this, "Couldn't open this app", Toast.LENGTH_SHORT).show(); return }
  try { startActivity(i) } catch (_: Exception) { Toast.makeText(this, "Couldn't open this app", Toast.LENGTH_SHORT).show() } }

fun Context.groupBitmap(g: Group): Bitmap {
  val b = createBitmap(432, 432); val c = Canvas(b); val pt = Paint(Paint.ANTI_ALIAS_FLAG)
  pt.color = g.icolor.toInt(); c.drawRect(0f, 0f, 432f, 432f, pt)
  runCatching { when (g.mode) {
    "Picture" -> loadBmp(g.pic, 432)?.let { c.drawBitmap(it.scale(432, 432), 0f, 0f, null) }
    "Preset" -> drawIcon(c, g.preset, 216f, 216f, 200f, if (g.glyph != 0L) g.glyph.toInt() else if (Color(g.icolor).luminance() > .6f) -16777216 else -1)
    else -> g.apps.asSequence().filter { !it.startsWith("pl:") }.take(4).forEachIndexed { i, p -> c.drawBitmap(packageManager.getApplicationIcon(p).toBitmap(120, 120), 96f + ((i % 2) * 130f), 96f + ((i / 2) * 130f), null) } } }
  return b }

@Composable fun AppItem(a: AppInfo, shape: Shape = RoundedCornerShape(22), label: Boolean = true, size: Dp = 56.dp, onClick: () -> Unit) {
  Column(Modifier.padding(6.dp).clickable { onClick() }, horizontalAlignment = Alignment.CenterHorizontally) {
    ItemIcon(a, size, shape)
    if (label) Text(a.label, color = Color.White, fontSize = if (a.label.length > 22) 9.sp else 11.sp, maxLines = 2, lineHeight = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.widthIn(max = (size.value + 28f).dp)) }
}
@Composable fun Pick(t: String, on: Boolean, f: () -> Unit) = Text(t, color = chipText(on), modifier = Modifier.padding(end = 6.dp).chipLook(on).clickable { f() }.padding(horizontal = 14.dp, vertical = 8.dp))
@Composable fun Tx(t: String, f: () -> Unit) = Text(t, color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 2.dp).clip(RoundedCornerShape(50)).background(Color(0xFF333333)).clickable { f() }.padding(horizontal = 10.dp, vertical = 6.dp))

fun Store.covers(): Map<String, String> { val j = JSONObject(p.getString("covers", "{}")!!); return j.keys().asSequence().associateWith { j.getString(it) } }
fun Store.setCover(u: String, c: String) { val j = JSONObject(p.getString("covers", "{}")!!); j.put(u, c); p.edit { putString("covers", j.toString()) }; val q = JSONObject(p.getString("cpos", "{}")!!); q.remove(u); p.edit { putString("cpos", q.toString()) } }
fun Store.removeCover(u: String) { val j = JSONObject(p.getString("covers", "{}")!!); j.remove(u); val q = JSONObject(p.getString("cpos", "{}")!!); q.remove(u); p.edit { putString("covers", j.toString()).putString("cpos", q.toString()) } }
fun Store.coverPos(u: String): FloatArray { val a = JSONObject(p.getString("cpos", "{}")!!).optJSONArray(u) ?: return floatArrayOf(0f, 0f, 1f); return floatArrayOf(a.getDouble(0).toFloat(), a.getDouble(1).toFloat(), a.getDouble(2).toFloat()) }
fun Store.setCoverPos(u: String, x: Float, y: Float, z: Float) { val q = JSONObject(p.getString("cpos", "{}")!!); q.put(u, JSONArray(listOf(x.toDouble(), y.toDouble(), z.toDouble()))); p.edit { putString("cpos", q.toString()) } }
fun Store.customColors(k: String): List<Long> = p.getString("cc_$k", "")!!.split(",").asSequence().filter { it.isNotEmpty() }.map { it.toLong() }.toList()
fun Store.addColor(k: String, c: Long) { if (c !in customColors(k)) p.edit { putString("cc_$k", (customColors(k) + c).joinToString(",")) } }
fun Store.removeColor(k: String, c: Long) { p.edit { putString("cc_$k", (customColors(k) - c).joinToString(",")) } }
// Photos are read at a sensible size, not full size, so opening things stays quick
fun Context.loadBmp(u: String, max: Int = 600): Bitmap? = runCatching {
  val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }; contentResolver.openInputStream(u.toUri()).use { BitmapFactory.decodeStream(it, null, o) }
  var s = 1; while (((o.outWidth / (s * 2)) >= max) && ((o.outHeight / (s * 2)) >= max)) s *= 2
  contentResolver.openInputStream(u.toUri()).use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s }) } }.getOrNull()
fun Context.loadImg(u: String): androidx.compose.ui.graphics.ImageBitmap? = loadBmp(u)?.asImageBitmap()

// The playlist that is playing right now (by name), so its bubble can show pause instead of the music note
val LocalPlaying = compositionLocalOf<String?> { null }

// One look per playlist bubble, set per group: "" = music note (or a song cover), "icon:<name>", "name", "pic:<uri>"
val LocalPlLook = compositionLocalOf<Map<String, String>> { emptyMap() }
fun Group.looks(): Map<String, String> = runCatching { val j = JSONObject(plLook.ifEmpty { "{}" }); j.keys().asSequence().associateWith { j.getString(it) } }.getOrDefault(emptyMap())

// App icons are turned into pictures once and kept, and prepared in the background when the quick settings panel opens
object IconCache { private val m = java.util.concurrent.ConcurrentHashMap<String, androidx.compose.ui.graphics.ImageBitmap>()
  fun get(c: Context, pkg: String): androidx.compose.ui.graphics.ImageBitmap = m.getOrPut(pkg) { c.packageManager.getApplicationIcon(pkg).toBitmap(144, 144).asImageBitmap() } }
object AppCache { @Volatile var apps: List<AppInfo>? = null
  fun warm(c: Context) { val app = c.applicationContext; Thread { runCatching { apps = app.apps(); Store(app).groups().flatMap { it.apps }.distinct().filter { !it.startsWith("pl:") }.forEach { runCatching { IconCache.get(app, it) } } } }.start() } }

// An app icon, or for a playlist ("pl:" items) a bubble: song cover or note, a symbol, its name, or your picture. A pause badge shows while it plays.
@Composable fun ItemIcon(a: AppInfo, size: Dp, clip: Shape = CircleShape, pad: Dp = 0.dp, onClick: (() -> Unit)? = null) {
  val c = LocalContext.current; val m = Modifier.padding(pad).size(size).clip(clip).then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
  if (a.pkg.startsWith("pl:")) { val playing = LocalPlaying.current == a.label; val look = LocalPlLook.current[a.label] ?: ""
    val img = remember(a.label, look) { if (look.startsWith("pic:")) c.loadImg(look.removePrefix("pic:")) else if (look == "") { val st = Store(c); val cv = st.effCovers(); st.lib()[a.label]?.firstNotNullOfOrNull { sg -> cv[sg.u] }?.let { c.loadImg(it) } } else null }
    Box(m.background(Color(0xFF2A2A2A)), Alignment.Center) {
      if (img != null) { Image(img, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop); if (look == "") Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .45f))) }
      if (look == "name") Text(a.label, color = Color.White, fontSize = (size.value * .2f).sp, maxLines = 2, textAlign = TextAlign.Center, lineHeight = (size.value * .22f).sp, modifier = Modifier.padding(6.dp))
      else if (look.startsWith("icon:") && (look.removePrefix("icon:") in ICONS)) Ico(look.removePrefix("icon:"), size * .5f, Color.White)
      else if (!look.startsWith("pic:")) Ico("music", size * .5f, Color.White)
      if (playing) Box(Modifier.align(Alignment.BottomEnd).padding(2.dp).size(size * .34f).clip(CircleShape).background(Color.White), Alignment.Center) { Ico("pause", size * .2f, Color.Black) } } }
  else Image(remember(a.pkg) { IconCache.get(c, a.pkg) }, null, m)
}

// Cover that rings are built from: which ring each app sits on (apps with no choice fill the rings from the inside out)
fun Group.rings(): Map<String, Int> = runCatching { val j = JSONObject(ringMap.ifEmpty { "{}" }); j.keys().asSequence().associateWith { j.getInt(it) } }.getOrDefault(emptyMap())
fun buildRingsRaw(list: List<AppInfo>, m: Map<String, Int>): List<List<AppInfo>> {
  val cap = { k: Int -> maxOf(3, (6.283f * (64f + 62f * k) / 56f).toInt()) }; val rows = ArrayList<MutableList<AppInfo>>()
  fun ring(k: Int): MutableList<AppInfo> { while (rows.size <= k) rows.add(mutableListOf()); return rows[k] }
  list.forEach { a -> m[a.pkg]?.let { ring(it.coerceAtLeast(0)).add(a) } }
  list.forEach { a -> if (m[a.pkg] == null) { var k = 0; while (ring(k).size >= cap(k)) k++; ring(k).add(a) } }
  return rows }
fun buildRings(list: List<AppInfo>, m: Map<String, Int>) = buildRingsRaw(list, m).filter { it.isNotEmpty() }

// Covers: yours, or the album art inside the MP3 (yours wins). Both feed the media card on the lock screen and notifications.
fun Store.embedded(): Map<String, String> { val j = JSONObject(p.getString("emb", "{}")!!); return j.keys().asSequence().associateWith { j.getString(it) } }
fun Store.setEmbedded(u: String, c: String) { val j = JSONObject(p.getString("emb", "{}")!!); j.put(u, c); p.edit { putString("emb", j.toString()) } }
fun Store.effCovers(): Map<String, String> = embedded() + covers()
fun Store.artUri(u: String): Uri? = JSONObject(p.getString("art", "{}")!!).optString(u, "").takeIf { it.isNotEmpty() }?.toUri()
fun Context.extractArt(uri: String): String? = runCatching { val r = MediaMetadataRetriever()
  try { r.setDataSource(this, uri.toUri()); val b = r.embeddedPicture ?: return@runCatching null
    val f = File(File(filesDir, "art").apply { mkdirs() }, "e${uri.hashCode()}.jpg"); f.writeBytes(b); Uri.fromFile(f).toString() } finally { r.release() } }.getOrNull()
// a square copy of the cover, cropped the way you set it, handed to Android as the song's artwork
fun Context.refreshArt(u: String) { val st = Store(this); val cv = st.effCovers()[u]; val q = JSONObject(st.p.getString("art", "{}")!!)
  if (cv == null) { q.remove(u); st.p.edit { putString("art", q.toString()) }; return }
  val bmp = loadBmp(cv, 700) ?: return; val pos = st.coverPos(u); val s = 512
  val out = createBitmap(s, s); val s0 = maxOf(s / bmp.width.toFloat(), s / bmp.height.toFloat()) * pos[2]; val dw = bmp.width * s0; val dh = bmp.height * s0
  val x = (s - dw) / 2 + pos[0] * (dw - s) / 2; val y = (s - dh) / 2 + pos[1] * (dh - s) / 2
  Canvas(out).drawBitmap(bmp, null, RectF(x, y, x + dw, y + dh), Paint(Paint.FILTER_BITMAP_FLAG))
  val f = File(cacheDir, "art${u.hashCode()}_${System.nanoTime()}.jpg"); f.outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 88, it) }
  q.put(u, Uri.fromFile(f).toString()); st.p.edit { putString("art", q.toString()) } }

// Fonts you add: the file is copied into the app's own storage, so it keeps working if the original moves
object Fonts {
  fun dir(c: Context) = File(c.filesDir, "fonts").apply { mkdirs() }
  fun list(c: Context): List<String> = (dir(c).listFiles() ?: emptyArray()).map { it.name }.sorted()
  private val cache = java.util.concurrent.ConcurrentHashMap<String, androidx.compose.ui.text.font.FontFamily>()
  fun family(c: Context, name: String): androidx.compose.ui.text.font.FontFamily? {
    if (name.isEmpty()) return null; cache[name]?.let { return it }
    return runCatching { androidx.compose.ui.text.font.FontFamily(android.graphics.Typeface.Builder(File(dir(c), name)).build()!!) }.getOrNull()?.also { cache[name] = it } }
  fun add(c: Context, uri: Uri): String? = runCatching {
    var n = c.contentResolver.query(uri, null, null, null, null)?.use { if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(android.provider.OpenableColumns.DISPLAY_NAME)) else null } ?: "font.ttf"
    n = n.replace(Regex("[^A-Za-z0-9._ -]"), "_"); val f = File(dir(c), n)
    c.contentResolver.openInputStream(uri).use { i -> f.outputStream().use { o -> i!!.copyTo(o) } }
    if (android.graphics.Typeface.Builder(f).build() == null) { f.delete(); null } else { cache.remove(n); n } }.getOrNull()
  fun remove(c: Context, name: String) { File(dir(c), name).delete(); cache.remove(name) }
}

// Pictures you pick are copied into the app's storage (shrunk), so they survive a reinstall and don't need file permission
fun Context.keepPic(u: Uri): String = runCatching { val b = loadBmp(u.toString(), 1200)!!
  val f = File(File(filesDir, "pics").apply { mkdirs() }, "p${u.hashCode()}_${System.nanoTime()}.jpg"); f.outputStream().use { b.compress(Bitmap.CompressFormat.JPEG, 88, it) }; Uri.fromFile(f).toString() }.getOrDefault(u.toString())
