package com.finite.functions
import androidx.compose.animation.ContentTransform
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.Path
import kotlin.math.sin
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Buttons, chips, toggles, sliders and the tab bar all change with the theme. With None they are the normal Material ones.
enum class BtnKind { Filled, Outlined, Text }

val LocalThemeT = staticCompositionLocalOf<State<Float>> { mutableFloatStateOf(0f) }
val LocalBackdrop = staticCompositionLocalOf<GraphicsLayer?> { null }

// Frosted glass: the theme's background, blurred, behind a translucent tint with a thin bright edge. Used for dropdown headers, tool cards and buttons.
@Composable fun GlassBox(shape: Shape, modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
  val layer = LocalBackdrop.current; var pos by remember { mutableStateOf(Offset.Zero) }
  Box(modifier.onGloballyPositioned { pos = it.positionInRoot() }.clip(shape).background(Color.White.copy(alpha = .07f)).border(1.dp, Color.White.copy(alpha = .22f), shape)) {
    if (layer != null) Canvas(Modifier.matchParentSize().blur(18.dp, BlurredEdgeTreatment.Rectangle)) { translate(-pos.x, -pos.y) { drawLayer(layer) } }
    Box(Modifier.matchParentSize().background(Color.White.copy(alpha = .06f)))
    content() } }

@Composable private fun ThemedButtonImpl(kind: BtnKind, onClick: () -> Unit, modifier: Modifier, enabled: Boolean, override: Color?, content: @Composable RowScope.() -> Unit) {
  val a = Th.accent; val b = Th.second; val st = Th.style
  val shape: Shape = when (st) { "Neon grid" -> RoundedCornerShape(2.dp); "Sunset plains" -> RoundedCornerShape(24.dp); else -> RoundedCornerShape(50) }
  var m: Modifier = Modifier.alpha(if (enabled) 1f else .4f); var tc = if (st == "None") Color.White else a; val f = kind == BtnKind.Filled; val o = kind == BtnKind.Outlined
  when (st) {
    "Aurora" -> if (f || o) m = m.border(1.5.dp, Brush.horizontalGradient(listOf(a, b)), shape)
    "Bubbles" -> { if (f) { m = m.border(2.dp, a.copy(alpha = .85f), shape); tc = Color.White } else if (o) m = m.border(2.dp, a.copy(alpha = .5f), shape) }
    "Neon grid" -> if (f) m = m.border(2.dp, a, shape) else if (o) m = m.border(1.5.dp, a.copy(alpha = .6f), shape)
    "Sunset plains" -> { tc = b; if (f) { m = m.border(1.5.dp, Brush.verticalGradient(listOf(a, b)), shape); tc = Color.White } else if (o) m = m.border(1.5.dp, b, shape) }
    else -> if (o) m = m.border(1.dp, Color.White.copy(alpha = .4f), shape)
  }
  val inner: @Composable () -> Unit = { Row(Modifier.clip(shape).clickable(enabled) { onClick() }.padding(horizontal = if (kind == BtnKind.Text) 12.dp else 20.dp, vertical = 10.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
    CompositionLocalProvider(LocalContentColor provides (override ?: tc)) { ProvideTextStyle(TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 14.sp)) { content() } } } }
  if (f) GlassBox(shape, modifier.then(m)) { inner() } else Box(modifier.then(m)) { inner() }
}

@Composable fun TButton(onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, content: @Composable RowScope.() -> Unit) { ThemedButtonImpl(BtnKind.Filled, onClick, modifier, enabled, null, content) }
@Composable fun TOutlinedButton(onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, content: @Composable RowScope.() -> Unit) {
  if (Th.style == "None") OutlinedButton(onClick, modifier, enabled, content = content) else ThemedButtonImpl(BtnKind.Outlined, onClick, modifier, enabled, null, content) }
@Composable fun TTextButton(onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, danger: Boolean = false, content: @Composable RowScope.() -> Unit) {
  if (Th.style == "None") TextButton(onClick, modifier, enabled, colors = if (danger) ButtonDefaults.textButtonColors(contentColor = Color(0xFFFF5252)) else ButtonDefaults.textButtonColors(), content = content)
  else ThemedButtonImpl(BtnKind.Text, onClick, modifier, enabled, if (danger) Color(0xFFFF5252) else null, content) }

// Toggles: Aurora a glowing gradient pill, Bubbles a hollow bubble, Neon grid a square neon switch, Sunset plains a little sun.
@Composable fun TSwitch(checked: Boolean, onCheckedChange: ((Boolean) -> Unit)?, modifier: Modifier = Modifier, enabled: Boolean = true) {
  if (Th.style == "None") { Switch(checked, onCheckedChange, modifier, enabled = enabled); return }
  val a = Th.accent; val b = Th.second; val th = Th.style; val x by animateDpAsState(if (checked) 22.dp else 0.dp, tween(220))
  val trackShape: Shape = if (th == "Neon grid") RoundedCornerShape(2.dp) else RoundedCornerShape(50)
  val track = when (th) { "Aurora" -> if (checked) Modifier.background(Brush.horizontalGradient(listOf(a, b))) else Modifier.background(Th.card2)
    "Bubbles" -> Modifier.background(a.copy(alpha = if (checked) .3f else .08f)).border(2.dp, a.copy(alpha = if (checked) .9f else .35f), trackShape)
    "Neon grid" -> Modifier.background(if (checked) Th.card else Color.Transparent).border(2.dp, a.copy(alpha = if (checked) 1f else .4f), trackShape)
    else -> if (checked) Modifier.background(Brush.horizontalGradient(listOf(a, b))) else Modifier.background(Th.card2) }
  Box(modifier.alpha(if (enabled) 1f else .4f).size(52.dp, 30.dp).clip(trackShape).then(track).clickable(enabled && onCheckedChange != null) { onCheckedChange?.invoke(!checked) }.padding(3.dp)) {
    val thumbShape: Shape = if (th == "Neon grid") RoundedCornerShape(2.dp) else CircleShape
    val thumb = when (th) { "Bubbles" -> Modifier.border(2.dp, if (checked) Color.White else a, thumbShape).background(Color.White.copy(alpha = .15f))
      "Neon grid" -> Modifier.background(if (checked) a else a.copy(alpha = .4f))
      "Sunset plains" -> Modifier.background(if (checked) Color(0xFFFFF3C4) else b.copy(alpha = .6f))
      else -> Modifier.background(Color.White) }
    Box(Modifier.offset(x = x).size(24.dp).clip(thumbShape).then(thumb)) } }

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun TSlider(value: Float, onValueChange: (Float) -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, valueRange: ClosedFloatingPointRange<Float> = 0f..1f, steps: Int = 0) {
  if (Th.style == "None") { Slider(value = value, onValueChange = onValueChange, modifier = modifier, enabled = enabled, valueRange = valueRange, steps = steps); return }
  val a = Th.accent; val b = Th.second; val th = Th.style
  Slider(value = value, onValueChange = onValueChange, modifier = modifier, enabled = enabled, valueRange = valueRange, steps = steps,
    colors = SliderDefaults.colors(thumbColor = a, activeTrackColor = a, inactiveTrackColor = Th.card2, activeTickColor = Color.Black.copy(alpha = .5f), inactiveTickColor = a.copy(alpha = .4f)),
    thumb = { when (th) { "Bubbles" -> Box(Modifier.size(24.dp).clip(CircleShape).border(2.dp, a, CircleShape).background(a.copy(alpha = .2f)))
      "Neon grid" -> Box(Modifier.size(18.dp).background(Th.card).border(2.dp, a))
      "Sunset plains" -> Box(Modifier.size(22.dp).clip(CircleShape).background(Brush.verticalGradient(listOf(Color(0xFFFFF3C4), b))))
      else -> Box(Modifier.size(22.dp).clip(CircleShape).background(Brush.horizontalGradient(listOf(a, b)))) } }) }

// chips (the pick buttons) follow the theme too
@Composable fun Modifier.chipLook(on: Boolean): Modifier { val a = Th.accent; val b = Th.second; val shape = Th.chipShape
  return when (Th.style) {
    "Aurora" -> clip(shape).background(if (on) Brush.horizontalGradient(listOf(a, b)) else Brush.horizontalGradient(listOf(Th.card2, Th.card2)))
    "Bubbles" -> if (on) clip(shape).background(a.copy(alpha = .3f)).border(2.dp, a, shape) else clip(shape).background(a.copy(alpha = .08f)).border(1.dp, a.copy(alpha = .35f), shape)
    "Neon grid" -> clip(shape).background(if (on) Th.card else Color.Transparent).border(if (on) 2.dp else 1.dp, a.copy(alpha = if (on) 1f else .35f), shape)
    "Sunset plains" -> clip(shape).background(if (on) Brush.verticalGradient(listOf(a, b)) else Brush.verticalGradient(listOf(Th.card2, Th.card2)))
    else -> clip(shape).background(if (on) Color.White else Th.card2) } }
@Composable fun chipText(on: Boolean): Color = when (Th.style) { "Bubbles" -> Color.White; "Neon grid" -> if (on) Th.accent else Th.accent.copy(alpha = .7f); else -> if (on) Color.Black else Color.White }

// the tab bar, in the style of the theme (None keeps the normal one)
@Composable fun ThemedNavBar(selected: Int, onSelect: (Int) -> Unit) {
  val items = listOf("Tools" to "wrench", "Library" to "folder", "Music" to "music", "Groups" to "grid", "Settings" to "info"); val a = Th.accent; val b = Th.second; val st = Th.style; val clock = LocalThemeT.current
  val bar = when (st) {
    "Aurora" -> Modifier.padding(horizontal = 12.dp, vertical = 8.dp).clip(RoundedCornerShape(28.dp)).background(Th.nav.copy(alpha = .92f)).border(1.5.dp, Brush.horizontalGradient(listOf(a, b)), RoundedCornerShape(28.dp))
    "Bubbles" -> Modifier.padding(horizontal = 12.dp, vertical = 8.dp).clip(RoundedCornerShape(50)).background(a.copy(alpha = .10f)).border(2.dp, a.copy(alpha = .5f), RoundedCornerShape(50))
    "Neon grid" -> Modifier.background(Th.nav).drawBehind { drawLine(a, Offset(0f, 0f), Offset(size.width, 0f), 2.dp.toPx()) }
    else -> Modifier }
  // the system inset sits outside the pill, so the space around the Aurora and Bubbles bars stays see-through and the icons sit in the middle
  val rowMod = if (st == "Neon grid") Modifier.fillMaxWidth().then(bar).navigationBarsPadding() else if (st == "Sunset plains") Modifier.fillMaxWidth().navigationBarsPadding() else Modifier.fillMaxWidth().navigationBarsPadding().then(bar)
  Box(Modifier.fillMaxWidth()) {
    if (st == "Sunset plains") Canvas(Modifier.matchParentSize()) {   // a movie-style ocean: waves along the top, the sun or moon glinting on the water, a ripple under the chosen tab
      val t = clock.value; val w = size.width; val h = size.height; val base = 14.dp.toPx()
      drawRect(Brush.verticalGradient(listOf(Th.fam(.4f).copy(alpha = .55f), Th.bg), startY = base, endY = h), Offset(0f, base), androidx.compose.ui.geometry.Size(w, h - base))
      val (cxf, elev, isSun) = celestial(t); val gx = cxf * w; val inten = (elev * 1.3f).coerceIn(0f, 1f); val light = if (isSun) Color(0xFFFFE9B0) else Color(0xFFDDE6FF)
      for (k in 0 until 9) { val y = base + 6.dp.toPx() + k * (h - base) / 10f; val dw = (6f + k * 5f).dp.toPx() * (1f + .3f * sin(t * 3f + k * 2f)); val off = sin(t * 2f + k) * 6.dp.toPx(); drawLine(light.copy(alpha = inten * (1f - k / 10f) * .8f), Offset(gx - dw / 2 + off, y), Offset(gx + dw / 2 + off, y), 2.dp.toPx()) }
      for (i in 0 until 3) { val p = Path(); p.moveTo(0f, base); var x = 0f; while (x <= w) { p.lineTo(x, base + sin(x / 38.dp.toPx() + t * (1f + i * .4f) + i * 1.7f) * (3f + i).dp.toPx()); x += 8f }; drawPath(p, Th.fam(.75f).copy(alpha = .55f - .15f * i), style = Stroke((2.2f - .4f * i).dp.toPx())) }
      val rx = (selected + .5f) / 5f * w; val ry = base + (h - base) * .62f
      for (r in 0 until 2) { val ph = (t * .6f + r * .5f) % 1f; drawOval(Color.White.copy(alpha = (1f - ph) * .5f), Offset(rx - ph * 44.dp.toPx(), ry - ph * 9.dp.toPx()), androidx.compose.ui.geometry.Size(ph * 88.dp.toPx(), ph * 18.dp.toPx()), style = Stroke(1.5.dp.toPx())) } }
    Row(rowMod, verticalAlignment = Alignment.CenterVertically) { items.forEachIndexed { i, (name, ic) -> val on = selected == i
      val sc by animateFloatAsState(if (on) 1.18f else 1f, tween(250)); val tint = if (on) (if (st == "Sunset plains") Color.White else a) else (if (st == "Sunset plains") Color.White.copy(alpha = .6f) else Color.Gray)
      Column(Modifier.weight(1f).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onSelect(i) }.padding(vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.height(48.dp), Alignment.Center) {   // every icon gets the same fixed slot, so they line up
          val look = when (st) { "Bubbles" -> if (on) Modifier.size(46.dp).clip(CircleShape).background(a.copy(alpha = .3f)).border(2.dp, a, CircleShape) else Modifier.size(46.dp)
            "Aurora" -> if (on) Modifier.clip(RoundedCornerShape(50)).background(Brush.horizontalGradient(listOf(a.copy(alpha = .5f), b.copy(alpha = .5f)))).padding(horizontal = 16.dp, vertical = 4.dp) else Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            "Neon grid" -> Modifier.drawBehind { if (on) drawLine(a, Offset(0f, size.height + 4.dp.toPx()), Offset(size.width, size.height + 4.dp.toPx()), 2.dp.toPx()) }.padding(4.dp)
            else -> Modifier.padding(4.dp) }
          Box(Modifier.graphicsLayer { scaleX = sc; scaleY = sc }.then(look), Alignment.Center) { Ico(ic, 24.dp, tint, if (i == 3) Modifier.graphicsLayer { rotationZ = 45f; scaleX = .78f; scaleY = .78f } else Modifier) } }
        Text(name, color = tint, fontSize = 11.sp) } } } }
}

// switching sections plays an animation that depends on the theme
fun themeTransition(from: Int, to: Int): ContentTransform { val dir = if (to > from) 1 else -1
  return when (Th.style) {
    "Aurora" -> (fadeIn(tween(450)) + slideInVertically(tween(450)) { it / 14 }) togetherWith (fadeOut(tween(250)) + slideOutVertically(tween(250)) { -it / 14 })
    "Bubbles" -> (fadeIn(tween(350)) + scaleIn(tween(350), initialScale = .85f)) togetherWith (fadeOut(tween(200)) + scaleOut(tween(200), targetScale = 1.1f))
    "Neon grid" -> (slideInHorizontally(tween(260)) { dir * it } + fadeIn(tween(200))) togetherWith (slideOutHorizontally(tween(260)) { -dir * it } + fadeOut(tween(200)))
    "Sunset plains" -> (fadeIn(tween(700)) + slideInVertically(tween(700)) { it / 20 }) togetherWith fadeOut(tween(450))
    else -> EnterTransition.None togetherWith ExitTransition.None } }
