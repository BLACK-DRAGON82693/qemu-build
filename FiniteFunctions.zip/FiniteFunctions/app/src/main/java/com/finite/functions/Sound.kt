package com.finite.functions
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.pow
import kotlin.math.sin
import kotlin.random.Random

// Synthesized sounds (no audio files). Every buffer is built and loaded ahead of time, in low-latency mode, so a tick lands when the app passes.
object Snd {
  private const val SR = 22050
  private val tracks = java.util.concurrent.ConcurrentHashMap<String, AudioTrack>(); private var last = 0L
  private fun tone(f0: Float, f1: Float, ms: Int, vol: Float, noise: Float = 0f, pow: Float = 2f): FloatArray { val n = SR * ms / 1000; val r = Random(7); var ph = 0.0
    return FloatArray(n) { i -> val t = i / n.toFloat(); ph += 2 * PI * (f0 + (f1 - f0) * t) / SR; (sin(ph).toFloat() * (1 - noise) + (r.nextFloat() * 2 - 1) * noise) * vol * (1 - t).pow(pow) } }
  private fun mix(vararg p: Pair<Int, FloatArray>): ShortArray { val n = p.maxOf { SR * it.first / 1000 + it.second.size }; val o = FloatArray(n)
    p.forEach { (ms, a) -> val off = SR * ms / 1000; a.forEachIndexed { i, v -> o[off + i] += v } }; return ShortArray(n) { (o[it].coerceIn(-1f, 1f) * 32767).toInt().toShort() } }
  private fun pitch(v: Int) = 2f.pow(((v % 8) * 2) / 12f)   // whole-tone steps upward
  private fun build(kind: String, lock: Boolean, v: Int): ShortArray = when (kind) {
    "Revolver" -> if (lock) mix(0 to tone(160f, 90f, 45, .8f), 0 to tone(2200f, 900f, 8, .6f, .8f), 30 to tone(1200f, 700f, 10, .5f, .6f)) else mix(0 to tone(2500f, 1200f, 6, .5f, .8f), 16 to tone(900f, 600f, 9, .4f, .5f))
    "Bubble" -> mix(0 to tone(300f, 950f, 100, .35f))
    "Wood tap" -> if (lock) mix(0 to tone(300f, 220f, 60, .6f, .2f, 3f)) else mix(0 to tone(520f, 380f, 35, .5f, .2f, 3f))
    "Typewriter" -> if (lock) mix(0 to tone(3000f, 1500f, 5, .5f, .9f), 12 to tone(600f, 400f, 25, .35f, .4f, 3f), 40 to tone(2400f, 2400f, 280, .25f, 0f, 1.6f)) else mix(0 to tone(3000f, 1500f, 5, .5f, .9f), 12 to tone(600f, 400f, 25, .35f, .4f, 3f))
    "Water drop" -> { val p = pitch(v); mix(0 to tone(700f * p, 1500f * p, 70, .35f, 0f, 2.5f)) }
    "Ratchet" -> if (lock) mix(0 to tone(200f, 100f, 40, .7f), 0 to tone(2600f, 1200f, 6, .6f, .8f)) else mix(0 to tone(3000f, 1800f, 3, .4f, .9f), 6 to tone(3000f, 1800f, 3, .4f, .9f), 12 to tone(3000f, 1800f, 3, .4f, .9f))
    "Glass" -> if (lock) mix(0 to tone(2800f, 2800f, 220, .35f, 0f, 1.8f)) else mix(0 to tone(3800f, 3500f, 25, .3f, 0f, 2.2f))
    "Marimba" -> { val f = 392f * pitch(v); if (lock) mix(0 to tone(f, f, 160, .4f, 0f, 2.5f), 0 to tone(f * 1.5f, f * 1.5f, 160, .25f, 0f, 2.5f)) else mix(0 to tone(f, f, 120, .4f, 0f, 2.5f)) }
    else -> mix(0 to tone(1500f, 1100f, 14, .22f))   // Rolling
  }
  private fun track(kind: String, lock: Boolean, v: Int): AudioTrack { val vv = if (kind == "Water drop" || kind == "Marimba") v % 8 else 0
    return tracks.getOrPut("$kind:$lock:$vv") { val d = build(kind, lock, vv)
      AudioTrack.Builder().setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
        .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(SR).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
        .setTransferMode(AudioTrack.MODE_STATIC).setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY).setBufferSizeInBytes(d.size * 2).build().also { it.write(d, 0, d.size) } } }
  fun warm(kind: String) { if (kind == "Off") return; for (v in 0 until 8) runCatching { track(kind, false, v) } }
  private fun play(kind: String, lock: Boolean, v: Int) { runCatching { val t = track(kind, lock, v); t.stop(); t.reloadStaticData(); t.play() } }
  fun step(kind: String, v: Int = 0) { if (kind == "Off") return; val n = System.currentTimeMillis(); if (n - last < 35) return; last = n; play(kind, false, v) }
  // landing on an app plays the same sound you picked (skipped if that sound just played as the app passed)
  fun lock(kind: String, v: Int = 0) { if (kind == "Off") return; val n = System.currentTimeMillis(); if (n - last < 150) return; last = n; play(kind, false, v) }
}
