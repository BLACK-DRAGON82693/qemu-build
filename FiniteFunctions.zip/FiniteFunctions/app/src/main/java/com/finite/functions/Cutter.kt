package com.finite.functions
import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaPlayer
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs

object Audio {
  private fun open(c: Context, uri: Uri): Pair<MediaExtractor, MediaFormat>? { val ex = MediaExtractor(); ex.setDataSource(c, uri, null)
    for (i in 0 until ex.trackCount) { val f = ex.getTrackFormat(i); if (f.getString(MediaFormat.KEY_MIME)!!.startsWith("audio/")) { ex.selectTrack(i); return ex to f } }
    ex.release(); return null }

  // decodes the audio between startUs and endUs and hands each chunk of 16-bit samples (with its time) to sink; returns sample rate and channels
  fun decode(c: Context, uri: Uri, startUs: Long, endUs: Long, sink: (ShortArray, Long) -> Unit): Pair<Int, Int> {
    val (ex, fmt) = open(c, uri) ?: error("no audio"); var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE); var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
    if (startUs > 0) ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
    if (fmt.getString(MediaFormat.KEY_MIME) == "audio/raw") { val rb = ByteBuffer.allocate(1 shl 16)
      while (true) { rb.clear(); val n = ex.readSampleData(rb, 0); if (n < 0 || ex.sampleTime > endUs) break; val t = ex.sampleTime
        if (t >= startUs) { val sh = ShortArray(n / 2); ByteBuffer.wrap(rb.array(), 0, n).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(sh); sink(sh, t) }; ex.advance() }
      ex.release(); return rate to ch }
    val dec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!); dec.configure(fmt, null, null, 0); dec.start()
    val info = MediaCodec.BufferInfo(); var inDone = false; var outDone = false
    while (!outDone) {
      if (!inDone) { val i = dec.dequeueInputBuffer(10000)
        if (i >= 0) { val n = ex.readSampleData(dec.getInputBuffer(i)!!, 0)
          if (n < 0 || ex.sampleTime > endUs) { dec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true } else { dec.queueInputBuffer(i, 0, n, ex.sampleTime, 0); ex.advance() } } }
      val o = dec.dequeueOutputBuffer(info, 10000)
      if (o >= 0) { if (info.size > 0 && info.presentationTimeUs >= startUs) { val ob = dec.getOutputBuffer(o)!!; ob.order(ByteOrder.nativeOrder()); ob.position(info.offset); ob.limit(info.offset + info.size)
          val sh = ShortArray(info.size / 2); ob.asShortBuffer().get(sh); sink(sh, info.presentationTimeUs) }
        dec.releaseOutputBuffer(o, false); if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true }
      else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { val nf = dec.outputFormat; rate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE); ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT) } }
    dec.stop(); dec.release(); ex.release(); return rate to ch }

  // the song's loudness along its length, for drawing the waveform; second value is its length in microseconds
  fun waveform(c: Context, uri: Uri, bins: Int = 500, onP: (Float) -> Unit): Pair<FloatArray, Long> {
    val (ex, fmt) = open(c, uri) ?: error("no audio"); val dur = fmt.getLong(MediaFormat.KEY_DURATION); ex.release()
    val peaks = FloatArray(bins)
    decode(c, uri, 0, Long.MAX_VALUE) { sh, t -> val b = (t * bins / dur).toInt().coerceIn(0, bins - 1); var m = 0; for (s in sh) { val a = abs(s.toInt()); if (a > m) m = a }; if (m / 32768f > peaks[b]) peaks[b] = m / 32768f; onP((t / dur.toFloat()).coerceIn(0f, 1f)) }
    val mx = (peaks.maxOrNull() ?: 1f).coerceAtLeast(.01f); for (i in peaks.indices) peaks[i] = peaks[i] / mx; return peaks to dur }

  // what kind of file the audio is: mp3, aac (m4a), wav or other
  fun sourceKind(c: Context, uri: Uri): String { val (ex, fmt) = open(c, uri) ?: return "other"; val m = fmt.getString(MediaFormat.KEY_MIME) ?: ""; ex.release()
    return when (m) { "audio/mpeg" -> "mp3"; "audio/mp4a-latm" -> "aac"; "audio/raw" -> "wav"; else -> "other" } }

  // cuts an MP3 or an M4A without re-encoding: the song's own frames are copied across, so there's no quality loss
  fun cutLossless(c: Context, uri: Uri, s: Long, e: Long, out: File, onP: (Float) -> Unit) {
    val (ex, fmt) = open(c, uri)!!; val mp3 = fmt.getString(MediaFormat.KEY_MIME) == "audio/mpeg"; ex.seekTo(s, MediaExtractor.SEEK_TO_PREVIOUS_SYNC); val buf = ByteBuffer.allocate(1 shl 16)
    if (mp3) FileOutputStream(out).use { o -> while (true) { buf.clear(); val n = ex.readSampleData(buf, 0); if (n < 0) break; val t = ex.sampleTime; if (t > e) break
        if (t >= s) o.write(buf.array(), 0, n); ex.advance(); onP(((t - s) / (e - s).toFloat()).coerceIn(0f, 1f)) } }
    else { val mux = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4); val ti = mux.addTrack(fmt); mux.start(); val info = MediaCodec.BufferInfo()
      while (true) { buf.clear(); val n = ex.readSampleData(buf, 0); if (n < 0) break; val t = ex.sampleTime; if (t > e) break
        if (t >= s) { info.set(0, n, t - s, MediaCodec.BUFFER_FLAG_KEY_FRAME); buf.position(0); buf.limit(n); mux.writeSampleData(ti, buf, info) }; ex.advance(); onP(((t - s) / (e - s).toFloat()).coerceIn(0f, 1f)) }
      mux.stop(); mux.release() }
    ex.release() }

  // saves the part as a WAV (uncompressed, large, lossless)
  fun cutWav(c: Context, uri: Uri, s: Long, e: Long, out: File, onP: (Float) -> Unit) {
    val parts = ArrayList<ShortArray>(); var total = 0; val (rate, ch) = decode(c, uri, s, e) { sh, t -> if (t < e) { parts.add(sh); total += sh.size; onP(((t - s) / (e - s).toFloat()).coerceIn(0f, .9f)) } }
    val bytes = total * 2; val bb = ByteBuffer.allocate(44 + bytes).order(ByteOrder.LITTLE_ENDIAN)
    bb.put("RIFF".toByteArray()); bb.putInt(36 + bytes); bb.put("WAVE".toByteArray()); bb.put("fmt ".toByteArray()); bb.putInt(16); bb.putShort(1); bb.putShort(ch.toShort()); bb.putInt(rate); bb.putInt(rate * ch * 2); bb.putShort((ch * 2).toShort()); bb.putShort(16)
    bb.put("data".toByteArray()); bb.putInt(bytes); val sb = bb.asShortBuffer(); parts.forEach { sb.put(it) }; out.writeBytes(bb.array()); onP(1f) }

  // cuts the part between startUs and endUs and saves it as an M4A (AAC). An MP3 can't be cut without re-encoding, so there's a tiny loss of quality.
  fun cut(c: Context, uri: Uri, startUs: Long, endUs: Long, out: File, onP: (Float) -> Unit) {
    val parts = ArrayList<ShortArray>(); var total = 0; val (rate, ch) = decode(c, uri, startUs, endUs) { sh, t -> if (t < endUs) { parts.add(sh); total += sh.size } }
    val all = ShortArray(total); var o = 0; parts.forEach { System.arraycopy(it, 0, all, o, it.size); o += it.size }; parts.clear()
    val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
    enc.configure(MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, rate, ch).apply { setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC); setInteger(MediaFormat.KEY_BIT_RATE, 128000); setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384) }, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
    enc.start(); val mux = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4); var track = -1; var started = false
    val info = MediaCodec.BufferInfo(); var pos = 0; var inDone = false; var outDone = false
    while (!outDone) {
      if (!inDone) { val i = enc.dequeueInputBuffer(10000)
        if (i >= 0) { val buf = enc.getInputBuffer(i)!!; buf.clear(); buf.order(ByteOrder.nativeOrder()); val n = minOf(buf.capacity() / 2, total - pos); val pts = pos.toLong() * 1_000_000L / (rate * ch)
          if (n <= 0) { enc.queueInputBuffer(i, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true } else { buf.asShortBuffer().put(all, pos, n); enc.queueInputBuffer(i, 0, n * 2, pts, 0); pos += n }
          onP(if (total == 0) 1f else pos / total.toFloat()) } }
      val r = enc.dequeueOutputBuffer(info, 10000)
      if (r == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { track = mux.addTrack(enc.outputFormat); mux.start(); started = true }
      else if (r >= 0) { val ob = enc.getOutputBuffer(r)!!; if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
        if (info.size > 0 && started) { ob.position(info.offset); ob.limit(info.offset + info.size); mux.writeSampleData(track, ob, info) }
        enc.releaseOutputBuffer(r, false); if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true } }
    enc.stop(); enc.release(); mux.stop(); mux.release() }
}

private fun fmt(us: Long): String { val t = us / 100000; return "${t / 600}:${"%02d".format((t / 10) % 60)}.${t % 10}" }
private fun nameOf(c: Context, u: Uri) = c.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null } ?: "audio"

// Audio cutter: pick a song, drag the two handles on the waveform, preview, then cut. The cut lands in Library > Cuts.
@Composable fun CutterPage() {
  val c = LocalContext.current; val scope = rememberCoroutineScope(); val st = remember { Store(c) }
  var uri by remember { mutableStateOf<Uri?>(null) }; var name by remember { mutableStateOf("") }; var wave by remember { mutableStateOf<FloatArray?>(null) }; var durUs by remember { mutableStateOf(0L) }; var wp by remember { mutableStateOf(0f) }
  var a by remember { mutableStateOf(0f) }; var b by remember { mutableStateOf(1f) }; var playing by remember { mutableStateOf(false) }; var fmtSel by remember { mutableStateOf("Same as original") }; var src by remember { mutableStateOf("") }; var cutP by remember { mutableStateOf<Float?>(null) }; var songs by remember { mutableStateOf(false) }
  val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) { uri = u; name = nameOf(c, u) } }
  LaunchedEffect(uri) { val u = uri ?: return@LaunchedEffect; wave = null; wp = 0f; a = 0f; b = 1f; playing = false
    src = withContext(Dispatchers.IO) { runCatching { Audio.sourceKind(c, u) }.getOrDefault("other") }
    val r = withContext(Dispatchers.IO) { runCatching { Audio.waveform(c, u) { wp = it } }.getOrNull() }
    if (r == null) Toast.makeText(c, "Couldn't read that audio", Toast.LENGTH_SHORT).show() else { wave = r.first; durUs = r.second } }
  val mp = remember { MediaPlayer() }; DisposableEffect(Unit) { onDispose { runCatching { mp.release() } } }
  LaunchedEffect(playing) { if (playing) { val u = uri; if (u != null) { runCatching { mp.reset(); mp.setDataSource(c, u); mp.prepare(); mp.seekTo((a * durUs / 1000).toInt()); mp.start() }
      while (playing && mp.currentPosition < b * durUs / 1000) delay(40L) }; runCatching { mp.pause() }; playing = false } else runCatching { if (mp.isPlaying) mp.pause() } }
  fun nudge(start: Boolean, ds: Float) { val d = ds * 1_000_000f / durUs.coerceAtLeast(1); if (start) a = (a + d).coerceIn(0f, b - 0.002f) else b = (b + d).coerceIn(a + 0.002f, 1f) }
  // what the cut comes out as: file type, method and a note for the page. null = not possible.
  fun plan(): Triple<String, String, String>? = when (fmtSel) {
    "MP3" -> if (src == "mp3") Triple("mp3", "lossless", "Cut without re-encoding, so no quality is lost.") else null
    "M4A" -> if (src == "aac") Triple("m4a", "lossless", "Cut without re-encoding, so no quality is lost.") else Triple("m4a", "encode", "Re-encoded to M4A, with a tiny loss of quality.")
    "WAV" -> Triple("wav", "wav", "Saved as WAV. Large files, nothing lost.")
    else -> when (src) { "mp3" -> Triple("mp3", "lossless", "Stays an MP3, cut without re-encoding, so no quality is lost."); "aac" -> Triple("m4a", "lossless", "Stays an M4A, cut without re-encoding, so no quality is lost.")
      "wav" -> Triple("wav", "wav", "Stays a WAV."); else -> Triple("m4a", "encode", "This type can't be cut as it is, so it's saved as an M4A.") } }
  fun doCut() { val pl = plan() ?: return; val u = uri ?: return; val s = (a * durUs).toLong(); val e = (b * durUs).toLong(); cutP = 0f
    scope.launch(Dispatchers.IO) { val label = "${name.substringBeforeLast('.')} ${fmt(s)}–${fmt(e)}"; val f = File(LibStore.dir(c, "cut"), label.replace(Regex("[^A-Za-z0-9._ –-]"), "-") + "." + pl.first)
      val ok = runCatching { when (pl.second) { "lossless" -> Audio.cutLossless(c, u, s, e, f) { cutP = it }; "wav" -> Audio.cutWav(c, u, s, e, f) { cutP = it }; else -> Audio.cut(c, u, s, e, f) { cutP = it } }; true }.getOrDefault(false)
      if (ok) { LibStore.addMade(c, "cut", f, label, when (pl.first) { "mp3" -> "audio/mpeg"; "wav" -> "audio/x-wav"; else -> "audio/mp4" }); LibStore.toast(c, "Saved to Library > Cuts") } else { f.delete(); LibStore.toast(c, "Couldn't cut that audio") }; cutP = null } }
  Column(Modifier.fillMaxWidth().padding(top = 12.dp)) {
    Row { TButton({ pick.launch(arrayOf("audio/*")) }) { Text("Choose audio file") }; Spacer(Modifier.width(8.dp)); TOutlinedButton({ songs = true }) { Text("From Music") } }
    if (uri != null) Text(name, color = Color.White, modifier = Modifier.padding(top = 10.dp), maxLines = 1)
    if (uri != null && wave == null) Row(Modifier.padding(top = 10.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) { CircularProgressIndicator(progress = { wp }, color = Color.White, trackColor = Color(0xFF333333), modifier = Modifier.size(24.dp)); Text("  Reading the song… ${(wp * 100).toInt()}%", color = Color.Gray, fontSize = 13.sp) }
    val w = wave
    if (w != null) {
      Canvas(Modifier.fillMaxWidth().height(120.dp).padding(top = 12.dp).clip(RoundedCornerShape(12.dp)).background(Th.card)
        .pointerInput(w) { var grab = 0
          detectDragGestures(onDragStart = { off -> grab = if (abs(off.x / size.width - a) < abs(off.x / size.width - b)) 0 else 1 },
            onDrag = { ch, _ -> val f = (ch.position.x / size.width).coerceIn(0f, 1f); if (grab == 0) a = minOf(f, b - 0.002f) else b = maxOf(f, a + 0.002f) }) }) {
        val bw = size.width / w.size; w.forEachIndexed { i, v -> val x = i * bw; val inside = x / size.width in a..b; val hh = maxOf(2f, v * size.height * .9f)
          drawRect(if (inside) Color.White else Color(0xFF555555), Offset(x, (size.height - hh) / 2), Size(maxOf(1f, bw - 1f), hh)) }
        drawRect(Color.White, Offset(a * size.width - 2f, 0f), Size(4f, size.height)); drawRect(Color.White, Offset(b * size.width - 2f, 0f), Size(4f, size.height)) }
      Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text("Start ${fmt((a * durUs).toLong())}", color = Color.White, fontSize = 13.sp); Text("Length ${fmt(((b - a) * durUs).toLong())}", color = Color.Gray, fontSize = 13.sp); Text("End ${fmt((b * durUs).toLong())}", color = Color.White, fontSize = 13.sp) }
      Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Row { Tx("−0.1") { nudge(true, -.1f) }; Tx("+0.1") { nudge(true, .1f) } }; Row { Tx("−0.1") { nudge(false, -.1f) }; Tx("+0.1") { nudge(false, .1f) } } }
      Row(Modifier.padding(top = 8.dp)) { TButton({ playing = !playing }) { Text(if (playing) "Stop" else "Play the selection") }; Spacer(Modifier.width(8.dp)); TButton({ doCut() }, enabled = plan() != null) { Text("Cut") } }
      Text("Save as", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp)); Row(Modifier.horizontalScroll(rememberScrollState())) { listOf("Same as original", "MP3", "M4A", "WAV").forEach { Pick(it, it == fmtSel) { fmtSel = it } } }
      Text(plan()?.third ?: "Converting to MP3 needs an encoder that isn't included in the app yet. Choose Same as original or M4A.", color = if (plan() == null) Color(0xFFFF8A80) else Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
      Text("The cut is saved in Library > Cuts.", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp)) } }
  cutP?.let { p -> CenterCard("Cutting", false, { }, locked = true) { RecRow("Cut", p, "") } }
  if (songs) CenterCard("Choose a song", false, { songs = false }) { LazyColumn(Modifier.heightIn(max = 360.dp)) { items(st.lib()["All"] ?: emptyList()) { s -> Text(s.t, color = Color.White, maxLines = 1, modifier = Modifier.fillMaxWidth().clickable { uri = Uri.parse(s.u); name = s.t; songs = false }.padding(vertical = 10.dp)) } }
    TTextButton({ songs = false }) { Text("Cancel") } }
}
